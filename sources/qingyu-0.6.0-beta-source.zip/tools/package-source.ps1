$ErrorActionPreference='Stop'
$project=Split-Path -Parent $PSScriptRoot
$version=([regex]::Match((Get-Content "$project/app/build.gradle" -Raw),"versionName '([^']+)'")).Groups[1].Value
$destination=Join-Path $project "dist/source-$version"
if(Test-Path -LiteralPath $destination){throw "Source staging already exists: $destination"}
New-Item -ItemType Directory -Path "$destination/app","$destination/tools" -Force | Out-Null
foreach($name in @('build.gradle','settings.gradle','gradle.properties','LICENSE','README.md','发布更新说明.md')){
    Copy-Item -LiteralPath "$project/$name" -Destination $destination
}
Copy-Item -LiteralPath "$project/app/build.gradle" -Destination "$destination/app"
Copy-Item -LiteralPath "$project/app/src" -Destination "$destination/app" -Recurse
foreach($name in @('activate-android.ps1','build-prototype.ps1','download-voice-runtime.ps1','download-dictionary.ps1','build-dictionary.py','test-prototype.ps1','test-upgrade6.ps1','test-phone-voice.ps1','build-update-fixtures.ps1','prepare-update.ps1','package-source.ps1','build-home-font.py')){
    Copy-Item -LiteralPath "$project/tools/$name" -Destination "$destination/tools"
}
Copy-Item -LiteralPath "$project/SOURCE-BUILD.md" -Destination $destination
New-Item -ItemType Directory -Path "$destination/dist" -Force | Out-Null
foreach($name in @('一加12语音验收说明.md','百度翻译配置与验收-0.6.md',"测试报告-$($version.Split('-')[0]).md")){
    $document=Join-Path "$project/dist" $name
    if(Test-Path -LiteralPath $document){Copy-Item -LiteralPath $document -Destination "$destination/dist"}
}
if(Test-Path -LiteralPath "$project/design"){Copy-Item -LiteralPath "$project/design" -Destination $destination -Recurse}
$forbidden=Get-ChildItem -LiteralPath $destination -Recurse -File | Where-Object {
    $_.Extension -in @('.jks','.keystore','.apk','.aar','.part') -or $_.Name -in @('local.properties','key.properties','.env')
}
if($forbidden){throw 'Source archive contains a forbidden local artifact'}
$zip=Join-Path $project "dist/qingyu-$version-source.zip"
Compress-Archive -Path "$destination/*" -DestinationPath $zip -Force
Get-FileHash -LiteralPath $zip -Algorithm SHA256
