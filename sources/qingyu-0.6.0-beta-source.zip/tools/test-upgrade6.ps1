param([string]$Serial='emulator-5554')
$ErrorActionPreference='Stop'
. "$PSScriptRoot/activate-android.ps1"
$project=Split-Path -Parent $PSScriptRoot
function Invoke-Device([string[]]$Arguments){
    $result=& adb -s $Serial @Arguments 2>&1
    if($LASTEXITCODE -ne 0){throw ($result | Out-String)}
    return ($result | Out-String).Trim()
}
if((Invoke-Device @('shell','getprop','ro.kernel.qemu')) -ne '1'){throw 'Upgrade fixture is restricted to an emulator.'}
$pkg='com.jianyi.translator.prototype'
$qa=Join-Path $project 'dist/qa'
New-Item -ItemType Directory -Force -Path $qa | Out-Null
Invoke-Device @('shell','am','force-stop',$pkg) | Out-Null
Invoke-Device @('install','-r','-d',"$project/dist/qingyu-0.5.1-beta.apk") | Out-Null
$legacy='[{"q":"I want to eat beef","zh":false,"time":1,"en":"I want to eat beef","cn":"我想吃"}]'
$favorite='[{"q":"bank","zh":false,"time":1}]'
$fixture='<?xml version="1.0" encoding="utf-8"?><map><string name="history">'+[Security.SecurityElement]::Escape($legacy)+'</string><string name="favorites">'+[Security.SecurityElement]::Escape($favorite)+'</string></map>'
Set-Content -LiteralPath "$qa/upgrade-fixture.xml" -Value $fixture -Encoding utf8
Get-Content -LiteralPath "$qa/upgrade-fixture.xml" -Raw | & adb -s $Serial shell run-as $pkg tee shared_prefs/jianyi-local-v1.xml | Out-Null
if($LASTEXITCODE -ne 0){throw "Could not write emulator-only fixture"}
Invoke-Device @('shell','am','start','-W','-n',"$pkg/com.jianyi.translator.MainActivity") | Out-Null
Invoke-Device @('shell','am','force-stop',$pkg) | Out-Null
$before=Invoke-Device @('shell','run-as',$pkg,'cat','shared_prefs/jianyi-local-v1.xml')
$voiceBefore=Invoke-Device @('shell','run-as',$pkg,'sha256sum','files/voices/uk-cori-v1/en_GB-cori-medium.onnx','files/voices/us-v1/en_US-ljspeech-medium.onnx')
$uidBefore=Invoke-Device @('shell','run-as',$pkg,'id','-u')
Invoke-Device @('install','-r',"$project/dist/qingyu-0.6.0-beta.apk") | Out-Null
Invoke-Device @('shell','am','start','-W','-n',"$pkg/com.jianyi.translator.MainActivity") | Out-Null
$after=Invoke-Device @('shell','run-as',$pkg,'cat','shared_prefs/jianyi-local-v1.xml')
$voiceAfter=Invoke-Device @('shell','run-as',$pkg,'sha256sum','files/voices/uk-cori-v1/en_GB-cori-medium.onnx','files/voices/us-v1/en_US-ljspeech-medium.onnx')
$uidAfter=Invoke-Device @('shell','run-as',$pkg,'id','-u')
if($before -ne $after){throw 'Legacy history/favorites changed during upgrade'}
if($voiceBefore -ne $voiceAfter){throw 'Installed voice model changed during upgrade'}
if($uidBefore -ne $uidAfter){throw 'App identity changed during upgrade'}
$version=Invoke-Device @('shell','dumpsys','package',$pkg)
if($version -notmatch 'versionName=0.6.0-beta'){throw 'Unexpected installed version'}
'PASS: 4 checks (upgrade6): 0.5.1 -> 0.6, identical legacy records, identical voice models, same UID, expected version.' | Tee-Object -FilePath "$qa/upgrade6.txt"
