package com.jianyi.translator;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.lang.reflect.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/** Emulator-only UI integration; fake translation transport never sends test credentials. */
final class UiChecks6 {
    private final Instrumentation runner;private final MainActivity main;private int count;
    private UiChecks6(Instrumentation r,MainActivity a){runner=r;main=a;}
    private void ok(boolean value,String label){if(!value)throw new AssertionError(label);count++;}
    private View find(Activity a,String tag){return a.findViewById(android.R.id.content).findViewWithTag(tag);}
    private String text(Activity a,String tag){return ((TextView)find(a,tag)).getText().toString();}
    private boolean has(View v,String text){if(v instanceof TextView&&((TextView)v).getText().toString().contains(text))return true;if(v instanceof android.view.ViewGroup){android.view.ViewGroup g=(android.view.ViewGroup)v;for(int i=0;i<g.getChildCount();i++)if(has(g.getChildAt(i),text))return true;}return false;}
    private boolean mainHas(String text){boolean[] found={false};runner.runOnMainSync(()->found[0]=has(main.findViewById(android.R.id.content),text));return found[0];}
    private void query(String value){runner.runOnMainSync(()->{((EditText)find(main,"query-input")).setText(value);find(main,"submit").performClick();});}
    private void waitFor(String value)throws Exception{for(int i=0;i<60&&!mainHas(value);i++)Thread.sleep(50);ok(mainHas(value),"UI contains "+value);}
    static int run(Instrumentation r,MainActivity main)throws Exception{return new UiChecks6(r,main).test();}
    private int test()throws Exception {
        Context c=runner.getTargetContext();TranslationAccount account=new TranslationAccount(c);account.save("123456789","ui-test-key-not-real",1000000);TranslationPolicy.consent(c,1);
        AtomicInteger calls=new AtomicInteger();DictionaryRepository.Result beef=TranslationChecks.result("I want to eat beef","我想吃牛肉");
        runner.runOnMainSync(()->main.translatorFactory=()->new OnlineTranslator(){@Override DictionaryRepository.Result translate(String q,boolean zh)throws IOException{calls.incrementAndGet();try{Thread.sleep(200);}catch(InterruptedException e){throw new InterruptedIOException();}return beef;}});
        query("I want to eat beef");waitFor("我想吃牛肉");ok(calls.get()==1,"mock provider called once");
        query("I want to eat beef");waitFor("百度翻译 · 已保存");ok(calls.get()==1,"repeat uses cache without network");
        runner.runOnMainSync(()->find(main,"online-translate").performClick());waitFor("百度翻译 · 联网");ok(calls.get()==2,"explicit refresh bypasses cache");
        CountDownLatch entered=new CountDownLatch(1),release=new CountDownLatch(1);AtomicInteger duplicateCalls=new AtomicInteger();
        runner.runOnMainSync(()->main.translatorFactory=()->new OnlineTranslator(){@Override DictionaryRepository.Result translate(String q,boolean zh)throws IOException{duplicateCalls.incrementAndGet();entered.countDown();try{release.await(2,TimeUnit.SECONDS);}catch(InterruptedException e){/* Intentionally deliver a stale response to test UI generation guard. */}return beef;}});
        query("pending sentence");ok(entered.await(2,TimeUnit.SECONDS),"pending request started");runner.runOnMainSync(()->find(main,"submit").performClick());Thread.sleep(100);ok(duplicateCalls.get()==1,"duplicate tap coalesced");
        runner.runOnMainSync(()->find(main,"clear-input").performClick());release.countDown();Thread.sleep(200);ok(!mainHas("我想吃牛肉"),"cancelled response cannot overwrite cleared input");
        // Settings must require explicit quota confirmation, conceal and not save secret view state.
        Instrumentation.ActivityMonitor m=runner.addMonitor(TranslationSettingsActivity.class.getName(),null,false);
        runner.runOnMainSync(()->main.startActivity(new Intent(main,TranslationSettingsActivity.class)));
        Activity settings=m.waitForActivityWithTimeout(3000);runner.removeMonitor(m);ok(settings!=null,"configuration activity opens");runner.waitForIdleSync();
        runner.runOnMainSync(()->{
            EditText key=(EditText)find(settings,"baidu-secret");ok(key.getTransformationMethod() instanceof android.text.method.PasswordTransformationMethod,"secret masked");ok(!key.isSaveEnabled(),"secret excluded from state");
            find(settings,"baidu-save").performClick();ok(text(settings,"baidu-status").contains("勾选"),"consent required");
            ((EditText)find(settings,"baidu-remaining")).setText("1000000");((CheckBox)find(settings,"baidu-consent")).setChecked(true);find(settings,"baidu-save").performClick();
        });
        for(int i=0;i<60;i++){Thread.sleep(50);boolean[] done={false};runner.runOnMainSync(()->done[0]=text(settings,"baidu-status").startsWith("已保存"));if(done[0])break;}
        runner.runOnMainSync(()->{ok(text(settings,"baidu-status").startsWith("已保存"),"empty key preserves existing matching account");ok(text(settings,"baidu-secret").isEmpty(),"key field clears after save");settings.finish();});runner.waitForIdleSync();
        // Trigger certificate failure through the actual update page, without weakening TLS.
        m=runner.addMonitor(UpdateActivity.class.getName(),null,false);runner.runOnMainSync(()->main.startActivity(new Intent(main,UpdateActivity.class)));Activity update=m.waitForActivityWithTimeout(3000);runner.removeMonitor(m);ok(update!=null,"update activity opens");runner.waitForIdleSync();
        runner.runOnMainSync(()->{try{
            Method cancel=UpdateActivity.class.getDeclaredMethod("cancelTask");cancel.setAccessible(true);cancel.invoke(update);
            Field generation=UpdateActivity.class.getDeclaredField("generation");generation.setAccessible(true);
            Method fail=UpdateActivity.class.getDeclaredMethod("failure",int.class,Exception.class);fail.setAccessible(true);fail.invoke(update,generation.getInt(update),new javax.net.ssl.SSLHandshakeException("sensitive hidden detail"));
        }catch(Exception e){throw new AssertionError(e);}});runner.waitForIdleSync();
        runner.runOnMainSync(()->{ok(text(update,"update-details").contains("安全连接"),"certificate error readable on page");ok(find(update,"browser-update").getVisibility()==View.VISIBLE&&find(update,"check-update").isEnabled(),"browser and retry available after failure");ok(!has(update.findViewById(android.R.id.content),"sensitive hidden detail"),"raw exception absent from UI");update.finish();});runner.waitForIdleSync();
        account.delete();TranslationPolicy.consent(c,-1);runner.runOnMainSync(()->{main.translatorFactory=()->new OnlineTranslator(c);find(main,"clear-input").performClick();});
        return count;
    }
}
