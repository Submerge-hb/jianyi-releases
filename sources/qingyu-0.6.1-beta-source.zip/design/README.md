# 轻语 · 淡墨山水

首页采用用户确认的“淡墨山水”方向，题句为“字里行间，山海相逢。”。图中不包含文字，应用使用原生 TextView 渲染标题及全部操作，支持系统字体缩放。背景插画仅作装饰，不参与无障碍朗读。

生成方式：内置 image_gen 工具。原图为 `qingyu-landscape-source.png`；应用资源为 `app/src/main/res/drawable-nodpi/qingyu_landscape.jpg`，仅转换 JPEG 编码（质量 82），没有把界面文字烧录进图片。资源 79,341 字节。页面将插画限制在 136 dp 高区域，使用 0.66 透明度；输入或查询时收起题句，结果区按内容增长。

最终生成提示词：

> Create a single landscape illustration asset for a minimalist Chinese translator mobile app named 轻语. NOT a UI screenshot. NO text, letters, logo, border, frame, icons, or watermark. Extremely quiet Chinese ink wash mountains in desaturated sage gray, misty lake and faint reflections, a few tiny trees on distant shore. Wide horizontal aspect ratio 3:1. Warm uniform off-white paper background exact color #F7F5ED, no visible paper grain. Left 40 percent almost completely empty paper for a text overlay; layered distant mountain contours rising on the right, gentle dark sage accents only in rightmost quarter. Mountains and water fade gently into the paper at all edges, especially left and bottom. Airy, understated, poetic editorial illustration, low contrast but delicate intelligible mountain contours. Match a refined off-white and sage green Android interface. Artwork fills short header area only, no landscape continuing below image, no large solid dark regions.

为避免旧版更新失效，项目内部兼容包名、持久化键及公开更新地址仍沿用旧标识。实际显示名为轻语，Gradle 工程名为 QingYu，主要安装包与源码包以 qingyu- 命名。
