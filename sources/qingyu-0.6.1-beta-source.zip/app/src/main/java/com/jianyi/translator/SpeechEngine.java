package com.jianyi.translator;

import android.content.Context;
import android.media.*;
import android.os.*;
import com.k2fsa.sherpa.onnx.*;
import java.io.*;
import java.lang.ref.WeakReference;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/** Application-scoped engine. Native model access is confined to the synthesis executor. */
final class SpeechEngine {
    static final int CACHE_LIMIT=8*1024*1024;
    static final float SPEED=1.0f;
    interface Listener { void state(String state); void failed(); }
    interface DiskAction { void run()throws Exception; }
    static final class Metrics {
        long loadMs,generateMs,totalMs,referenceSamples,writtenSamples;
        volatile long firstOutputMs=-1;
        boolean cacheHit=true;
        int chunks;
    }
    static final class Job {
        final long started=SystemClock.elapsedRealtime();
        final String text;
        final VoiceStore.Pack pack;
        final WeakReference<Listener> listener;
        final ArrayBlockingQueue<float[]> queue=new ArrayBlockingQueue<>(2);
        final CompletableFuture<Metrics> done=new CompletableFuture<>();
        final Metrics metrics=new Metrics();
        volatile boolean cancelled;
        volatile int rate;
        Job(String text,VoiceStore.Pack pack,Listener listener){this.text=text;this.pack=pack;this.listener=new WeakReference<>(listener);}
    }
    private static final float[] END=new float[0];
    private static SpeechEngine instance;
    static synchronized SpeechEngine get(Context c){if(instance==null)instance=new SpeechEngine(c.getApplicationContext());return instance;}
    private final Context context;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService synthesis=Executors.newSingleThreadExecutor();
    private final ExecutorService playback=Executors.newSingleThreadExecutor();
    private final LinkedHashMap<String,GeneratedAudio> cache=new LinkedHashMap<>(16,0.75f,true);
    private int cacheBytes;
    private final AtomicInteger epoch=new AtomicInteger();
    private volatile Job current;
    private volatile AudioTrack track;
    private OfflineTts model;
    private VoiceStore.Pack loaded;
    volatile int modelLoads;
    SpeechEngine(Context c){context=c.getApplicationContext();}

    static OfflineTts create(Context c,VoiceStore.Pack p){
        File dir=VoiceStore.directory(c,p);
        OfflineTtsVitsModelConfig vits=new OfflineTtsVitsModelConfig();
        vits.setModel(new File(dir,p.model).getPath());vits.setTokens(new File(dir,"tokens.txt").getPath());
        vits.setDataDir(new File(dir,"espeak-ng-data").getPath());
        OfflineTtsModelConfig cfg=new OfflineTtsModelConfig();cfg.setVits(vits);cfg.setNumThreads(2);cfg.setDebug(false);
        OfflineTtsConfig tts=new OfflineTtsConfig();tts.setModel(cfg);tts.setMaxNumSentences(1);
        return new OfflineTts(null,tts);
    }
    private void ensureModel(VoiceStore.Pack p){
        if(model!=null&&loaded==p)return;
        releaseModel();model=create(context,p);loaded=p;modelLoads++;
    }
    private void releaseModel(){if(model!=null){model.release();model=null;}loaded=null;}
    private boolean live(Job job){return current==job&&!job.cancelled;}
    private void state(Job job,String value){
        main.post(()->{Listener l=job.listener.get();if(l!=null&&(!job.cancelled||value.equals("idle")))l.state(value);});
    }
    private void cancelLocked(Job job){
        if(job==null)return;job.cancelled=true;job.queue.clear();job.queue.offer(END);
        AudioTrack audio=track;if(audio!=null)try{audio.pause();audio.flush();}catch(IllegalStateException ignored){}
        job.done.cancel(false);state(job,"idle");
    }
    synchronized Job speak(String text,VoiceStore.Pack pack,Listener listener){
        cancelLocked(current);epoch.incrementAndGet();
        Job job=new Job(text.trim(),pack,listener);current=job;
        context.getSharedPreferences("jianyi-settings",0).edit().putString("last-voice",pack==VoiceStore.US?"us":"uk").apply();
        state(job,"preparing");
        synthesis.submit(()->generate(job));
        return job;
    }
    synchronized void cancel(Job job){
        if(current==job){cancelLocked(job);current=null;epoch.incrementAndGet();}
    }
    synchronized void suspend(){
        cancelLocked(current);current=null;epoch.incrementAndGet();
        synthesis.submit(()->{releaseModel();clearCache();});
    }
    void prewarm(){
        if(current!=null)return;
        boolean us=context.getSharedPreferences("jianyi-settings",0).getString("last-voice","uk").equals("us");
        VoiceStore.Pack pack=VoiceStore.available(context,us?Locale.US:Locale.UK);
        if(!VoiceStore.ready(context,pack))return;
        int ticket=epoch.get();
        synthesis.submit(()->{
            if(ticket!=epoch.get()||current!=null||!VoiceStore.ready(context,pack))return;
            try{ensureModel(pack);}catch(Exception|LinkageError ignored){releaseModel();}
        });
    }
    /** Prevent a downloaded/removed model from racing native inference or preloading. */
    synchronized Future<?> exclusive(DiskAction action){
        cancelLocked(current);current=null;epoch.incrementAndGet();
        return synthesis.submit(()->{releaseModel();clearCache();try{action.run();}catch(Exception ex){throw new CompletionException(ex);}});
    }
    private String key(VoiceStore.Pack p,String text){return p.sha+"|"+p.speaker+"|"+SPEED+"|"+text;}
    private synchronized GeneratedAudio cached(String key){return cache.get(key);}
    private synchronized void remember(String key,GeneratedAudio audio){
        int bytes=audio.getSamples().length*4;
        if(bytes>CACHE_LIMIT)return;
        GeneratedAudio previous=cache.remove(key);if(previous!=null)cacheBytes-=previous.getSamples().length*4;
        while(cacheBytes+bytes>CACHE_LIMIT&&!cache.isEmpty()){
            Map.Entry<String,GeneratedAudio> eldest=cache.entrySet().iterator().next();
            cacheBytes-=eldest.getValue().getSamples().length*4;cache.remove(eldest.getKey());
        }
        cache.put(key,audio);cacheBytes+=bytes;
    }
    private synchronized void clearCache(){cache.clear();cacheBytes=0;}
    synchronized int cachedBytes(){return cacheBytes;}
    Future<?> barrier(){return synthesis.submit(()->{});}
    private boolean offer(Job job,float[] samples){
        try{while(live(job)){if(job.queue.offer(samples,40,TimeUnit.MILLISECONDS))return true;}}
        catch(InterruptedException ex){Thread.currentThread().interrupt();}
        return false;
    }
    private void generate(Job job){
        if(!live(job))return;
        Future<?> playing=null;
        try{
            for(String piece:SpeechPlayer.segments(job.text)){
                if(!live(job))return;
                String key=key(job.pack,piece);GeneratedAudio hit=cached(key);
                if(hit!=null){
                    job.metrics.referenceSamples+=hit.getSamples().length;
                    job.rate=hit.getSampleRate();
                    if(playing==null)playing=playback.submit(()->play(job));
                    if(!offer(job,hit.getSamples()))return;
                }else{
                    job.metrics.cacheHit=false;
                    long start=SystemClock.elapsedRealtime();ensureModel(job.pack);
                    job.metrics.loadMs+=SystemClock.elapsedRealtime()-start;
                    if(!live(job))return;
                    job.rate=model.sampleRate();
                    if(playing==null)playing=playback.submit(()->play(job));
                    final int[] callbacks={0};
                    start=SystemClock.elapsedRealtime();
                    // Keep a typed invoke(float[]) bridge: JNI cannot invoke an erased Java lambda.
                    GeneratedAudio audio=model.generateWithCallback(piece,job.pack.speaker,SPEED,new kotlin.jvm.functions.Function1<float[],Integer>(){
                        @Override public Integer invoke(float[] samples){
                            if(samples.length==0)return live(job)?1:0;
                            callbacks[0]++;return offer(job,samples)?1:0;
                        }
                    });
                    job.metrics.generateMs+=SystemClock.elapsedRealtime()-start;
                    if(!live(job))return;
                    if(audio.getSamples().length==0)throw new IOException("Empty speech");
                    job.metrics.referenceSamples+=audio.getSamples().length;
                    // Some runtimes may return audio without invoking callbacks; never play both.
                    if(callbacks[0]==0&&!offer(job,audio.getSamples()))return;
                    remember(key,audio);
                }
            }
            if(!offer(job,END))return;
            if(playing!=null)playing.get();
            if(live(job)){
                job.metrics.totalMs=SystemClock.elapsedRealtime()-job.started;
                job.done.complete(job.metrics);
            }
        }catch(Exception|LinkageError ex){
            if(live(job)){
                job.done.completeExceptionally(ex);
                main.post(()->{Listener l=job.listener.get();if(l!=null&&!job.cancelled)l.failed();});
            }
            releaseModel();
        }finally{
            if(!job.done.isDone())job.done.cancel(false);
            // Unblock playback on error as well as cancellation.
            job.queue.offer(END);
            synchronized(this){if(current==job){current=null;epoch.incrementAndGet();}}
            state(job,"idle");
        }
    }
    private void play(Job job){
        AudioTrack audio=null;
        AudioManager manager=(AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
        AudioAttributes attributes=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build();
        AudioFocusRequest focus=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            .setAudioAttributes(attributes).setOnAudioFocusChangeListener(change->{if(change<0)cancel(job);},main).build();
        try{
            float[] samples=job.queue.poll(60,TimeUnit.SECONDS);
            if(samples==null)throw new IOException("Speech timed out");
            if(samples==END||!live(job))return;
            int rate=job.rate;
            int minimum=AudioTrack.getMinBufferSize(rate,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_FLOAT);
            if(minimum<=0)throw new IOException("Unsupported audio format");
            audio=new AudioTrack.Builder().setAudioAttributes(attributes)
                .setAudioFormat(new AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_FLOAT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setTransferMode(AudioTrack.MODE_STREAM).setBufferSizeInBytes(Math.max(minimum,4096)).build();
            synchronized(this){if(!live(job))return;track=audio;}
            if(manager.requestAudioFocus(focus)!=AudioManager.AUDIOFOCUS_REQUEST_GRANTED)throw new IOException("Audio busy");
            audio.play();long written=0;boolean announced=false;
            while(live(job)&&samples!=END){
                job.metrics.chunks++;
                for(int offset=0;offset<samples.length&&live(job);){
                    int n=audio.write(samples,offset,Math.min(1024,samples.length-offset),AudioTrack.WRITE_NON_BLOCKING);
                    if(n<0)throw new IOException("Audio write failed");
                    if(n==0){SystemClock.sleep(4);continue;}
                    if(!announced){job.metrics.firstOutputMs=SystemClock.elapsedRealtime()-job.started;announced=true;state(job,"playing");}
                    offset+=n;written+=n;job.metrics.writtenSamples+=n;
                }
                if(!live(job))break;
                samples=job.queue.poll(60,TimeUnit.SECONDS);
                if(samples==null)throw new IOException("Speech timed out");
            }
            long deadline=SystemClock.elapsedRealtime()+4000;
            while(live(job)&&Integer.toUnsignedLong(audio.getPlaybackHeadPosition())<written&&SystemClock.elapsedRealtime()<deadline)SystemClock.sleep(8);
        }catch(Exception ex){
            job.done.completeExceptionally(ex);
            synchronized(this){if(current==job){job.cancelled=true;current=null;}}
            main.post(()->{Listener l=job.listener.get();if(l!=null)l.failed();});
        }finally{
            if(audio!=null){synchronized(this){if(track==audio)track=null;}try{audio.pause();audio.flush();}catch(IllegalStateException ignored){}audio.release();}
            manager.abandonAudioFocusRequest(focus);
        }
    }
}
