package com.jianyi.translator;

import android.content.Context;
import android.view.*;

/** Four actions fit one row when their actual scaled labels fit, otherwise two rows. */
final class AdaptiveActions extends ViewGroup {
    private final int gap;
    private int columns=1,rowHeight;
    AdaptiveActions(Context c){super(c);gap=Math.round(6*c.getResources().getDisplayMetrics().density);}
    @Override protected void onMeasure(int widthSpec,int heightSpec){
        int width=MeasureSpec.getSize(widthSpec),count=getChildCount(),needed=0;
        for(int i=0;i<count;i++){
            View child=getChildAt(i);child.measure(MeasureSpec.makeMeasureSpec(0,MeasureSpec.UNSPECIFIED),MeasureSpec.makeMeasureSpec(0,MeasureSpec.UNSPECIFIED));needed=Math.max(needed,child.getMeasuredWidth());
        }
        columns=count==4&&needed*4+gap*3<=width?4:Math.min(2,Math.max(1,count));
        int cell=Math.max(1,(width-gap*(columns-1))/columns);rowHeight=0;
        for(int i=0;i<count;i++){View child=getChildAt(i);child.measure(MeasureSpec.makeMeasureSpec(cell,MeasureSpec.EXACTLY),MeasureSpec.makeMeasureSpec(0,MeasureSpec.UNSPECIFIED));rowHeight=Math.max(rowHeight,child.getMeasuredHeight());}
        int rows=(count+columns-1)/columns;setMeasuredDimension(width,rows*rowHeight+Math.max(0,rows-1)*gap);
    }
    @Override protected void onLayout(boolean changed,int left,int top,int right,int bottom){
        int cell=(getWidth()-gap*(columns-1))/columns;
        for(int i=0;i<getChildCount();i++){int x=(i%columns)*(cell+gap),y=(i/columns)*(rowHeight+gap);getChildAt(i).layout(x,y,x+cell,y+rowHeight);}
    }
    @Override protected LayoutParams generateDefaultLayoutParams(){return new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT);}
}
