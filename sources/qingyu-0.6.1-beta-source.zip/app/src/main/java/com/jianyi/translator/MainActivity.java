package com.jianyi.translator;

import android.app.*;
import android.content.*;
import android.content.res.ColorStateList;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.*;
import android.text.*;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.*;
import android.view.inputmethod.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.*;
import java.util.concurrent.*;

public final class MainActivity extends Activity {
    static final int PAPER=0xffF7F5ED, WHITE=0xffFFFEFA, INK=0xff293B30,
        MUTED=0xff687266, GREEN=0xff526D58, PALE=0xffE8EDE2, LINE=0xffE2E5D9;
    private DictionaryRepository repository;
    private LocalStore store;
    private SpeechPlayer speech;
    private LinearLayout root, page, navigation, results, hero, header, actionBar;
    private LinearLayout modes, inputBox, editorRow, inputFooter, examples, submitSlot;
    private Button submitButton, clearButton;
    private View inputRule;
    private boolean compact=false;
    private ScrollView scroll;
    private EditText input;
    private String draft="", lastQuery="";
    private boolean fromChinese=false;
    private boolean keyboardVisible=false;
    private int tab=0;
    private final ExecutorService network=Executors.newSingleThreadExecutor();
    private Future<?> pending;
    private int requestVersion=0;
    private OnlineTranslator translator;
    java.util.function.Supplier<OnlineTranslator> translatorFactory=()->new OnlineTranslator(getApplicationContext());

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        store=new LocalStore(this); speech=new SpeechPlayer(this);
        try { repository=new DictionaryRepository(this); }
        catch(Exception ex) { new AlertDialog.Builder(this).setTitle("离线词库未能加载").setMessage("请重新安装完整的轻语 APK。").setPositiveButton("关闭",(d,w)->finish()).setCancelable(false).show();return; }
        if(state!=null){draft=state.getString("draft","");lastQuery=state.getString("last","");fromChinese=state.getBoolean("zh");tab=state.getInt("tab");compact=state.getBoolean("compact",!lastQuery.isEmpty());}
        if(Build.VERSION.SDK_INT>=30) {
            getWindow().setDecorFitsSystemWindows(false);
        } else getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        root=column(); root.setBackgroundColor(PAPER);
        if(Build.VERSION.SDK_INT>=29)root.setForceDarkAllowed(false);
        setContentView(root);
        if(Build.VERSION.SDK_INT>=30 && getWindow().getInsetsController()!=null) {
            getWindow().getInsetsController().setSystemBarsAppearance(WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS|WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS,WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS|WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
        }
        root.setOnApplyWindowInsetsListener((v,insets)->{
            int left,top,right,bottom; boolean keyboard=false;
            if(Build.VERSION.SDK_INT>=30){
                Insets bars=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());
                Insets ime=insets.getInsets(WindowInsets.Type.ime());
                left=bars.left;top=bars.top;right=bars.right;bottom=Math.max(bars.bottom,ime.bottom);
                keyboard=insets.isVisible(WindowInsets.Type.ime());
            }else{left=insets.getSystemWindowInsetLeft();top=insets.getSystemWindowInsetTop();right=insets.getSystemWindowInsetRight();bottom=insets.getSystemWindowInsetBottom();keyboard=bottom>dp(140);}
            v.setPadding(left,top,right,bottom);
            keyboardVisible=keyboard;
            updateChrome();
            return insets;
        });
        render();
    }
    @Override protected void onSaveInstanceState(Bundle state){
        super.onSaveInstanceState(state);state.putString("draft",draft);state.putString("last",lastQuery);state.putBoolean("zh",fromChinese);state.putInt("tab",tab);state.putBoolean("compact",compact);
    }
    @Override protected void onStop(){super.onStop();if(speech!=null)speech.stop();}
    @Override protected void onResume(){super.onResume();if(speech!=null&&!lastQuery.isEmpty())speech.prewarm();}
    @Override protected void onDestroy(){cancelNetwork();network.shutdownNow();if(repository!=null)repository.close();if(speech!=null)speech.close();super.onDestroy();}
    @Override public void onBackPressed(){if(tab!=0){tab=0;render();}else super.onBackPressed();}

    private int dp(float value){return Math.round(value*getResources().getDisplayMetrics().density);}
    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private GradientDrawable shape(int color,int radius,boolean stroke){
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));if(stroke)d.setStroke(dp(1),LINE);return d;
    }
    private void clickable(View v,int color,int radius){v.setBackground(new RippleDrawable(ColorStateList.valueOf(0x22526D58),shape(color,radius,false),shape(Color.WHITE,radius,false)));v.setClickable(true);v.setFocusable(true);}
    private TextView text(String value,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);t.setIncludeFontPadding(false);t.setLineSpacing(dp(3),1f);
        t.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));return t;
    }
    private Button button(String value,int color,int background){
        Button b=new Button(this);b.setText(value);b.setTextSize(14);b.setAllCaps(false);b.setTextColor(color);b.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
        b.setMinHeight(dp(48));b.setMinimumHeight(dp(48));b.setMinWidth(0);b.setMinimumWidth(0);b.setPadding(dp(12),dp(8),dp(12),dp(8));b.setStateListAnimator(null);clickable(b,background,16);return b;
    }
    private void add(LinearLayout parent,View child,int top){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(top);parent.addView(child,p);}
    private void space(LinearLayout parent,int size){View v=new View(this);parent.addView(v,new LinearLayout.LayoutParams(1,dp(size)));}
    private void rule(LinearLayout parent,int top){View v=new View(this);v.setBackgroundColor(LINE);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(1));p.topMargin=dp(top);parent.addView(v,p);}
    private void weight(LinearLayout parent,View child){parent.addView(child,new LinearLayout.LayoutParams(0,-2,1));}
    private LinearLayout card(){LinearLayout c=column();c.setPadding(dp(20),dp(20),dp(20),dp(20));c.setBackground(shape(WHITE,24,true));return c;}
    private void toast(String value){Toast.makeText(this,value,Toast.LENGTH_SHORT).show();}

    private void render(){
        if(root==null)return;
        cancelNetwork();
        speech.stop();root.removeAllViews();input=null;hero=null;navigation=null;
        header=row();header.setPadding(dp(22),dp(10),dp(22),dp(8));
        TextView name=text(getString(R.string.app_name),19,INK,false);name.setTypeface(getResources().getFont(R.font.qingyu_kai));weight(header,name);
        LinearLayout badge=row();badge.setPadding(dp(10),0,dp(4),0);badge.setMinimumHeight(dp(48));
        Glyph gear=new Glyph("settings",MUTED);badge.addView(gear,new LinearLayout.LayoutParams(dp(19),dp(19)));
        TextView settingsLabel=text("设置",13,MUTED,false);settingsLabel.setPadding(dp(7),0,0,0);badge.addView(settingsLabel);
        clickable(badge,PAPER,12);badge.setTag("about");badge.setContentDescription("打开设置");badge.setOnClickListener(v->settings());header.addView(badge);
        root.addView(header,new LinearLayout.LayoutParams(-1,-2));
        scroll=new ScrollView(this);scroll.setTag("result-scroll");scroll.setFillViewport(true);scroll.setClipToPadding(false);scroll.setVerticalScrollBarEnabled(false);
        page=column();page.setPadding(dp(24),dp(8),dp(24),dp(24));scroll.addView(page,new ScrollView.LayoutParams(-1,-2));root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        actionBar=column();actionBar.setTag("result-actions");actionBar.setBackgroundColor(PAPER);actionBar.setVisibility(View.GONE);root.addView(actionBar,new LinearLayout.LayoutParams(-1,-2));
        if(tab==0)home();else collection();
        buildNavigation();updateChrome();root.requestApplyInsets();
    }
    private void buildNavigation(){
        navigation=column();navigation.setBackgroundColor(PAPER);rule(navigation,0);
        LinearLayout items=row();items.setPadding(dp(20),dp(6),dp(20),dp(4));
        String[] names={"翻译","收藏","历史"},icons={"translate","bookmark","clock"};
        for(int i=0;i<3;i++){
            final int index=i;LinearLayout item=column();item.setGravity(Gravity.CENTER);item.setPadding(0,dp(7),0,dp(7));
            clickable(item,PAPER,18);item.setTag("tab-"+i);item.setContentDescription(names[i]);item.setSelected(tab==i);
            Glyph icon=new Glyph(icons[i],tab==i?GREEN:MUTED);icon.setPadding(dp(13),dp(3),dp(13),dp(3));if(tab==i)icon.setBackground(shape(PALE,14,false));item.addView(icon,new LinearLayout.LayoutParams(dp(50),dp(29)));
            TextView label=text(names[i],11,tab==i?GREEN:MUTED,tab==i);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,-2);lp.topMargin=dp(4);item.addView(label,lp);
            item.setMinimumHeight(dp(62));item.setOnClickListener(v->{hideKeyboard();tab=index;render();});LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(0,-2,1);if(i>0)ip.leftMargin=dp(14);items.addView(item,ip);
        }
        navigation.addView(items);root.addView(navigation,new LinearLayout.LayoutParams(-1,-2));
    }
    private void home(){
        hero=column();hero.setTag("home-hero");FrameLayout scene=new FrameLayout(this);scene.setMinimumHeight(dp(136));
        ImageView landscape=new ImageView(this);landscape.setImageResource(R.drawable.qingyu_landscape);landscape.setScaleType(ImageView.ScaleType.FIT_XY);landscape.setAlpha(.66f);landscape.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        scene.addView(landscape,new FrameLayout.LayoutParams(-1,dp(136),Gravity.BOTTOM));
        TextView verse=text("字里行间，\n山海相逢。",21,INK,false);verse.setTypeface(getResources().getFont(R.font.qingyu_kai));verse.setLineSpacing(dp(6),1f);verse.setPadding(dp(2),dp(18),0,dp(20));
        scene.addView(verse,new FrameLayout.LayoutParams(-1,-2,Gravity.CENTER_VERTICAL));hero.addView(scene,new LinearLayout.LayoutParams(-1,-2));space(hero,14);page.addView(hero);
        modes=row();modes.setTag("translation-direction");modes.setBackground(shape(PALE,18,false));modes.setPadding(dp(4),dp(4),dp(4),dp(4));
        Button en=button("英文  →  中文",fromChinese?MUTED:GREEN,fromChinese?PALE:WHITE);en.setTag("mode-en");
        Button zh=button("中文  →  英文",fromChinese?GREEN:MUTED,fromChinese?WHITE:PALE);zh.setTag("mode-zh");
        en.setSelected(!fromChinese);zh.setSelected(fromChinese);en.setOnClickListener(v->changeMode(false));zh.setOnClickListener(v->changeMode(true));weight(modes,en);weight(modes,zh);add(page,modes,0);
        inputBox=card();inputBox.setTag("input-box");editorRow=row();inputBox.addView(editorRow);
        input=new EditText(this);input.setTag("query-input");input.setTextColor(INK);input.setHintTextColor(0xff92988B);input.setGravity(Gravity.TOP|Gravity.START);input.setBackgroundColor(Color.TRANSPARENT);
        input.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);input.setImeOptions(EditorInfo.IME_ACTION_DONE);input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(1000)});
        input.setHint(fromChinese?"输入中文词语或句子…":"输入英文单词或句子…");input.setContentDescription(fromChinese?"中文输入":"英文输入");input.setText(draft);weight(editorRow,input);
        rule(inputBox,0);inputRule=inputBox.getChildAt(inputBox.getChildCount()-1);
        inputFooter=row();TextView count=text(draft.length()+" / 1000",11,MUTED,false);weight(inputFooter,count);
        clearButton=button("清空",MUTED,WHITE);clearButton.setTag("clear-input");clearButton.setContentDescription("清空输入，返回首页");clearButton.setOnClickListener(v->clearInput());inputFooter.addView(clearButton);inputBox.addView(inputFooter);add(page,inputBox,8);
        submitButton=button("翻译     →",WHITE,GREEN);submitButton.setTag("submit");submitButton.setContentDescription("翻译输入内容");submitButton.setOnClickListener(v->submit());submitSlot=column();add(page,submitSlot,12);submitSlot.addView(submitButton,new LinearLayout.LayoutParams(-1,dp(54)));
        input.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence value,int start,int count,int after){}public void onTextChanged(CharSequence value,int start,int before,int countAdded){
            draft=value.toString();count.setText(getString(R.string.input_count,value.length()));input.setError(null);
            if(pending!=null||!lastQuery.isEmpty()){
                cancelNetwork();speech.stop();lastQuery="";showWelcome();
            }
        }public void afterTextChanged(Editable value){}});
        input.setOnEditorActionListener((v,action,event)->{if(action==EditorInfo.IME_ACTION_DONE){submit();return true;}return false;});
        examples=row();examples.setTag("query-examples");examples.addView(text("试试看",11,MUTED,false));HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);LinearLayout chips=row();
        String[] samples=fromChinese?new String[]{"银行","行走","这首音乐很好听。"}:new String[]{"bank","light","I went to the bank."};
        for(String sample:samples){Button chip=button(sample,GREEN,PAPER);chip.setTextSize(12);chip.setTag("sample:"+sample);chip.setOnClickListener(v->{input.setText(sample);submit();});chips.addView(chip);}
        hs.addView(chips);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(0,-2,1);hp.leftMargin=dp(6);examples.addView(hs,hp);add(page,examples,7);
        results=column();results.setTag("result-area");add(page,results,8);
        applyInputLayout();
        if(!lastQuery.isEmpty()&&lastQuery.equals(draft.trim()))showResult(resolve(lastQuery,fromChinese));else showWelcome();
        page.setFocusableInTouchMode(true);page.requestFocus();
    }
    private void updateChrome(){
        if(navigation!=null)navigation.setVisibility(keyboardVisible?View.GONE:View.VISIBLE);
        if(hero!=null&&tab==0)hero.setVisibility(keyboardVisible||compact?View.GONE:View.VISIBLE);
        if(actionBar!=null)actionBar.setVisibility(tab==0&&!keyboardVisible&&actionBar.getChildCount()>0?View.VISIBLE:View.GONE);
    }
    private void detach(View v){if(v.getParent() instanceof ViewGroup)((ViewGroup)v.getParent()).removeView(v);}
    private void applyInputLayout(){
        header.setPadding(dp(22),dp(compact?2:10),dp(22),dp(compact?2:8));
        page.setPadding(dp(compact?18:24),dp(compact?4:8),dp(compact?18:24),dp(16));
        inputBox.setPadding(dp(compact?12:18),dp(compact?4:12),dp(compact?4:18),dp(4));
        input.setTextSize(compact?16:20);input.setMinLines(compact?1:3);input.setMaxLines(compact?2:5);input.setMinimumHeight(dp(48));
        input.setPadding(0,dp(compact?6:10),dp(compact?4:0),dp(compact?6:12));input.setVerticalScrollBarEnabled(true);
        detach(submitButton);detach(clearButton);
        if(compact){
            submitButton.setText("翻译");clearButton.setText("×");clearButton.setTextSize(22);clearButton.setPadding(0,dp(4),0,dp(4));submitButton.setPadding(dp(4),dp(4),dp(4),dp(4));
            editorRow.addView(submitButton,new LinearLayout.LayoutParams(dp(48),-2));editorRow.addView(clearButton,new LinearLayout.LayoutParams(dp(48),-2));
        }else{
            submitButton.setText("翻译     →");submitButton.setPadding(dp(12),dp(8),dp(12),dp(8));clearButton.setText("清空");clearButton.setTextSize(14);clearButton.setPadding(dp(12),dp(8),dp(12),dp(8));
            inputFooter.addView(clearButton);submitSlot.addView(submitButton,new LinearLayout.LayoutParams(-1,-2));
        }
        inputFooter.setVisibility(compact?View.GONE:View.VISIBLE);inputRule.setVisibility(compact?View.GONE:View.VISIBLE);submitSlot.setVisibility(compact?View.GONE:View.VISIBLE);examples.setVisibility(compact?View.GONE:View.VISIBLE);
        ((Button)modes.getChildAt(0)).setText(compact?"英 → 中":"英文  →  中文");((Button)modes.getChildAt(1)).setText(compact?"中 → 英":"中文  →  英文");
        modes.setPadding(dp(compact?2:4),dp(compact?2:4),dp(compact?2:4),dp(compact?2:4));updateChrome();
    }
    private void clearInput(){
        cancelNetwork();speech.stop();lastQuery="";draft="";input.setText("");compact=false;showWelcome();applyInputLayout();hideKeyboard();scroll.post(()->scroll.scrollTo(0,0));
    }
    private void changeMode(boolean chinese){
        if(fromChinese==chinese)return;
        hideKeyboard();fromChinese=chinese;draft="";lastQuery="";render();
    }
    private void hideKeyboard(){View current=getCurrentFocus();if(current!=null){((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(current.getWindowToken(),0);current.clearFocus();}}
    private void submit(){
        String query=input.getText().toString().trim();
        if(query.isEmpty()){input.setError("先输入一个词或一句话");input.requestFocus();return;}
        if(pending!=null&&query.equals(lastQuery))return;
        cancelNetwork();speech.stop();hideKeyboard();lastQuery=query;compact=true;applyInputLayout();scroll.post(()->scroll.scrollTo(0,0));
        DictionaryRepository.Result cached=store.fresh(query,fromChinese,System.currentTimeMillis());
        if(cached!=null){store.record(query,fromChinese,cached);showResult(cached);return;}
        if(!TranslationPolicy.connected(this)){fallback(query,fromChinese,"当前无可用网络，已使用离线内容。");return;}
        if(TranslationPolicy.consent(this)<0){fallback(query,fromChinese,"已关闭联网翻译，可在设置中开启。");return;}
        requestOnline();
    }
    private DictionaryRepository.Result resolve(String q,boolean zh){DictionaryRepository.Result cached=store.cached(q,zh);return cached!=null?cached:repository.lookup(q,zh);}
    private void cancelNetwork(){requestVersion++;if(translator!=null){translator.close();translator=null;}if(pending!=null){pending.cancel(true);pending=null;}}
    private void fallback(String query,boolean chinese,String message){
        DictionaryRepository.Result local=resolve(query,chinese);
        if(local!=null)store.record(query,chinese,local);
        showResult(local);if(local!=null&&(message.startsWith("当前无可用网络")||message.startsWith("已关闭联网")))return;TextView notice=text(message,12,MUTED,false);notice.setTag("network-error");notice.setPadding(0,0,0,dp(12));results.addView(notice,0);
    }
    private void requestOnline(){
        final String query=lastQuery;final boolean chinese=fromChinese;if(query.isEmpty())return;
        if(!TranslationPolicy.connected(this)){fallback(query,chinese,"当前无可用网络，已使用离线内容。");return;}
        try{OnlineTranslator.validate(query);}catch(java.io.IOException ex){fallback(query,chinese,ex.getMessage());return;}
        if(!new TranslationAccount(this).configured()||TranslationPolicy.consent(this)<=0){
            fallback(query,chinese,"请在设置中配置并启用百度翻译服务。旧版译文仅供参考。");
            Button configure=button("配置翻译服务",WHITE,GREEN);configure.setTag("configure-translation");configure.setOnClickListener(v->startActivity(new Intent(this,TranslationSettingsActivity.class)));add(results,configure,12);return;
        }
        if(pending!=null)return;
        startOnline(query,chinese);
    }
    private void startOnline(String query,boolean chinese){
        cancelNetwork();final int version=requestVersion;
        DictionaryRepository.Result local=repository.lookup(query,chinese);if(local!=null)showResult(local);else showWelcome();
        LinearLayout loading=row();loading.setTag("network-loading");loading.setPadding(dp(10),0,0,0);loading.setBackground(shape(PALE,12,false));weight(loading,text("正在联网翻译…",13,GREEN,false));
        Button cancel=button("取消",GREEN,PALE);cancel.setTag("cancel-network");cancel.setOnClickListener(v->{cancelNetwork();showResult(resolve(lastQuery,fromChinese));});loading.addView(cancel);results.addView(loading,0);
        final OnlineTranslator request=translatorFactory.get();translator=request;
        pending=network.submit(()->{
            DictionaryRepository.Result translated=null;String error=null;
            try{translated=request.translate(query,chinese);}catch(Exception ex){error=NetworkErrors.message(ex,"翻译");}finally{request.close();}
            final DictionaryRepository.Result result=translated;final String message=error;
            runOnUiThread(()->{
                if(isFinishing()||isDestroyed()||version!=requestVersion)return;
                pending=null;
                if(result!=null){store.record(query,chinese,result);showResult(result);}
                else fallback(query,chinese,"联网未完成，已尝试离线内容。\n"+(message==null?"请稍后重试。":message));
            });
        });
    }
    private void showWelcome(){results.removeAllViews();actionBar.removeAllViews();updateChrome();}
    private String shortSource(DictionaryRepository.Result result){
        if(result==null)return "离线未收录";
        if(OnlineTranslator.PROVIDER.equals(result.provider))return result.source.contains("已保存")?"百度 · 已保存":"百度 · 联网";
        if(!result.provider.isEmpty())return "MyMemory · 旧版";
        return result.source;
    }
    private void resultMenu(View anchor,DictionaryRepository.Result result){
        PopupMenu menu=new PopupMenu(this,anchor);menu.getMenu().add(0,1,0,"重新联网翻译");menu.getMenu().add(0,2,1,"来源与说明");
        menu.setOnMenuItemClickListener(item->{if(item.getItemId()==1)requestOnline();else new AlertDialog.Builder(this).setTitle("来源与说明").setMessage(
            (result==null?"暂无可用结果":result.source)+"\n\n"+(result!=null&&!result.provider.isEmpty()?"机器译文仅供参考。\n\n":"")+"离线词库参考 ECDICT 与 ipa-dict，非牛津授权词典。点按英文单词可查看音标与释义，未收录的词不会编造内容。"
        ).setPositiveButton("知道了",null).show();return true;});menu.show();
    }
    private void showResult(DictionaryRepository.Result result){
        speech.stop();if(result!=null)speech.prewarm();results.removeAllViews();actionBar.removeAllViews();
        List<DictionaryRepository.Word> words=new ArrayList<>();
        if(result!=null){
            if(!result.isSentence())words.addAll(result.words);
            else{
                DictionaryRepository.Result dictionary=repository.lookup(lastQuery,fromChinese);
                if(dictionary!=null&&!dictionary.isSentence())words.addAll(dictionary.words);
                else if(fromChinese&&result.english.trim().matches("[A-Za-z]+(?:['’-][A-Za-z]+)*")){
                    DictionaryRepository.Word word=repository.word(result.english.trim());if(word!=null)words.add(word);
                }
            }
        }
        LinearLayout label=row();label.setTag("result-heading");weight(label,text(result==null?"暂无离线结果":words.isEmpty()?"翻译结果":"单词释义",16,INK,true));
        TextView source=text(shortSource(result),11,MUTED,false);source.setTag("result-source");source.setGravity(Gravity.END|Gravity.CENTER_VERTICAL);weight(label,source);
        Button more=button("···",GREEN,PAPER);more.setTextSize(20);more.setPadding(0,0,0,0);more.setTag("result-more");more.setContentDescription("更多：重新联网翻译、来源与说明");more.setOnClickListener(v->resultMenu(v,result));label.addView(more,new LinearLayout.LayoutParams(dp(48),-2));add(results,label,0);
        if(result==null){
            LinearLayout empty=card();empty.setPadding(dp(16),dp(14),dp(16),dp(14));add(empty,text("这条内容需要联网翻译",17,INK,true),0);add(empty,text("可查离线词典或查看已保存的译文。新句子请联网后，通过右上方“更多”重试。",13,MUTED,false),8);
            List<String> suggestions=fromChinese?Collections.emptyList():repository.suggestions(lastQuery);
            for(String value:suggestions){Button b=button(value,GREEN,PALE);b.setOnClickListener(v->{input.setText(value);submit();});add(empty,b,6);}add(results,empty,4);
        }else if(!words.isEmpty()){
            if(fromChinese)add(results,text("“"+lastQuery+"”的常见对应词"+(words.size()>1?" · 结合语境选择":""),12,MUTED,false),0);
            for(int i=0;i<words.size();i++)add(results,wordCard(words.get(i),i==0&&result.isSentence()?result.translation(fromChinese):null),6);
            buildResultActions(result,false);
        }else{
            LinearLayout c=card();c.setTag("sentence-card");c.setPadding(dp(16),dp(14),dp(16),dp(14));c.setBackground(shape(PALE,20,false));
            add(c,text(fromChinese?"中文原文":"英文原文",11,MUTED,false),0);
            TextView original=fromChinese?text(result.chinese,17,INK,false):clickableEnglish(result.english,17);if(fromChinese)original.setTag("sentence-chinese");add(c,original,6);
            rule(c,10);add(c,text(fromChinese?"英文译文":"中文译文",11,MUTED,false),10);
            TextView translated=fromChinese?clickableEnglish(result.english,20):text(result.chinese,20,INK,true);if(!fromChinese)translated.setTag("sentence-chinese");add(c,translated,6);
            add(c,text("点按英文单词查音标与释义",11,GREEN,false),10);add(results,c,4);buildResultActions(result,true);
        }
        updateChrome();
    }
    private void buildResultActions(DictionaryRepository.Result result,boolean sentence){
        // Outside the ScrollView, so the final definition is never hidden by this bar.
        actionBar.setPadding(dp(16),dp(6),dp(16),dp(6));AdaptiveActions actions=new AdaptiveActions(this);actions.setTag("action-buttons");actionBar.addView(actions,new LinearLayout.LayoutParams(-1,-2));
        if(sentence){
            Button uk=button("英式朗读",GREEN,PALE),us=button("美式朗读",GREEN,PALE);uk.setTag("speak-sentence-uk");us.setTag("speak-sentence-us");
            uk.setContentDescription("英式朗读英文内容");us.setContentDescription("美式朗读英文内容");uk.setOnClickListener(v->speech.speak(result.english,Locale.UK,v));us.setOnClickListener(v->speech.speak(result.english,Locale.US,v));actions.addView(uk);actions.addView(us);
        }
        Button copy=button("复制",GREEN,PALE);copy.setTag("copy-result");copy.setContentDescription("复制完整结果");copy.setOnClickListener(v->{((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("轻语",copyText(result)));toast("已复制");});actions.addView(copy);
        final String query=lastQuery;final boolean chinese=fromChinese;
        Button favorite=button(store.isFavorite(query,chinese)?"已收藏":"收藏",GREEN,PALE);favorite.setTag("favorite");favorite.setOnClickListener(v->{try{boolean saved=store.toggle(query,chinese);favorite.setText(saved?"已收藏":"收藏");toast(saved?"已加入收藏":"已取消收藏");}catch(IllegalStateException ex){toast(ex.getMessage());}});actions.addView(favorite);
    }
    private String copyText(DictionaryRepository.Result result){
        if(result.isSentence())return result.translation(fromChinese);
        StringBuilder b=new StringBuilder();for(DictionaryRepository.Word w:result.words){if(b.length()>0)b.append("\n\n");b.append(w.word).append("\n英 ").append(w.uk).append("  美 ").append(w.us);for(String[] s:w.senses)b.append("\n").append(s[0]).append(" ").append(s[1]);}return b.toString();
    }
    private LinearLayout wordCard(DictionaryRepository.Word word){return wordCard(word,null);}
    private LinearLayout wordCard(DictionaryRepository.Word word,String online){
        LinearLayout c=card();c.setTag("word-card:"+word.word);c.setPadding(dp(16),dp(12),dp(16),dp(12));
        TextView head=text(word.word,26,INK,false);head.setTypeface(Typeface.create("serif",Typeface.NORMAL));head.setTextIsSelectable(true);add(c,head,0);
        if(online!=null){TextView summary=text(getString(R.string.compact_translation,online),15,INK,false);summary.setTextIsSelectable(true);summary.setTag("word-online-summary");add(c,summary,6);}
        add(c,pronunciationRow("英",word.uk,word.word,Locale.UK),4);add(c,pronunciationRow("美",word.us,word.word,Locale.US),0);rule(c,4);
        int index=0;for(String[] sense:word.senses){
            LinearLayout line=row();line.setGravity(Gravity.TOP);TextView meaning=text(sense[1],15,INK,false);meaning.setTextIsSelectable(true);meaning.setTag("sense:"+word.word+":"+index++);
            TextView part=text(sense[0],12,GREEN,true);part.setPadding(0,dp(2),dp(8),0);
            if(getResources().getConfiguration().fontScale>=1.8f||sense[0].length()>10){LinearLayout block=column();add(block,part,0);add(block,meaning,3);add(c,block,8);}
            else{line.addView(part,new LinearLayout.LayoutParams(dp(48),-2));weight(line,meaning);add(c,line,8);}
        }return c;
    }
    private LinearLayout pronunciationRow(String label,String ipa,String word,Locale locale){
        LinearLayout row=row();row.addView(text(label,12,MUTED,false),new LinearLayout.LayoutParams(dp(30),-2));TextView p=text(ipa,16,INK,false);p.setTextIsSelectable(true);weight(row,p);
        FrameLayout audio=new FrameLayout(this);clickable(audio,PALE,16);
        Glyph icon=new Glyph("volume",GREEN);icon.setTag("speech-icon");icon.setPadding(dp(10),dp(10),dp(10),dp(10));audio.addView(icon,new FrameLayout.LayoutParams(-1,-1));
        ProgressBar progress=new ProgressBar(this);progress.setTag("speech-progress");progress.setVisibility(View.GONE);audio.addView(progress,new FrameLayout.LayoutParams(dp(24),dp(24),Gravity.CENTER));
        audio.setContentDescription("播放"+(label.equals("英")?"英式":"美式")+"离线发音："+word);audio.setTag("speak:"+label+":"+word);audio.setOnClickListener(v->speech.speak(word,locale,v));row.addView(audio,new LinearLayout.LayoutParams(dp(48),dp(48)));return row;
    }
    private TextView clickableEnglish(String sentence,int size){
        TextView t=text(sentence,size,INK,false);t.setTypeface(Typeface.create("serif",Typeface.NORMAL));SpannableString spans=new SpannableString(sentence);
        Matcher matcher=Pattern.compile("[A-Za-z]+(?:['’-][A-Za-z]+)*").matcher(sentence);
        while(matcher.find()){
            String word=matcher.group();spans.setSpan(new ClickableSpan(){@Override public void onClick(View view){showWord(word);}@Override public void updateDrawState(TextPaint ds){ds.setColor(GREEN);ds.setUnderlineText(true);}},matcher.start(),matcher.end(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        t.setText(spans);t.setMovementMethod(LinkMovementMethod.getInstance());t.setHighlightColor(0x33526D58);t.setTag("sentence-english");return t;
    }
    private void showWord(String query){
        DictionaryRepository.Word word=repository.word(query);if(word==null){toast("离线词库暂未收录这个词，可单独输入后联网翻译");return;}
        ScrollView s=new ScrollView(this);s.setPadding(dp(10),dp(10),dp(10),0);s.addView(wordCard(word));
        new AlertDialog.Builder(this).setTitle("单词速查 · 离线词典").setView(s).setPositiveButton("完成",null).show();
    }
    private void collection(){
        boolean favorites=tab==1;String kind=favorites?"favorites":"history";List<LocalStore.Entry> entries=store.read(kind);
        add(page,text(favorites?"把想记住的，\n留在这里。":"每一次查阅，\n都有迹可循。",28,INK,true),12);
        LinearLayout info=row();weight(info,text(favorites?"你的随身词语小册":"最近查询 · 最多保留 100 条",13,MUTED,false));info.addView(text(entries.size()+" 条",12,GREEN,true));add(page,info,18);
        if(!favorites && !entries.isEmpty()){Button clear=button("清空历史",MUTED,PAPER);clear.setTag("clear-history");clear.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("清空查询历史？").setMessage("会删除这台手机上的所有查询记录，收藏内容会保留。").setNegativeButton("取消",null).setPositiveButton("清空",(d,w)->{store.clearHistory();render();}).show());add(page,clear,7);}
        if(entries.isEmpty()){
            LinearLayout empty=card();Glyph g=new Glyph(favorites?"bookmark":"clock",GREEN);LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(dp(46),dp(46));gp.gravity=Gravity.CENTER;empty.addView(g,gp);
            TextView title=text(favorites?"还没有收藏":"还没有查询记录",18,INK,true);title.setGravity(Gravity.CENTER);add(empty,title,19);
            TextView message=text(favorites?"查词或翻译后，点击「收藏」。\n喜欢的词句，下次一眼找到。":"试着查一个词，\n你的查询记录就会出现在这里。",13,MUTED,false);message.setGravity(Gravity.CENTER);add(empty,message,12);
            Button go=button("去查一个词  →",WHITE,GREEN);go.setOnClickListener(v->{tab=0;render();});add(empty,go,24);add(page,empty,28);
        }else for(LocalStore.Entry e:entries){
            LinearLayout c=card();c.setPadding(dp(17),dp(12),dp(10),dp(12));LinearLayout line=row();LinearLayout body=column();body.setPadding(0,dp(7),dp(8),dp(7));add(body,text(e.query,18,INK,true),0);
            DictionaryRepository.Result r=e.result!=null?e.result:repository.lookup(e.query,e.fromChinese);TextView preview=text(r==null?"词库暂未收录":r.translation(e.fromChinese),13,MUTED,false);preview.setMaxLines(2);preview.setEllipsize(TextUtils.TruncateAt.END);add(body,preview,7);add(body,text((e.fromChinese?"中 → 英":"英 → 中")+"  ·  "+date(e.time),10,MUTED,false),10);
            clickable(body,WHITE,12);body.setTag("entry:"+e.query);body.setContentDescription("打开查询："+e.query);body.setOnClickListener(v->{fromChinese=e.fromChinese;draft=e.query;lastQuery=e.query;compact=true;tab=0;render();});weight(line,body);
            if(favorites){Glyph remove=new Glyph("x",MUTED);remove.setPadding(dp(14),dp(14),dp(14),dp(14));clickable(remove,WHITE,14);remove.setContentDescription("取消收藏："+e.query);remove.setTag("remove:"+e.key());remove.setOnClickListener(v->{store.toggle(e.query,e.fromChinese);render();toast("已取消收藏");});line.addView(remove,new LinearLayout.LayoutParams(dp(48),dp(48)));}
            c.addView(line);add(page,c,12);
        }
        TextView local=text("历史与收藏只存本机；联网翻译会发送所选文字。",11,MUTED,false);local.setGravity(Gravity.CENTER);add(page,local,24);
    }
    private String date(long time){SimpleDateFormat day=new SimpleDateFormat("yyyyMMdd",Locale.ROOT);return day.format(new Date(time)).equals(day.format(new Date()))?"今天":new SimpleDateFormat("M 月 d 日",Locale.CHINA).format(new Date(time));}
    private void settings(){
        String version;try{version=UpdateClient.installed(this).versionName;}catch(Exception e){version="未知";}
        new AlertDialog.Builder(this).setTitle("轻语设置").setItems(new String[]{"翻译服务","英美语音包","应用更新 · "+version,"关于与许可"},(d,w)->{
            cancelNetwork();
            if(w==0)startActivity(new Intent(this,TranslationSettingsActivity.class));
            else if(w==1)startActivity(new Intent(this,VoiceActivity.class));
            else if(w==2)startActivity(new Intent(this,UpdateActivity.class));else about();
        }).setNegativeButton("完成",null).show();
    }
    private void about(){new AlertDialog.Builder(this).setTitle("轻语 · 0.6.1 测试版")
        .setMessage("12,000 个离线词条，英美音标、词形还原、中文反查；保留 6 组内置短句。\n\n音标参考 ECDICT 与 ipa-dict，未逐条人工校对。非牛津授权词典。英美离线语音包独立下载，无需安装系统语音。\n\n联网翻译使用你配置的百度个人接口，启用后点击翻译发送文字，设置可关闭。每次最多 1000 字符，本机每月上限 10 万字符。失败时尝试离线词库及已保存译文。历史与收藏只存本机；卸载会清除。\n\n服务条款：https://fanyi-api.baidu.com/")
        .setNeutralButton("数据来源与许可",(d,w)->licenses()).setNegativeButton("检查更新",(d,w)->startActivity(new Intent(this,UpdateActivity.class))).setPositiveButton("知道了",null).show();}
    private void licenses(){
        StringBuilder content=new StringBuilder("ECDICT: https://github.com/skywind3000/ECDICT\nipa-dict: https://github.com/open-dict-data/ipa-dict\n美式数据上游：cmudict-ipa / CMUdict\n\n");
        try{for(String name:getAssets().list("licenses")){content.append(name).append("\n");try(java.io.InputStream in=getAssets().open("licenses/"+name);java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream()){byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);content.append(out.toString("UTF-8")).append("\n\n");}}}catch(java.io.IOException ex){content.append("许可文件暂时无法读取");}
        TextView t=text(content.toString(),12,INK,false);t.setTextIsSelectable(true);t.setPadding(dp(20),dp(12),dp(20),dp(12));ScrollView s=new ScrollView(this);s.addView(t);new AlertDialog.Builder(this).setTitle("开放数据许可").setView(s).setPositiveButton("完成",null).show();
    }

    private final class Glyph extends View {
        private final String kind;private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);private final Path glyphPath=new Path();
        Glyph(String kind,int color){super(MainActivity.this);this.kind=kind;paint.setColor(color);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(1.7f);paint.setStrokeCap(Paint.Cap.ROUND);paint.setStrokeJoin(Paint.Join.ROUND);setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);}
        @Override public void setContentDescription(CharSequence description){super.setContentDescription(description);setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);}
        @Override protected void onDraw(Canvas canvas){
            super.onDraw(canvas);float available=Math.min(getWidth()-getPaddingLeft()-getPaddingRight(),getHeight()-getPaddingTop()-getPaddingBottom());float size=available*(kind.equals("brand")?.63f:1f);canvas.save();canvas.translate((getWidth()-size)/2,(getHeight()-size)/2);canvas.scale(size/24,size/24);Path p=glyphPath;p.reset();
            switch(kind){
                case "settings":canvas.drawCircle(12,12,6.5f,paint);canvas.drawCircle(12,12,2.5f,paint);for(int i=0;i<8;i++){canvas.save();canvas.rotate(i*45,12,12);canvas.drawLine(12,2,12,5,paint);canvas.restore();}break;
                case "brand":case "book":p.moveTo(3,4);p.cubicTo(6,3,9,4,12,6);p.cubicTo(15,4,18,3,21,4);p.lineTo(21,20);p.cubicTo(17,19,15,19,12,21);p.cubicTo(9,19,7,19,3,20);p.close();canvas.drawPath(p,paint);canvas.drawLine(12,6,12,21,paint);canvas.drawLine(6,8,9,9,paint);canvas.drawLine(6,12,9,13,paint);canvas.drawLine(15,9,18,8,paint);break;
                case "bookmark":p.moveTo(6,3);p.lineTo(18,3);p.lineTo(18,22);p.lineTo(12,18);p.lineTo(6,22);p.close();canvas.drawPath(p,paint);break;
                case "clock":canvas.drawCircle(12,12,9,paint);canvas.drawLine(12,6,12,12,paint);canvas.drawLine(12,12,16,14,paint);break;
                case "x":canvas.drawLine(5,5,19,19,paint);canvas.drawLine(19,5,5,19,paint);break;
                case "volume":p.moveTo(3,9);p.lineTo(7,9);p.lineTo(12,5);p.lineTo(12,19);p.lineTo(7,15);p.lineTo(3,15);p.close();canvas.drawPath(p,paint);canvas.drawArc(10,7,20,17,-55,110,false,paint);canvas.drawArc(8,3,24,21,-52,104,false,paint);break;
                default:canvas.drawLine(3,5,15,5,paint);canvas.drawLine(9,2,9,5,paint);p.moveTo(12,5);p.cubicTo(11,11,7,14,3,15);canvas.drawPath(p,paint);canvas.drawLine(6,8,12,14,paint);p.reset();p.moveTo(13,21);p.lineTo(18,10);p.lineTo(23,21);canvas.drawPath(p,paint);canvas.drawLine(15,17,21,17,paint);
            }canvas.restore();
        }
    }
}
