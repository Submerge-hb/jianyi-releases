package com.jianyi.translator;

import android.content.Context;
import android.content.pm.*;
import android.os.Build;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

/** Public metadata and immutable-version APKs. No GitHub credentials in the app. */
final class UpdateClient implements AutoCloseable {
    static final String REPOSITORY="Submerge-hb/jianyi-releases";
    static final String MANIFEST_URL="https://raw.githubusercontent.com/"+REPOSITORY+"/main/update.json";
    static final long MAX_APK_BYTES=50L*1024*1024;
    private volatile boolean cancelled;
    private volatile HttpURLConnection connection;
    interface Progress { void changed(int percent); }
    static final class Info {
        final int versionCode,minSdk; final String versionName,url,sha256,notes,packageName;final long size;
        Info(JSONObject o)throws JSONException,IOException {
            if(o.getInt("schemaVersion")!=1)throw new NetworkErrors.Failure("更新信息格式不受支持");
            versionCode=o.getInt("versionCode");minSdk=o.getInt("minSdk");versionName=o.getString("versionName");
            url=o.getString("apkUrl");sha256=o.getString("sha256").toLowerCase(Locale.ROOT);
            notes=o.getString("notes");size=o.getLong("sizeBytes");packageName=o.getString("packageName");
            if(versionCode<1||minSdk<26||minSdk>100||!versionName.matches("[0-9][A-Za-z0-9.\\-]{0,39}")||!sha256.matches("[a-f0-9]{64}")||size<1024||size>MAX_APK_BYTES||notes.length()>4000||!packageName.equals("com.jianyi.translator.prototype"))
                throw new NetworkErrors.Failure("更新信息不完整或不匹配，暂不安装");
            validateApkUrl(url);
        }
        String fileName(){return "jianyi-"+versionCode+"-"+sha256+".apk";}
    }
    static Info parse(String json)throws IOException {
        try{return new Info(new JSONObject(json));}catch(JSONException ex){throw new NetworkErrors.Failure("更新信息格式异常，请稍后重试",ex);}
    }
    static void validateApkUrl(String value)throws IOException {
        try {
            URI u=new URI(value);
            if(!"https".equals(u.getScheme())||u.getUserInfo()!=null||u.getFragment()!=null||u.getQuery()!=null||u.getPort()!=-1)throw new NetworkErrors.Failure("更新下载地址不可信");
            String path=u.getRawPath();
            boolean raw="raw.githubusercontent.com".equals(u.getHost())&&path.matches("/Submerge-hb/jianyi-releases/[a-f0-9]{40}/packages/jianyi-[A-Za-z0-9.\\-]+\\.apk");
            boolean release="github.com".equals(u.getHost())&&path.matches("/Submerge-hb/jianyi-releases/releases/download/[A-Za-z0-9.\\-]+/jianyi-[A-Za-z0-9.\\-]+\\.apk");
            if(!raw&&!release)throw new NetworkErrors.Failure("更新下载地址不属于轻语发布仓库");
        }catch(URISyntaxException ex){throw new NetworkErrors.Failure("更新下载地址无效",ex);}
    }
    private void checkCancelled()throws InterruptedIOException{if(cancelled||Thread.currentThread().isInterrupted())throw new InterruptedIOException("已取消");}
    private HttpURLConnection open(String address)throws IOException {
        URL next=new URL(address);
        for(int i=0;i<5;i++){
            checkCancelled();
            if(!next.getProtocol().equals("https")||next.getUserInfo()!=null||next.getPort()!=-1||!Arrays.asList("raw.githubusercontent.com","github.com","release-assets.githubusercontent.com","objects.githubusercontent.com").contains(next.getHost()))throw new NetworkErrors.Failure("更新下载跳转地址不可信");
            HttpURLConnection c=(HttpURLConnection)next.openConnection();connection=c;
            c.setConnectTimeout(12000);c.setReadTimeout(15000);c.setInstanceFollowRedirects(false);c.setUseCaches(false);
            c.setRequestProperty("User-Agent","QingYu-Android-Updater");c.setRequestProperty("Accept-Encoding","identity");
            checkCancelled();int status=c.getResponseCode();
            if(status==301||status==302||status==303||status==307||status==308){String location=c.getHeaderField("Location");c.disconnect();if(location==null)throw new NetworkErrors.Failure("下载地址缺失");next=new URL(next,location);continue;}
            if(status==404){c.disconnect();throw new NetworkErrors.Failure("发布文件尚未就绪，请稍后重试");}
            if(status!=200){c.disconnect();throw new NetworkErrors.Failure(status==403||status==429?"GitHub 暂时限制访问，请稍后重试":"更新服务暂不可用（"+status+"）");}
            return c;
        }throw new NetworkErrors.Failure("下载跳转次数过多");
    }
    Info check()throws IOException {
        HttpURLConnection c=open(MANIFEST_URL);
        try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] buffer=new byte[4096];int n;
            while((n=in.read(buffer))!=-1){checkCancelled();if(out.size()+n>16384)throw new NetworkErrors.Failure("更新信息过大");out.write(buffer,0,n);}
            return parse(out.toString(StandardCharsets.UTF_8.name()));
        }finally{c.disconnect();}
    }
    static long version(PackageInfo p){return Build.VERSION.SDK_INT>=28?p.getLongVersionCode():p.versionCode;}
    static PackageInfo installed(Context context)throws PackageManager.NameNotFoundException{return context.getPackageManager().getPackageInfo(context.getPackageName(),Build.VERSION.SDK_INT>=28?PackageManager.GET_SIGNING_CERTIFICATES:PackageManager.GET_SIGNATURES);}
    static Set<String> certificates(PackageInfo p){
        Signature[] signatures=Build.VERSION.SDK_INT>=28?(p.signingInfo==null?null:p.signingInfo.getApkContentsSigners()):p.signatures;
        Set<String> certs=new HashSet<>();if(signatures!=null)for(Signature s:signatures)certs.add(s.toCharsString());return certs;
    }
    static String hex(byte[] bytes){StringBuilder s=new StringBuilder();for(byte b:bytes)s.append(String.format(Locale.ROOT,"%02x",b&255));return s.toString();}
    static String hash(File file)throws Exception {
        MessageDigest md=MessageDigest.getInstance("SHA-256");try(InputStream in=new FileInputStream(file)){byte[] buffer=new byte[32768];int n;while((n=in.read(buffer))!=-1){if(Thread.currentThread().isInterrupted())throw new InterruptedIOException();md.update(buffer,0,n);}}return hex(md.digest());
    }
    static void verify(Context context,File file,Info info)throws Exception {
        if(file.length()!=info.size||!hash(file).equals(info.sha256))throw new NetworkErrors.Failure("安装包校验失败，请重新下载");
        if(info.minSdk>Build.VERSION.SDK_INT)throw new NetworkErrors.Failure("这个版本需要更新的 Android 系统");
        PackageInfo current=installed(context);
        PackageInfo archive=context.getPackageManager().getPackageArchiveInfo(file.getPath(),Build.VERSION.SDK_INT>=28?PackageManager.GET_SIGNING_CERTIFICATES:PackageManager.GET_SIGNATURES);
        if(archive==null||archive.applicationInfo==null||archive.applicationInfo.minSdkVersion!=info.minSdk||!context.getPackageName().equals(archive.packageName)||!info.packageName.equals(archive.packageName)||version(archive)!=info.versionCode||!info.versionName.equals(archive.versionName)||version(archive)<=version(current))throw new NetworkErrors.Failure("安装包身份或版本不匹配，已停止更新");
        Set<String> expected=certificates(current);if(expected.isEmpty()||!expected.equals(certificates(archive)))throw new NetworkErrors.Failure("安装包签名不匹配，已停止更新");
    }
    File download(Context context,Info info,Progress progress)throws Exception {
        checkCancelled();File dir=new File(context.getCacheDir(),"updates");if(!dir.isDirectory()&&!dir.mkdirs())throw new NetworkErrors.Failure("无法创建下载目录");
        File target=new File(dir,info.fileName());
        if(target.exists()){try{verify(context,target,info);checkCancelled();return target;}catch(InterruptedIOException ex){throw ex;}catch(Exception ex){if(!target.delete())throw new NetworkErrors.Failure("无法替换旧下载文件");}}
        android.os.storage.StorageManager storage=(android.os.storage.StorageManager)context.getSystemService(Context.STORAGE_SERVICE);
        if(storage.getAllocatableBytes(storage.getUuidForPath(dir))<info.size+5*1024*1024)throw new NetworkErrors.Failure("手机存储空间不足，请清理后重试");
        File temporary=File.createTempFile("download-",".part",dir);
        HttpURLConnection c=null;
        try {
            c=open(info.url);long expected=c.getContentLengthLong();if(expected!=-1&&expected!=info.size)throw new NetworkErrors.Failure("下载大小与发布信息不一致");
            try(InputStream in=c.getInputStream();FileOutputStream out=new FileOutputStream(temporary)){
                storage.allocateBytes(out.getFD(),info.size);
                byte[] buffer=new byte[32768];long total=0;int n,last=-1;
                while((n=in.read(buffer))!=-1){checkCancelled();total+=n;if(total>info.size)throw new NetworkErrors.Failure("下载大小超出发布信息");out.write(buffer,0,n);int percent=(int)(total*100/info.size);if(percent!=last){progress.changed(percent);last=percent;}}
                out.getFD().sync();
            }
            verify(context,temporary,info);checkCancelled();
            if(!temporary.renameTo(target))throw new NetworkErrors.Failure("无法保存安装包，请重试");
            // The only files eligible for cleanup are old updater-owned files.
            File[] old=dir.listFiles();if(old!=null)for(File f:old)if(!f.equals(target)&&f.getName().matches("jianyi-[0-9]+-[a-f0-9]{64}\\.apk"))f.delete();
            return target;
        }finally{if(c!=null)c.disconnect();temporary.delete();}
    }
    @Override public void close(){cancelled=true;HttpURLConnection c=connection;if(c!=null)c.disconnect();}
}
