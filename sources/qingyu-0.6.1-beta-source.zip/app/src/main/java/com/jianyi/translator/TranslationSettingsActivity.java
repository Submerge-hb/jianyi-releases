package com.jianyi.translator;

import android.app.*;
import android.content.*;
import android.graphics.Insets;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.util.concurrent.*;

/** User-configured personal account; no shared public API key. */
public final class TranslationSettingsActivity extends Activity {
    private TranslationAccount account;
    private EditText id,secret,remaining;
    private CheckBox consent;
    private TextView status,usage;
    private Button save,test,remove,toggle,cancel;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private OnlineTranslator request;
    private Future<?> task;
    private int generation;
    private boolean busy;
    @Override public void onCreate(Bundle state){
        super.onCreate(state);getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        if(Build.VERSION.SDK_INT>=30)getWindow().setDecorFitsSystemWindows(false);
        account=new TranslationAccount(this);
        LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setBackgroundColor(MainActivity.PAPER);if(Build.VERSION.SDK_INT>=29)outer.setForceDarkAllowed(false);setContentView(outer);
        outer.setOnApplyWindowInsetsListener((v,insets)->{if(Build.VERSION.SDK_INT>=30){Insets b=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout()|WindowInsets.Type.ime());v.setPadding(b.left,b.top,b.right,b.bottom);}else v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;});
        ScrollView scroll=new ScrollView(this);outer.addView(scroll);LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(24),dp(16),dp(24),dp(28));scroll.addView(body);
        add(body,button("‹ 返回轻语",()->finish()));add(body,label("翻译服务",25));
        add(body,label("百度通用翻译 · 个人高级版\n先在官方平台完成个人认证，开通通用文本翻译高级版，再填写自己的 APP ID 和密钥。",14));
        add(body,button("打开百度官方控制台",()->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://fanyi-api.baidu.com/")));}catch(ActivityNotFoundException e){status.setText(R.string.baidu_no_browser);}}));
        add(body,label("APP ID",14));id=field("填写个人 APP ID",InputType.TYPE_CLASS_NUMBER);id.setTag("baidu-app-id");add(body,id);
        add(body,label("密钥",14));secret=field("填写密钥（留空保留已保存密钥）",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);secret.setTag("baidu-secret");secret.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);add(body,secret);
        add(body,label("平台本月剩余免费字符",14));remaining=field("请核对平台后填写，每月重新确认",InputType.TYPE_CLASS_NUMBER);remaining.setTag("baidu-remaining");add(body,remaining);
        consent=new CheckBox(this);consent.setText("我已核对高级版及本月剩余免费额度，同意点击翻译时把文字发送给百度。凭据只保存在本机。请勿提交敏感内容。");consent.setTextColor(MainActivity.INK);consent.setSaveEnabled(false);consent.setTag("baidu-consent");add(body,consent);
        save=button("保存并启用",this::save);save.setTag("baidu-save");add(body,save);
        usage=label("",13);usage.setTag("baidu-usage");add(body,usage);
        add(body,label("本机每月最多调用 10 万字符，并从你填写的剩余额度中预留 1000 字符。发送后超时或取消仍保守计入。\n\n本机估算，非平台账单；其他设备调用、清除应用数据或重装可能影响统计。无需开启自动充值；余额为零也不保证自动停服，请同时关注平台用量。",12));
        test=button("测试连接 · 发送一条示例句",this::test);test.setTag("baidu-test");add(body,test);
        toggle=button("关闭联网翻译",()->{TranslationPolicy.consent(this,-1);status.setText("已关闭联网翻译；保存配置可重新启用。");refresh();});add(body,toggle);
        remove=button("删除本机凭据",()->new AlertDialog.Builder(this).setTitle("删除翻译凭据？").setMessage("将停止联网翻译，保留收藏、历史和用量记录。").setNegativeButton("取消",null).setPositiveButton("删除",(d,w)->{try{account.delete();TranslationPolicy.consent(this,-1);id.setText("");secret.setText("");remaining.setText("");consent.setChecked(false);status.setText("已删除凭据，用量记录保留。");refresh();}catch(Exception e){status.setText(NetworkErrors.message(e,"配置"));}}).show());add(body,remove);
        cancel=button("取消测试",this::cancelTest);cancel.setVisibility(View.GONE);add(body,cancel);
        status=label("",14);status.setTag("baidu-status");add(body,status);
        if(account.configured())try{id.setText(account.read().appId);}catch(Exception e){status.setText(e.getMessage());}
        refresh();outer.requestApplyInsets();
    }
    private int dp(int x){return Math.round(x*getResources().getDisplayMetrics().density);}
    private TextView label(String value,int size){TextView v=new TextView(this);v.setText(value);v.setTextSize(size);v.setTextColor(MainActivity.INK);v.setLineSpacing(dp(4),1);return v;}
    private EditText field(String hint,int type){EditText v=new EditText(this);v.setHint(hint);v.setSingleLine(true);v.setInputType(type);v.setTextSize(15);v.setTextColor(MainActivity.INK);v.setSaveEnabled(false);return v;}
    private Button button(String value,Runnable action){Button b=new Button(this);b.setText(value);b.setTextColor(MainActivity.GREEN);b.setAllCaps(false);b.setMinHeight(dp(48));GradientDrawable d=new GradientDrawable();d.setColor(MainActivity.PALE);d.setCornerRadius(dp(16));b.setBackground(d);b.setOnClickListener(v->{if(!busy||b==cancel)action.run();});return b;}
    private void add(LinearLayout body,View v){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(14);body.addView(v,p);}
    private void refresh(){
        try{TranslationAccount.Credentials c=account.read();usage.setText(getString(R.string.baidu_usage,TranslationAccount.month(),account.used(c.appId),account.budget(c.appId),account.confirmed(c.appId)?"已核对本月额度":"本月额度待核对",TranslationPolicy.consent(this)>0?"联网已开启":"联网已关闭"));}catch(Exception e){usage.setText("尚未配置 · 仍可使用离线词典和已保存译文");}
        test.setEnabled(!busy&&account.configured()&&TranslationPolicy.consent(this)>0);toggle.setEnabled(!busy&&TranslationPolicy.consent(this)>0);remove.setEnabled(!busy&&account.configured());save.setEnabled(!busy);cancel.setVisibility(busy?View.VISIBLE:View.GONE);
    }
    private void save(){
        if(!consent.isChecked()){status.setText("请先核对平台额度并勾选说明。");return;}
        String appId=id.getText().toString().trim(),key=secret.getText().toString().trim();long quota;
        try{quota=Long.parseLong(remaining.getText().toString().trim());if(key.isEmpty()&&account.configured()){TranslationAccount.Credentials old=account.read();if(old.appId.equals(appId))key=old.secret;}}catch(Exception e){status.setText(R.string.baidu_remaining_required);return;}
        final String value=key;busy=true;refresh();cancel.setVisibility(View.GONE);status.setText("正在安全保存…");int token=++generation;
        task=worker.submit(()->{String error=null;try{account.save(appId,value,quota);TranslationPolicy.consent(this,1);}catch(Exception e){error=NetworkErrors.message(e,"配置");}final String result=error;runOnUiThread(()->{if(isDestroyed()||isFinishing()||token!=generation)return;busy=false;secret.setText("");remaining.setText("");consent.setChecked(false);status.setText(result==null?"已保存。可测试连接，然后返回翻译。":result);refresh();});});
    }
    private void test(){
        if(!TranslationPolicy.connected(this)){status.setText("当前无可用网络，请连接后测试。");return;}
        busy=true;refresh();status.setText(R.string.baidu_testing);int token=++generation;request=new OnlineTranslator(this);OnlineTranslator current=request;
        task=worker.submit(()->{String result;long begin=SystemClock.elapsedRealtime();try{DictionaryRepository.Result r=current.translate("I want to eat beef",false);result="连接成功 · "+(SystemClock.elapsedRealtime()-begin)+" 毫秒\n示例译文："+r.chinese+"\n请确认含义完整（包含“牛肉”）。";}catch(Exception e){result=NetworkErrors.message(e,"翻译");}finally{current.close();}final String message=result;runOnUiThread(()->{if(isDestroyed()||isFinishing()||token!=generation)return;busy=false;request=null;status.setText(message);refresh();});});
    }
    private void cancelTest(){generation++;if(request!=null){request.close();request=null;}if(task!=null)task.cancel(true);busy=false;status.setText("已取消；已发送的请求仍计入本机用量。");refresh();}
    @Override protected void onStop(){super.onStop();if(request!=null)cancelTest();}
    @Override protected void onDestroy(){generation++;if(request!=null)request.close();worker.shutdownNow();super.onDestroy();}
}
