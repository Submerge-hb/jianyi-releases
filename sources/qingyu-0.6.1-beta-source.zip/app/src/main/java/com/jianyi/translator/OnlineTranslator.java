package com.jianyi.translator;
import android.content.Context;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.*;

/** Baidu HTTPS adapter. Never logs credentials, signatures or submitted text. */
class OnlineTranslator implements AutoCloseable {
    static final String PROVIDER="baidu-v1";
    static final int FORMAT=1,MAX_BYTES=6000;
    private static final ScheduledExecutorService TIMER=Executors.newSingleThreadScheduledExecutor(r->{Thread t=new Thread(r,"translation-deadline");t.setDaemon(true);return t;});
    interface ConnectionFactory {HttpURLConnection open()throws IOException;}
    interface Reservation {void reserve(String text)throws IOException;}
    private final TranslationAccount account;
    private final ConnectionFactory factory;
    private final TranslationAccount.Credentials testCredentials;
    private final Reservation testReservation;
    private final long timeoutMs;
    private volatile HttpURLConnection active;
    private volatile boolean cancelled,timedOut;
    OnlineTranslator(){account=null;factory=null;testCredentials=null;testReservation=null;timeoutMs=8000;}
    OnlineTranslator(Context c){account=new TranslationAccount(c);factory=()->(HttpURLConnection)new URL("https://fanyi-api.baidu.com/api/trans/vip/translate").openConnection();testCredentials=null;testReservation=null;timeoutMs=8000;}
    OnlineTranslator(ConnectionFactory f,TranslationAccount.Credentials c,Reservation r,long timeout){account=null;factory=f;testCredentials=c;testReservation=r;timeoutMs=timeout;}
    private void checkCancelled()throws IOException {if(timedOut)throw new SocketTimeoutException("翻译连接超时，请切换网络后重试。");if(cancelled||Thread.currentThread().isInterrupted())throw new InterruptedIOException("已取消");}
    public void close(){cancelled=true;HttpURLConnection c=active;if(c!=null)c.disconnect();}
    static void validate(String text)throws IOException {
        if(text.trim().isEmpty())throw new NetworkErrors.Failure("请先输入需要翻译的内容");
        if(text.length()>1000||text.getBytes(StandardCharsets.UTF_8).length>MAX_BYTES)throw new NetworkErrors.Failure("每次最多翻译 1000 字符，请缩短后重试。");
    }
    static String signature(String id,String text,String salt,String key)throws IOException {try{return UpdateClient.hex(MessageDigest.getInstance("MD5").digest((id+text+salt+key).getBytes(StandardCharsets.UTF_8)));}catch(Exception e){throw new NetworkErrors.Failure("无法准备翻译请求。");}}
    private static String encode(String s)throws UnsupportedEncodingException{return URLEncoder.encode(s,"UTF-8");}
    DictionaryRepository.Result translate(String text,boolean chinese)throws IOException {
        validate(text);checkCancelled();
        TranslationAccount.Credentials credentials=testCredentials!=null?testCredentials:account==null?null:account.read();
        if(credentials==null)throw new NetworkErrors.Failure("请先配置百度翻译服务。");
        String salt=UUID.randomUUID().toString();
        String body="q="+encode(text)+"&from="+(chinese?"zh":"en")+"&to="+(chinese?"en":"zh")+"&appid="+encode(credentials.appId)+"&salt="+encode(salt)+"&sign="+signature(credentials.appId,text,salt,credentials.secret);
        HttpURLConnection c=factory.open();active=c;
        c.setRequestMethod("POST");c.setDoOutput(true);c.setInstanceFollowRedirects(false);c.setUseCaches(false);c.setConnectTimeout(3000);c.setReadTimeout(5000);
        c.setRequestProperty("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");c.setRequestProperty("Accept-Encoding","identity");
        byte[] request=body.getBytes(StandardCharsets.UTF_8);c.setFixedLengthStreamingMode(request.length);
        ScheduledFuture<?> deadline=TIMER.schedule(()->{timedOut=true;c.disconnect();},timeoutMs,TimeUnit.MILLISECONDS);
        try {
            checkCancelled();if(testReservation!=null)testReservation.reserve(text);else account.reserve(credentials.appId,text);checkCancelled();
            try(OutputStream out=c.getOutputStream()){out.write(request);}
            int status=c.getResponseCode();checkCancelled();
            if(status==429)throw new NetworkErrors.Failure("翻译请求过于频繁，请稍后重试。");
            if(status!=200)throw new NetworkErrors.Failure("翻译服务暂不可用（"+status+"），请稍后重试。");
            try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){
                byte[] buffer=new byte[4096];int n;while((n=in.read(buffer))!=-1){checkCancelled();if(out.size()+n>262144)throw new NetworkErrors.Failure("翻译返回数据过大，请重试。");out.write(buffer,0,n);}
                checkCancelled();return parse(out.toString("UTF-8"),text,chinese);
            }
        }catch(IOException e){checkCancelled();throw new NetworkErrors.Failure(NetworkErrors.message(e,"翻译"),e);}
        finally{deadline.cancel(false);c.disconnect();active=null;}
    }
    private static String coverage(String s){return s.replaceAll("[\\s\\p{Z}]+","");}
    static DictionaryRepository.Result parse(String json,String text,boolean chinese)throws IOException {
        try {
            JSONObject data=new JSONObject(json);
            if(data.has("error_code")){
                String code=data.optString("error_code");
                switch(code){
                    case "52003":case "54001":case "58000":case "58002":throw new NetworkErrors.Failure("百度翻译凭据或服务权限异常，请检查 APP ID、密钥及服务开通状态（"+code+"）。");
                    case "54003":case "54005":throw new NetworkErrors.Failure("百度翻译请求频繁，请稍后重试（"+code+"）。");
                    case "54004":throw new NetworkErrors.Failure("百度账号可用额度或余额不足，已停止联网，请核对平台用量。");
                    default:throw new NetworkErrors.Failure("百度翻译未完成请求（"+(code.matches("[0-9]{1,8}")?code:"未知状态")+"），请稍后重试。");
                }
            }
            if(!(chinese?"zh":"en").equals(data.optString("from"))||!(chinese?"en":"zh").equals(data.optString("to")))throw new NetworkErrors.Failure("翻译方向不匹配，请重试。");
            JSONArray rows=data.getJSONArray("trans_result");if(rows.length()==0||rows.length()>1000)throw new NetworkErrors.Failure("服务没有返回完整译文，请重试。");
            StringBuilder sources=new StringBuilder(),translated=new StringBuilder();int cursor=0;
            for(int i=0;i<rows.length();i++){
                JSONObject row=rows.getJSONObject(i);String src=row.getString("src"),dst=row.getString("dst").trim();
                if(src.trim().isEmpty()||dst.isEmpty())throw new NetworkErrors.Failure("服务返回的译文有缺失，请重试。");
                if(i>0){int found=text.indexOf(src,cursor);String gap=found>=cursor?text.substring(cursor,found):"";long lines=gap.chars().filter(v->v=='\n').count();translated.append("\n".repeat((int)Math.max(1,Math.min(lines,1000))));}
                int found=text.indexOf(src,cursor);if(found>=0)cursor=found+src.length();
                sources.append(src);translated.append(dst);
            }
            if(!coverage(sources.toString()).equals(coverage(text))||translated.length()>20000)throw new NetworkErrors.Failure("服务返回的原文覆盖不完整，已停止保存，请重试。");
            DictionaryRepository.Result r=new DictionaryRepository.Result();r.source="百度翻译 · 联网";r.provider=PROVIDER;r.formatVersion=FORMAT;r.fetchedAt=System.currentTimeMillis();
            r.chinese=chinese?text:translated.toString();r.english=chinese?translated.toString():text;return r;
        }catch(JSONException e){throw new NetworkErrors.Failure("翻译服务返回格式异常，请稍后重试。");}
    }
}
