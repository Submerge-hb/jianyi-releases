package com.jianyi.translator;

import android.content.*;
import android.net.*;

/** Network state is a hint; request failures still fall back to local results. */
final class TranslationPolicy {
    static boolean connected(Context context) {
        ConnectivityManager cm=(ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkCapabilities c=cm.getNetworkCapabilities(cm.getActiveNetwork());
        // Some networks block Android's validation host while the translation endpoint works.
        // A connected Internet-capable transport gets one bounded request; failure falls back.
        return c!=null&&c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
    }
    static int consent(Context c){return c.getSharedPreferences("jianyi-settings",0).getInt("baidu-consent-v1",0);}
    static void consent(Context c,int choice){c.getSharedPreferences("jianyi-settings",0).edit().putInt("baidu-consent-v1",choice).apply();}
    static boolean shouldRequest(boolean connected,int consent){return connected&&consent>0;}
}
