package com.jianyi.translator;

import android.app.*;
import android.content.*;
import android.graphics.Insets;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.util.*;
import java.util.concurrent.*;

public final class VoiceActivity extends Activity {
    private LinearLayout body;
    private TextView status;
    private ProgressBar progress;
    private Button cancel;
    private final List<Button> actions=new ArrayList<>();
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private VoiceStore request;
    private Future<?> task;
    private SpeechPlayer speech;
    private int generation;
    private boolean busy;
    @Override public void onCreate(Bundle state){
        super.onCreate(state);speech=new SpeechPlayer(this);
        if(Build.VERSION.SDK_INT>=30)getWindow().setDecorFitsSystemWindows(false);
        LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setBackgroundColor(MainActivity.PAPER);
        if(Build.VERSION.SDK_INT>=29)outer.setForceDarkAllowed(false);
        setContentView(outer);
        outer.setOnApplyWindowInsetsListener((v,insets)->{
            if(Build.VERSION.SDK_INT>=30){Insets bars=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());v.setPadding(bars.left,bars.top,bars.right,bars.bottom);}
            else v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;
        });
        ScrollView scroll=new ScrollView(this);body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(24),dp(16),dp(24),dp(24));scroll.addView(body);outer.addView(scroll);render();outer.requestApplyInsets();
    }
    private int dp(int x){return Math.round(x*getResources().getDisplayMetrics().density);}
    private TextView label(String text,int size){TextView t=new TextView(this);t.setText(text);t.setTextSize(size);t.setTextColor(MainActivity.INK);t.setLineSpacing(dp(4),1);return t;}
    private Button button(String text){Button b=new Button(this);b.setText(text);b.setAllCaps(false);b.setTextColor(MainActivity.GREEN);b.setMinHeight(dp(50));GradientDrawable d=new GradientDrawable();d.setColor(MainActivity.PALE);d.setCornerRadius(dp(16));b.setBackground(d);return b;}
    private void add(LinearLayout parent,View view,int margin){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(margin);parent.addView(view,p);}
    private void render(){
        body.removeAllViews();actions.clear();
        Button back=button("‹  返回轻语");back.setOnClickListener(v->finish());add(body,back,0);
        add(body,label("把声音，留在手机里。",25),24);
        add(body,label("英美语音分别下载。准备好后，英文单词和句子都能断网朗读。",14),12);
        for(VoiceStore.Pack pack:VoiceStore.PACKS){
            boolean ready=VoiceStore.ready(this,pack);
            boolean legacy=pack==VoiceStore.UK&&!ready&&VoiceStore.ready(this,VoiceStore.LEGACY_UK);
            LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(18),dp(18),dp(18),dp(18));GradientDrawable d=new GradientDrawable();d.setColor(MainActivity.WHITE);d.setCornerRadius(dp(22));card.setBackground(d);
            add(card,label(pack.name,20),0);
            add(card,label(ready?"已下载 · 可离线朗读":String.format(Locale.CHINA,legacy?"新版约 %.1f MB · 旧声音仍可用":"下载约 %.1f MB · 未下载",pack.bytes/1000000.0),13),8);
            add(card,label(pack==VoiceStore.UK?"Cori · 英式女声":"LJ Speech · 美式女声",12),8);
            Button primary=button(ready?"试听发音":legacy?"更新英式语音":"下载语音包");primary.setTag("voice-download-"+pack.id);
            primary.setOnClickListener(v->{if(ready)speech.speak("Hello. Let's learn something new today.",pack==VoiceStore.UK?Locale.UK:Locale.US,v);else confirm(pack);});actions.add(primary);add(card,primary,16);
            if(ready||legacy){Button delete=button("删除语音包");delete.setTag("voice-delete-"+pack.id);delete.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("删除"+pack.name+"语音包？").setMessage("删除后可重新下载，收藏与历史不会受到影响。").setNegativeButton("取消",null).setPositiveButton("删除",(a,b)->remove(pack)).show());actions.add(delete);add(card,delete,8);}
            add(body,card,20);
        }
        status=label("建议连接 Wi-Fi 下载，安装时预留至少 300 MB 空间。下载期间请保持本页打开；离开本页会取消下载，可重新开始。",12);status.setTag("voice-status");add(body,status,20);
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setVisibility(View.GONE);add(body,progress,12);
        cancel=button("取消下载");cancel.setTag("voice-cancel");cancel.setVisibility(View.GONE);cancel.setOnClickListener(v->{if(request!=null)request.close();cancel.setEnabled(false);status.setText("正在取消并清理…");});add(body,cancel,12);
        add(body,label("语音由手机本地生成，不会上传朗读文字。语音模型来自 sherpa-onnx / Piper，下载地址为 GitHub；来源与许可可在设置的“关于与数据许可”查看。",12),20);
    }
    private void confirm(VoiceStore.Pack pack){
        new AlertDialog.Builder(this).setTitle("下载"+pack.name+"语音包？")
            .setMessage(String.format(Locale.CHINA,"需要下载约 %.1f MB，可能使用移动流量。下载完成后即可离线朗读。",pack.bytes/1000000.0)+(pack==VoiceStore.UK&&VoiceStore.ready(this,VoiceStore.LEGACY_UK)?" 新声音安装成功后会替换并清理旧英式包，失败时继续使用旧包。":""))
            .setNegativeButton("取消",null).setPositiveButton("开始下载",(d,w)->download(pack)).show();
    }
    private void setBusy(){busy=true;for(Button b:actions)b.setEnabled(false);progress.setVisibility(View.VISIBLE);progress.setIndeterminate(true);}
    private void post(int token,Runnable r){runOnUiThread(()->{if(!isDestroyed()&&!isFinishing()&&generation==token)r.run();});}
    private void download(VoiceStore.Pack pack){
        if(busy)return;speech.stop();setBusy();cancel.setVisibility(View.VISIBLE);cancel.setEnabled(true);status.setText("正在连接语音包下载地址…");
        int token=++generation;VoiceStore client=new VoiceStore();request=client;
        task=worker.submit(()->{
            String error=null;
            try{
                client.download(this,pack,(message,percent)->post(token,()->{status.setText(message);progress.setIndeterminate(percent<0);if(percent>=0)progress.setProgress(percent);}));
                if(pack==VoiceStore.UK&&VoiceStore.ready(this,pack))SpeechEngine.get(this).exclusive(()->VoiceStore.erase(VoiceStore.root(this),VoiceStore.directory(this,VoiceStore.LEGACY_UK))).get();
            }
            catch(Exception ex){error=client.isCancelled()?"下载已取消，可重新开始":ex instanceof javax.net.ssl.SSLException?"无法验证下载服务器证书，请检查手机日期或更换网络后重试":ex instanceof java.net.UnknownHostException?"无法连接下载服务，请检查网络":ex instanceof java.net.SocketTimeoutException?"下载连接超时，请重试":ex instanceof java.io.InterruptedIOException?"下载已取消，可重新开始":ex instanceof java.io.IOException?ex.getMessage():"下载未完成，请稍后重试";}
            finally{client.close();}
            String result=error;
            post(token,()->{busy=false;request=null;task=null;render();status.setText(result==null?pack.name+"已准备好，点击“试听发音”试试。":result);});
        });
    }
    private void remove(VoiceStore.Pack pack){
        if(busy)return;speech.stop();setBusy();int token=++generation;
        worker.submit(()->{String error=null;try{SpeechEngine.get(this).exclusive(()->{VoiceStore.erase(VoiceStore.root(this),VoiceStore.directory(this,pack));if(pack==VoiceStore.UK)VoiceStore.erase(VoiceStore.root(this),VoiceStore.directory(this,VoiceStore.LEGACY_UK));}).get();}catch(Exception ex){error="删除未完成，请重试";}String result=error;post(token,()->{busy=false;render();status.setText(result==null?"语音包已删除":result);});});
    }
    @Override public void onBackPressed(){finish();}
    @Override protected void onStop(){speech.stop();super.onStop();}
    @Override protected void onDestroy(){generation++;if(request!=null)request.close();if(task!=null)task.cancel(true);worker.shutdownNow();speech.close();super.onDestroy();}
}
