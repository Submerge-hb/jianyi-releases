package com.jianyi.translator;

import android.content.*;
import android.security.keystore.*;
import android.util.Base64;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import org.json.JSONObject;

/** Device-only credentials; quota survives credential deletion and history clearing. */
final class TranslationAccount {
    static final int MONTHLY_LIMIT=100000;
    private static final String KEY="qingyu-baidu-credentials-v1";
    private static final Object LOCK=new Object();
    private final SharedPreferences prefs;
    static final class Credentials {
        final String appId,secret;
        Credentials(String id,String key){appId=id;secret=key;}
    }
    TranslationAccount(Context c){prefs=c.getApplicationContext().getSharedPreferences("qingyu-baidu-v1",0);}
    boolean configured(){return prefs.contains("cipher");}
    static String month(){SimpleDateFormat f=new SimpleDateFormat("yyyy-MM",Locale.ROOT);f.setTimeZone(TimeZone.getTimeZone("Asia/Shanghai"));return f.format(new Date());}
    private SecretKey key()throws Exception {
        KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);
        if(store.containsAlias(KEY))return (SecretKey)store.getKey(KEY,null);
        KeyGenerator g=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        g.init(new KeyGenParameterSpec.Builder(KEY,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());return g.generateKey();
    }
    Credentials read()throws IOException {
        synchronized(LOCK){try {
            if(!configured())throw new NetworkErrors.Failure("请先在设置中配置百度翻译服务。");
            Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(prefs.getString("iv",""),Base64.NO_WRAP)));
            JSONObject o=new JSONObject(new String(c.doFinal(Base64.decode(prefs.getString("cipher",""),Base64.NO_WRAP)),StandardCharsets.UTF_8));return new Credentials(o.getString("id"),o.getString("secret"));
        }catch(IOException e){throw e;}catch(Exception e){throw new NetworkErrors.Failure("无法读取本机凭据，请重新配置翻译服务。");}}
    }
    void save(String id,String secret,long remaining)throws IOException {
        if(!id.matches("[0-9]{5,40}")||secret.trim().isEmpty()||secret.length()>256)throw new NetworkErrors.Failure("请填写有效的 APP ID 和密钥。");
        if(remaining<0||remaining>1000000)throw new NetworkErrors.Failure("请填写平台本月剩余免费字符数（0—1000000）。");
        synchronized(LOCK){try{
            Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());
            byte[] encrypted=c.doFinal(new JSONObject().put("id",id).put("secret",secret).toString().getBytes(StandardCharsets.UTF_8));
            String prefix=prefix(id);long used=prefs.getLong(prefix+"used",0);
            long budget=Math.min(MONTHLY_LIMIT,used+Math.max(0,remaining-1000));
            if(!prefs.edit().putString("cipher",Base64.encodeToString(encrypted,Base64.NO_WRAP)).putString("iv",Base64.encodeToString(c.getIV(),Base64.NO_WRAP)).putBoolean(prefix+"confirmed",true).putLong(prefix+"budget",budget).commit())throw new NetworkErrors.Failure("无法保存翻译配置，请重试。");
        }catch(IOException e){throw e;}catch(Exception e){throw new NetworkErrors.Failure("无法安全保存凭据，请重试。");}}
    }
    void delete()throws IOException {synchronized(LOCK){if(!prefs.edit().remove("cipher").remove("iv").commit())throw new NetworkErrors.Failure("删除配置失败，请重试。");}}
    private static String prefix(String id){try{return UpdateClient.hex(MessageDigest.getInstance("SHA-256").digest(id.getBytes(StandardCharsets.UTF_8)))+":"+month()+":";}catch(Exception e){throw new IllegalStateException(e);}}
    long used(String id){synchronized(LOCK){return prefs.getLong(prefix(id)+"used",0);}}
    long budget(String id){synchronized(LOCK){return prefs.getLong(prefix(id)+"budget",0);}}
    boolean confirmed(String id){synchronized(LOCK){return prefs.getBoolean(prefix(id)+"confirmed",false);}}
    void reserve(String id,String text)throws IOException {
        synchronized(LOCK){String p=prefix(id);
            if(!prefs.getBoolean(p+"confirmed",false))throw new NetworkErrors.Failure("请在翻译服务设置中核对本月剩余免费额度并保存。");
            long used=prefs.getLong(p+"used",0),budget=prefs.getLong(p+"budget",0);
            // UTF-16 length conservatively counts supplementary characters twice.
            long amount=text.length();if(amount>budget-used)throw new NetworkErrors.Failure("已达到本机本月调用上限，已停止联网；离线内容仍可使用。");
            if(!prefs.edit().putLong(p+"used",used+amount).commit())throw new NetworkErrors.Failure("无法保存用量记录，已停止发送。");
        }
    }
}
