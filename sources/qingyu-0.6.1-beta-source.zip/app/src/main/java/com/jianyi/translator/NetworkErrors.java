package com.jianyi.translator;
import java.io.*;
import java.net.*;
import java.security.cert.CertificateException;
import javax.net.ssl.SSLException;

final class NetworkErrors {
    /** Only application-authored messages may be shown verbatim. */
    static final class Failure extends IOException {
        Failure(String message){super(message);}
        Failure(String message,Throwable cause){super(message,cause);}
    }
    static String message(Throwable error,String service){
        for(Throwable e=error;e!=null;e=e.getCause()){
            if(e instanceof SSLException||e instanceof CertificateException||e instanceof java.security.cert.CertPathValidatorException)
                return "无法验证"+service+"服务器的安全连接，请尝试切换网络"+(service.equals("更新")?"，或使用浏览器访问官方下载页面。":"后重试。");
            if(e instanceof android.system.ErrnoException && ((android.system.ErrnoException)e).errno==android.system.OsConstants.ENOSPC)return "手机存储空间不足，请清理后重试。";
            if(e instanceof SocketTimeoutException)return "连接"+service+"服务超时，请切换网络后重试。";
            if(e instanceof UnknownHostException||e instanceof ConnectException||e instanceof NoRouteToHostException)return "无法连接"+service+"服务，请检查网络或切换网络后重试。";
        }
        return error instanceof Failure&&error.getMessage()!=null?error.getMessage():service+"暂时失败，请稍后重试。";
    }
    static String diagnostic(Throwable e){StringBuilder s=new StringBuilder();int n=0;while(e!=null&&n++<5){if(s.length()>0)s.append(" → ");s.append(e.getClass().getSimpleName());e=e.getCause();}return s.toString();}
}
