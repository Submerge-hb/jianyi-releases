package com.jianyi.translator;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.View;
import android.widget.*;
import com.k2fsa.sherpa.onnx.OfflineTts;
import java.util.*;

/** Page-owned UI facade; the shared engine only keeps a weak listener reference. */
final class SpeechPlayer {
    private final Activity activity;
    private final SpeechEngine engine;
    private final Handler main=new Handler(Looper.getMainLooper());
    private SpeechEngine.Job job;
    private SpeechEngine.Listener listener;
    private View button;
    private CharSequence label,description;
    private boolean closed;
    private int generation;
    SpeechPlayer(Activity activity){this.activity=activity;engine=SpeechEngine.get(activity);}
    static OfflineTts create(Context c,VoiceStore.Pack p){return SpeechEngine.create(c,p);}
    void prewarm(){if(!closed)engine.prewarm();}
    void speak(String text,Locale locale){speak(text,locale,null);}
    void speak(String text,Locale locale,View source){
        if(closed||text==null||text.trim().isEmpty())return;
        VoiceStore.Pack pack=VoiceStore.available(activity,locale);
        if(!VoiceStore.ready(activity,pack)){
            new AlertDialog.Builder(activity).setTitle("下载"+pack.name+"语音包")
                .setMessage("下载一次后，就能离线朗读英文单词和句子，无需安装手机系统语音。可在语音包页面试听、管理和删除。")
                .setNegativeButton("稍后",null).setPositiveButton("管理语音包",(d,w)->activity.startActivity(new Intent(activity,VoiceActivity.class))).show();return;
        }
        if(text.length()>5000){Toast.makeText(activity,"内容过长，请分段朗读",Toast.LENGTH_SHORT).show();return;}
        stop();int ticket=++generation;button=source;
        if(source!=null){description=source.getContentDescription();label=source instanceof TextView?((TextView)source).getText():null;}
        listener=new SpeechEngine.Listener(){
            @Override public void state(String state){
                if(closed||ticket!=generation)return;
                if(state.equals("preparing"))main.postDelayed(()->{if(!closed&&ticket==generation&&job!=null&&!job.done.isDone()&&job.metrics.firstOutputMs<0)preparing();},150);
                else restore();
            }
            @Override public void failed(){if(!closed&&ticket==generation&&!activity.isFinishing()){
                restore();new AlertDialog.Builder(activity).setTitle("暂时无法朗读").setMessage("请检查媒体音量；若仍无法播放，可在语音包管理中删除并重新下载。").setPositiveButton("知道了",null).show();
            }}
        };
        job=engine.speak(text,pack,listener);
    }
    private void preparing(){
        if(button==null)return;
        button.setContentDescription("正在准备发音");
        if(button instanceof TextView)((TextView)button).setText("准备中…");
        View progress=button.findViewWithTag("speech-progress"),icon=button.findViewWithTag("speech-icon");
        if(progress!=null)progress.setVisibility(View.VISIBLE);if(icon!=null)icon.setVisibility(View.INVISIBLE);
    }
    private void restore(){
        if(button==null)return;
        if(button instanceof TextView&&label!=null)((TextView)button).setText(label);
        button.setContentDescription(description);
        View progress=button.findViewWithTag("speech-progress"),icon=button.findViewWithTag("speech-icon");
        if(progress!=null)progress.setVisibility(View.GONE);if(icon!=null)icon.setVisibility(View.VISIBLE);
    }
    void stop(){generation++;if(job!=null)engine.cancel(job);job=null;listener=null;restore();button=null;}
    void close(){stop();closed=true;main.removeCallbacksAndMessages(null);}
    static List<String> segments(String text){
        List<String> result=new ArrayList<>();
        for(String sentence:text.trim().split("(?<=[.!?;])\\s+")){
            while(sentence.length()>200){int end=sentence.lastIndexOf(' ',200);if(end<1)end=200;result.add(sentence.substring(0,end));sentence=sentence.substring(end).trim();}
            if(!sentence.isEmpty())result.add(sentence);
        }return result;
    }
}
