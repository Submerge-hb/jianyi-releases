package com.jianyi.translator;

import android.app.*;
import android.os.*;
import android.content.ComponentCallbacks2;

/** Keeps one voice model across in-app navigation, but never keeps it in the background. */
public final class QingyuApplication extends Application implements Application.ActivityLifecycleCallbacks {
    private int started;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable background=()->{if(started==0)SpeechEngine.get(this).suspend();};
    @Override public void onCreate(){super.onCreate();registerActivityLifecycleCallbacks(this);}
    @Override public void onActivityStarted(Activity a){started++;handler.removeCallbacks(background);}
    @Override public void onActivityStopped(Activity a){started=Math.max(0,started-1);if(started==0)handler.postDelayed(background,300);}
    @Override public void onTrimMemory(int level){super.onTrimMemory(level);if(level>=ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW)SpeechEngine.get(this).suspend();}
    @Override public void onLowMemory(){super.onLowMemory();SpeechEngine.get(this).suspend();}
    @Override public void onActivityCreated(Activity a,Bundle state){}
    @Override public void onActivityResumed(Activity a){}
    @Override public void onActivityPaused(Activity a){}
    @Override public void onActivitySaveInstanceState(Activity a,Bundle state){}
    @Override public void onActivityDestroyed(Activity a){}
}
