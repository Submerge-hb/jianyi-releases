package com.jianyi.translator;

import android.app.Instrumentation;
import android.content.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

final class TranslationChecks {
    private int count;
    private interface Checked {void run()throws Exception;}
    private void ok(boolean value,String message){if(!value)throw new AssertionError(message);count++;}
    private void rejects(Checked task,String message)throws Exception {boolean rejected=false;try{task.run();}catch(IOException e){rejected=true;}ok(rejected,message);}
    static String response(String[] sources,String[] translations,boolean chinese)throws Exception {
        JSONArray rows=new JSONArray();for(int i=0;i<sources.length;i++)rows.put(new JSONObject().put("src",sources[i]).put("dst",translations[i]));
        return new JSONObject().put("from",chinese?"zh":"en").put("to",chinese?"en":"zh").put("trans_result",rows).toString();
    }
    static DictionaryRepository.Result result(String q,String translated)throws Exception{return OnlineTranslator.parse(response(new String[]{q},new String[]{translated},false),q,false);}
    static int run(Instrumentation runner)throws Exception{return new TranslationChecks().test(runner.getTargetContext());}
    private int test(Context context)throws Exception {
        OnlineTranslator.validate("汉".repeat(1000));ok(true,"1000 Chinese characters accepted");rejects(()->OnlineTranslator.validate("x".repeat(1001)),"limit enforced without truncation");
        String[][] samples={{"I want to eat beef","我想吃牛肉"},{"I do not want to eat beef.","我不想吃牛肉。"},{"Alice bought 12 books for $30.","爱丽丝花30美元买了12本书。"},{"First sentence. Second sentence.","第一句话。第二句话。"},{"<literal> & text","<字面内容> & 文字"}};
        for(String[] pair:samples){DictionaryRepository.Result r=result(pair[0],pair[1]);ok(r.chinese.equals(pair[1])&&r.english.equals(pair[0]),"complete fixture round trip: "+pair[0]);}
        String zh="他在银行工作，周末步行去公园。";DictionaryRepository.Result Chinese=OnlineTranslator.parse(response(new String[]{zh},new String[]{"He works at a bank and walks to the park on weekends."},true),zh,true);ok(Chinese.chinese.equals(zh)&&Chinese.english.endsWith("weekends."),"Chinese context preserved");
        String q="I want beef.\n\nShe wants tea.";String multi=response(new String[]{"I want beef.","She wants tea."},new String[]{"我想要牛肉。","她想要茶。"},false);
        ok(OnlineTranslator.parse(multi,q,false).chinese.equals("我想要牛肉。\n\n她想要茶。"),"all paragraphs and blank line preserved");
        rejects(()->OnlineTranslator.parse(response(new String[]{"I want to eat"},new String[]{"我想吃"},false),"I want to eat beef",false),"observed truncated-source regression rejected");
        rejects(()->OnlineTranslator.parse(response(new String[]{"I want beef."},new String[]{"我想要牛肉。"},false),q,false),"missing paragraph rejected");
        rejects(()->OnlineTranslator.parse(response(new String[]{"She wants tea.","I want beef."},new String[]{"茶","牛肉"},false),q,false),"reordered source rejected");
        rejects(()->OnlineTranslator.parse(response(new String[]{"test"},new String[]{""},false),"test",false),"empty translation rejected");
        rejects(()->OnlineTranslator.parse(multi,q,true),"wrong direction rejected");
        for(String code:new String[]{"52003","54001","54003","54004","54005","58002"})rejects(()->OnlineTranslator.parse("{\"error_code\":\""+code+"\"}","test",false),"provider error "+code);
        rejects(()->OnlineTranslator.parse("not json","test",false),"invalid JSON rejected");
        ok(OnlineTranslator.signature("2015063000000001","apple","1435660288","12345678").equals("f89f9594663708c1605f3d736d01d2d4"),"official signing vector");
        SharedPreferences localPrefs=context.getSharedPreferences("jianyi-local-v1",0);localPrefs.edit().clear().commit();
        LocalStore store=new LocalStore(context);DictionaryRepository.Result r=result("US","美国");store.record("US",false,r);
        ok(store.fresh("US",false,System.currentTimeMillis())!=null,"fresh exact cache hit");ok(store.fresh("us",false,System.currentTimeMillis())==null,"case sensitive cache");ok(store.fresh("US",true,System.currentTimeMillis())==null,"direction isolated");
        ok(store.fresh("US",false,r.fetchedAt+8L*24*60*60*1000)==null,"expired cache excluded");ok(store.fresh("US",false,r.fetchedAt-1)==null,"future timestamp excluded");
        r.formatVersion=99;store.record("US",false,r);ok(store.fresh("US",false,System.currentTimeMillis())==null,"format isolated");
        r=result("US","美国");store.record("US",false,r);store.toggle("US",false);store.clearHistory();ok(store.fresh("US",false,System.currentTimeMillis())!=null,"favorite survives history clear");
        String legacy="[{\"q\":\"I want to eat beef\",\"zh\":false,\"time\":1,\"en\":\"I want to eat beef\",\"cn\":\"我想吃\"}]";
        localPrefs.edit().putString("history",legacy).commit();ok(store.cached("I want to eat beef",false).source.contains("旧版"),"legacy remains readable and labeled");ok(store.fresh("I want to eat beef",false,System.currentTimeMillis())==null,"legacy not reused as new cache");
        ok(!new LocalStore.Entry("a\nb",false,0).key().equals(new LocalStore.Entry("a b",false,0).key()),"paragraph key distinct");
        SharedPreferences prefs=context.getSharedPreferences("qingyu-baidu-v1",0);prefs.edit().clear().commit();TranslationAccount account=new TranslationAccount(context);
        rejects(()->account.read(),"unconfigured blocked");account.save("123456789","test-secret-not-real",1000000);ok(account.read().secret.equals("test-secret-not-real"),"Keystore round trip");
        ok(!prefs.getAll().toString().contains("test-secret-not-real"),"no plaintext secret in preferences");
        ok(account.budget("123456789")==100000,"monthly ceiling");account.reserve("123456789","abc");ok(account.used("123456789")==3,"reservation persisted");store.clearHistory();ok(account.used("123456789")==3,"history clear retains usage");account.delete();ok(!account.configured()&&account.used("123456789")==3,"credential deletion retains ledger");
        account.save("123456789","another-test-key",1002);ok(account.used("123456789")==3&&account.budget("123456789")==5,"resave retains count and remaining margin");account.reserve("123456789","ab");rejects(()->account.reserve("123456789","c"),"over quota blocked");
        account.save("987654321","second-test-key",1000000);ok(account.used("987654321")==0&&account.used("123456789")==5,"accounts isolated without erasing old usage");
        rejects(()->account.reserve("111111111","test"),"unconfirmed month/account blocked");
        AtomicInteger reserved=new AtomicInteger();FakeConnection happy=new FakeConnection(response(new String[]{"tea"},new String[]{"茶"},false),false);
        try(OnlineTranslator client=new OnlineTranslator(()->happy,new TranslationAccount.Credentials("123456789","fake"),t->reserved.addAndGet(t.length()),8000)){ok(client.translate("tea",false).chinese.equals("茶"),"transport success");}
        ok(reserved.get()==3&&happy.written.toString("UTF-8").contains("q=tea")&&!happy.written.toString("UTF-8").contains("fake"),"signed form and quota before send");
        reserved.set(0);try(OnlineTranslator client=new OnlineTranslator(()->happy,new TranslationAccount.Credentials("123456789","fake"),t->reserved.incrementAndGet(),8000)){client.close();rejects(()->client.translate("tea",false),"cancel before send");}ok(reserved.get()==0,"unsent cancel no quota");
        FakeConnection wait=new FakeConnection("",true);long begin=System.nanoTime();try(OnlineTranslator client=new OnlineTranslator(()->wait,new TranslationAccount.Credentials("123456789","fake"),t->reserved.incrementAndGet(),150)){rejects(()->client.translate("tea",false),"whole request deadline");}ok((System.nanoTime()-begin)/1000000<1500&&reserved.get()==1,"timeout bounded and counted");
        FakeConnection denied=new FakeConnection("",false);try(OnlineTranslator client=new OnlineTranslator(()->denied,new TranslationAccount.Credentials("123456789","fake"),t->{throw new IOException("limit");},8000)){rejects(()->client.translate("tea",false),"quota denial before transport");}ok(denied.written.size()==0,"quota failure sends no text");
        FakeConnection cancelConnection=new FakeConnection("",true);OnlineTranslator cancellation=new OnlineTranslator(()->cancelConnection,new TranslationAccount.Credentials("123456789","fake"),t->{},8000);ExecutorService executor=Executors.newSingleThreadExecutor();Future<?> work=executor.submit(()->{try{cancellation.translate("tea",false);throw new AssertionError("cancel accepted as success");}catch(IOException expected){}});ok(cancelConnection.entered.await(2,TimeUnit.SECONDS),"request entered transport");cancellation.close();work.get(2,TimeUnit.SECONDS);executor.shutdownNow();ok(true,"inflight cancellation exits");
        IOException tls=new IOException("outer",new javax.net.ssl.SSLHandshakeException("secret URL must not be shown"));ok(NetworkErrors.message(tls,"更新").contains("安全连接"),"TLS explained");ok(!NetworkErrors.diagnostic(tls).contains("secret"),"diagnostics sanitized");ok(NetworkErrors.message(new SocketTimeoutException(),"更新").contains("超时"),"timeout explained");ok(NetworkErrors.message(new UnknownHostException(),"更新").contains("检查网络"),"DNS explained");
        ok(!NetworkErrors.message(new IOException("https://private.example/?secret=test"),"更新").contains("secret"),"unexpected transport details hidden");
        ok(NetworkErrors.message(new IOException("disk",new android.system.ErrnoException("write",android.system.OsConstants.ENOSPC)),"更新").contains("空间不足"),"disk full explained");
        prefs.edit().clear().commit();localPrefs.edit().clear().commit();TranslationPolicy.consent(context,-1);
        return count;
    }
    private static final class FakeConnection extends HttpURLConnection {
        final ByteArrayOutputStream written=new ByteArrayOutputStream();final CountDownLatch released=new CountDownLatch(1),entered=new CountDownLatch(1);final String response;final boolean wait;
        FakeConnection(String r,boolean w)throws Exception{super(new URL("https://fanyi-api.baidu.com/api/trans/vip/translate"));response=r;wait=w;}
        public void connect(){} public boolean usingProxy(){return false;}public void disconnect(){released.countDown();}
        public OutputStream getOutputStream(){return written;}
        public int getResponseCode(){return 200;}
        public InputStream getInputStream(){return new InputStream(){final ByteArrayInputStream bytes=new ByteArrayInputStream(response.getBytes(StandardCharsets.UTF_8));public int read()throws IOException{entered.countDown();if(wait){try{if(!released.await(3,TimeUnit.SECONDS))throw new IOException("test timed out");}catch(InterruptedException e){throw new InterruptedIOException();}throw new IOException("connection closed");}return bytes.read();}};}
    }
}
