package com.jianyi.translator;

import android.app.Instrumentation;
import android.content.*;
import android.os.*;
import android.media.*;
import com.k2fsa.sherpa.onnx.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;
import java.util.concurrent.*;

/** Real model/audio checks. No user history or favorites are read or modified. */
final class SpeechChecks {
    private int count;
    private final List<String> rows=new ArrayList<>();
    private void ok(boolean value,String message){if(!value)throw new AssertionError(message);count++;}
    private static final String[] WORDS={"judge","world","rural","clothes","thought","through","school","bank","light","right","computer","environment","dictionary","development","responsibility","beautiful","English","language","question","answer"};
    private SpeechEngine.Metrics play(SpeechEngine engine,VoiceStore.Pack pack,String text,String mode)throws Exception{
        SpeechEngine.Metrics m=engine.speak(text,pack,null).done.get(60,TimeUnit.SECONDS);
        engine.barrier().get(30,TimeUnit.SECONDS);
        ok(m.firstOutputMs>=0&&m.writtenSamples>0,"audio actually written: "+mode);
        ok(m.writtenSamples==m.referenceSamples,"callback audio not duplicated or truncated: "+mode);
        rows.add(pack.id+","+mode+","+text.replace(',',' ')+","+m.loadMs+","+m.generateMs+","+m.firstOutputMs+","+m.totalMs+","+m.cacheHit+","+m.writtenSamples);
        return m;
    }
    private void save(Context c,String name)throws Exception{
        File folder=c.getExternalFilesDir("qa");folder.mkdirs();
        List<String> csv=new ArrayList<>();csv.add("pack,mode,text,load_ms,generate_and_backpressure_ms,first_write_ms,total_ms,cache_hit,samples");csv.addAll(rows);
        Files.write(new File(folder,name+".csv").toPath(),csv,StandardCharsets.UTF_8);
    }
    static int functional(Instrumentation runner)throws Exception{return new SpeechChecks().checkEngine(runner);}
    private int checkEngine(Instrumentation runner)throws Exception{
        Context c=runner.getTargetContext();SpeechEngine e=SpeechEngine.get(c);
        ok(!TranslationPolicy.connected(c),"offline speech tests");
        ok(VoiceStore.ready(c,VoiceStore.UK)&&VoiceStore.ready(c,VoiceStore.US),"both models installed");
        ok(e==SpeechEngine.get(c.getApplicationContext()),"single application engine");
        e.suspend();e.barrier().get(30,TimeUnit.SECONDS);
        int before=e.modelLoads;
        play(e,VoiceStore.UK,"judge","cold");ok(e.modelLoads==before+1,"first model loaded once");
        play(e,VoiceStore.UK,"world","warm");ok(e.modelLoads==before+1,"new word reuses model");
        SpeechEngine.Metrics repeat=play(e,VoiceStore.UK,"world","repeat");
        ok(repeat.cacheHit&&repeat.generateMs==0&&e.modelLoads==before+1,"repeat uses PCM cache");
        SpeechEngine.Metrics us=play(e,VoiceStore.US,"world","switch-us");
        ok(!us.cacheHit&&e.modelLoads==before+2,"UK audio never reused for US");
        play(e,VoiceStore.UK,"world","cached-uk");ok(e.modelLoads==before+2,"cached UK needs no second model");
        SpeechEngine.Metrics sentence=play(e,VoiceStore.UK,"The judge walked through the school. Please listen to every word.","sentence");
        ok(sentence.chunks>=2,"sentence begins with first callback chunk");
        for(int i=0;i<12;i++)e.speak("This old request should be cancelled before the newest word.",VoiceStore.US,null);
        play(e,VoiceStore.UK,"thought","latest-wins");
        e.suspend();e.barrier().get(30,TimeUnit.SECONDS);ok(e.cachedBytes()==0,"background releases audio cache");
        c.getSharedPreferences("jianyi-settings",0).edit().putString("last-voice","uk").commit();
        before=e.modelLoads;e.prewarm();e.barrier().get(30,TimeUnit.SECONDS);
        ok(e.modelLoads==before+1,"prewarm loads selected voice");
        play(e,VoiceStore.UK,"through","prewarmed");ok(e.modelLoads==before+1,"prewarm reused on first tap");
        SpeechEngine.Job longJob=e.speak("The careful traveler carried a dictionary across the quiet village. ".repeat(25),VoiceStore.UK,null);
        for(int i=0;i<500&&longJob.metrics.firstOutputMs<0;i++)SystemClock.sleep(10);
        ok(longJob.metrics.firstOutputMs>=0,"long playback started");e.suspend();e.barrier().get(30,TimeUnit.SECONDS);
        ok(longJob.done.isCancelled(),"background cancels ongoing audio");
        play(e,VoiceStore.UK,"clothes","resume");
        runner.runOnMainSync(()->((QingyuApplication)c.getApplicationContext()).onTrimMemory(ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW));
        e.barrier().get(30,TimeUnit.SECONDS);ok(e.cachedBytes()==0,"low memory clears cache");
        before=e.modelLoads;play(e,VoiceStore.UK,"rural","after-trim");ok(e.modelLoads==before+1,"low memory released model");
        e.exclusive(()->{}).get(30,TimeUnit.SECONDS);ok(e.cachedBytes()==0,"file mutation waits for model release");
        before=e.modelLoads;play(e,VoiceStore.US,"judge","after-exclusive");ok(e.modelLoads==before+1,"exclusive access leaves no old model");
        ok(e.cachedBytes()<=SpeechEngine.CACHE_LIMIT,"cache bounded");
        save(c,"speech5-functional");return count;
    }
    static int benchmark(Instrumentation runner,int rounds)throws Exception{return new SpeechChecks().measure(runner,rounds);}
    private int measure(Instrumentation runner,int rounds)throws Exception{
        Context c=runner.getTargetContext();SpeechEngine e=SpeechEngine.get(c);
        ok(!TranslationPolicy.connected(c),"enable airplane mode and disable Wi-Fi before offline benchmarking");
        ok(VoiceStore.ready(c,VoiceStore.UK)&&VoiceStore.ready(c,VoiceStore.US),"download both new voice packs before benchmarking");
        android.content.SharedPreferences prefs=c.getSharedPreferences("jianyi-settings",0);
        String last=prefs.getString("last-voice",null);
        try{
            for(VoiceStore.Pack p:VoiceStore.PACKS){
                e.suspend();e.barrier().get(30,TimeUnit.SECONDS);
                for(int i=0;i<Math.min(rounds,6);i++)baseline(c,p,WORDS[i]);
                for(int i=0;i<rounds;i++){
                    e.suspend();e.barrier().get(30,TimeUnit.SECONDS);
                    play(e,p,WORDS[i%WORDS.length],"cold");
                    play(e,p,WORDS[(i+1)%WORDS.length],"warm");
                    play(e,p,WORDS[(i+1)%WORDS.length],"repeat");
                }
            }
        }finally{
            e.suspend();e.barrier().get(30,TimeUnit.SECONDS);
            android.content.SharedPreferences.Editor edit=prefs.edit();if(last==null)edit.remove("last-voice");else edit.putString("last-voice",last);edit.commit();
            save(c,"speech5-benchmark");
        }
        return count;
    }
    // Reconstruct the 0.4 reload -> full synthesis -> playback path with the SAME
    // installed model. This isolates pipeline changes; it is not an old-APK run.
    private void baseline(Context c,VoiceStore.Pack p,String word)throws Exception{
        long start=SystemClock.elapsedRealtime();OfflineTts tts=SpeechEngine.create(c,p);
        AudioTrack track=null;AudioManager manager=(AudioManager)c.getSystemService(Context.AUDIO_SERVICE);
        AudioAttributes attributes=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build();
        AudioFocusRequest focus=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK).setAudioAttributes(attributes).build();
        long loaded=SystemClock.elapsedRealtime()-start,generated,first=-1;
        try{
            long generateStart=SystemClock.elapsedRealtime();GeneratedAudio audio=tts.generate(word,p.speaker,0.95f);generated=SystemClock.elapsedRealtime()-generateStart;
            int rate=audio.getSampleRate();float[] samples=audio.getSamples();
            track=new AudioTrack.Builder().setAudioAttributes(attributes).setAudioFormat(new AudioFormat.Builder().setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).setEncoding(AudioFormat.ENCODING_PCM_FLOAT).build())
                .setTransferMode(AudioTrack.MODE_STREAM).setBufferSizeInBytes(Math.max(16384,AudioTrack.getMinBufferSize(rate,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_FLOAT))).build();
            if(manager.requestAudioFocus(focus)!=AudioManager.AUDIOFOCUS_REQUEST_GRANTED)throw new IOException("Baseline audio focus");
            track.play();int offset=0;
            while(offset<samples.length){int n=track.write(samples,offset,Math.min(4096,samples.length-offset),AudioTrack.WRITE_NON_BLOCKING);if(n<0)throw new IOException("Baseline playback");if(n==0){SystemClock.sleep(10);continue;}if(first<0)first=SystemClock.elapsedRealtime()-start;offset+=n;}
            long deadline=SystemClock.elapsedRealtime()+4000;while(Integer.toUnsignedLong(track.getPlaybackHeadPosition())<samples.length&&SystemClock.elapsedRealtime()<deadline)SystemClock.sleep(25);
            rows.add(p.id+",baseline_reload_v04_same_model,"+word+","+loaded+","+generated+","+first+","+(SystemClock.elapsedRealtime()-start)+",false,"+samples.length);
        }finally{if(track!=null){track.pause();track.flush();track.release();}manager.abandonAudioFocusRequest(focus);tts.release();}
    }
    static int stress(Instrumentation runner)throws Exception{
        SpeechChecks tests=new SpeechChecks();Context c=runner.getTargetContext();SpeechEngine e=SpeechEngine.get(c);
        e.suspend();e.barrier().get(30,TimeUnit.SECONDS);
        long bytes=0;List<String> memory=new ArrayList<>();
        for(int i=0;i<24;i++){
            String sentence="At station number "+i+", the careful traveler opened a dictionary and read every word clearly before continuing the journey through the quiet countryside.";
            SpeechEngine.Metrics m=tests.play(e,VoiceStore.UK,sentence,"stress");bytes+=m.referenceSamples*4;
            tests.ok(e.cachedBytes()<=SpeechEngine.CACHE_LIMIT,"LRU audio byte limit");
            memory.add(i+","+e.cachedBytes()+","+Debug.getPss());
        }
        tests.ok(bytes>SpeechEngine.CACHE_LIMIT,"exercise LRU eviction with real speech");
        tests.save(c,"speech5-stress");Files.write(new File(c.getExternalFilesDir("qa"),"speech5-memory.csv").toPath(),memory,StandardCharsets.UTF_8);
        return tests.count;
    }
}
