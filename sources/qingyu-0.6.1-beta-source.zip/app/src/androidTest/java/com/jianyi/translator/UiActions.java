package com.jianyi.translator;
import android.app.*;
import android.os.SystemClock;
import android.view.*;
import android.view.accessibility.AccessibilityNodeInfo;
final class UiActions {
    static void refresh(Instrumentation runner,Activity activity){
        runner.runOnMainSync(()->activity.findViewById(android.R.id.content).findViewWithTag("result-more").performClick());
        clickText(runner,"重新联网翻译");
    }
    static void clickText(Instrumentation runner,String text){
        for(int i=0;i<20;i++){
            runner.waitForIdleSync();AccessibilityNodeInfo root=runner.getUiAutomation().getRootInActiveWindow();
            if(root!=null)for(AccessibilityNodeInfo node:root.findAccessibilityNodeInfosByText(text))if(text.contentEquals(node.getText())){
                AccessibilityNodeInfo target=node;while(target!=null&&!target.isClickable())target=target.getParent();
                if(target!=null&&target.performAction(AccessibilityNodeInfo.ACTION_CLICK)){runner.waitForIdleSync();return;}
            }
            SystemClock.sleep(100);
        }throw new AssertionError("Missing menu item: "+text);
    }
}
