package com.jianyi.translator;

import android.app.Instrumentation;
import android.content.*;
import android.net.Uri;
import android.os.*;
import org.json.JSONObject;
import java.io.*;
import java.nio.file.Files;

final class UpdateChecks {
    private int count;
    private interface Checked { void run()throws Exception; }
    private void ok(boolean condition,String message){if(!condition)throw new AssertionError(message);count++;}
    private void rejects(Checked check,String message)throws Exception {boolean rejected=false;try{check.run();}catch(IOException ex){rejected=true;}ok(rejected,message);}
    private JSONObject metadata(File apk,int code,String name)throws Exception {
        return new JSONObject().put("schemaVersion",1).put("versionCode",code).put("versionName",name).put("minSdk",26).put("packageName","com.jianyi.translator.prototype").put("sizeBytes",apk.length()).put("sha256",UpdateClient.hash(apk)).put("notes","Update test").put("apkUrl","https://raw.githubusercontent.com/Submerge-hb/jianyi-releases/0000000000000000000000000000000000000000/packages/jianyi-test.apk");
    }
    static int run(Instrumentation runner)throws Exception{return new UpdateChecks().test(runner);}
    private int test(Instrumentation runner)throws Exception {
        Context context=runner.getTargetContext();File fixtures=context.getExternalFilesDir("qa-fixtures");
        File future=new File(fixtures,"future.apk"),wrong=new File(fixtures,"wrong-signer.apk"),other=new File(fixtures,"other-package.apk");
        JSONObject json=metadata(future,9,"0.7.0-qa");UpdateClient.Info info=UpdateClient.parse(json.toString());
        ok(info.versionCode==9,"parse valid manifest");
        String[] badUrls={"http://github.com/Submerge-hb/jianyi-releases/releases/download/v4/jianyi.apk","https://evil.example/jianyi.apk","https://github.com@evil.example/Submerge-hb/jianyi-releases/releases/download/v4/jianyi.apk","https://raw.githubusercontent.com/Submerge-hb/jianyi-releases/main/packages/jianyi.apk","https://github.com/Submerge-hb/jianyi-releases/releases/download/../jianyi.apk?token=bad"};
        for(String url:badUrls)rejects(()->UpdateClient.validateApkUrl(url),"reject untrusted or mutable download URL");
        UpdateClient.validateApkUrl("https://github.com/Submerge-hb/jianyi-releases/releases/download/v4/jianyi-4.apk");ok(true,"official release URL allowed");
        rejects(()->UpdateClient.parse("{}"),"missing manifest fields");
        rejects(()->UpdateClient.parse(new JSONObject(json.toString()).put("sizeBytes",UpdateClient.MAX_APK_BYTES+1).toString()),"oversized manifest rejected");
        rejects(()->UpdateClient.parse(new JSONObject(json.toString()).put("sha256","xyz").toString()),"invalid hash rejected");
        UpdateClient.verify(context,future,info);ok(true,"valid signed higher-version APK");
        rejects(()->UpdateClient.verify(context,future,UpdateClient.parse(new JSONObject(json.toString()).put("sha256","0".repeat(64)).toString())),"wrong hash rejected");
        rejects(()->UpdateClient.verify(context,future,UpdateClient.parse(new JSONObject(json.toString()).put("versionCode",99).toString())),"archive version mismatch rejected");
        rejects(()->UpdateClient.verify(context,wrong,UpdateClient.parse(metadata(wrong,9,"0.7.0-qa").toString())),"different signing key rejected");
        rejects(()->UpdateClient.verify(context,other,UpdateClient.parse(metadata(other,9,"0.7.0-qa").toString())),"different package rejected");
        File current=new File(context.getApplicationInfo().sourceDir);
        rejects(()->UpdateClient.verify(context,current,UpdateClient.parse(metadata(current,8,"0.6.1-beta").toString())),"same version rejected");
        UpdateClient cancelled=new UpdateClient();cancelled.close();rejects(()->cancelled.check(),"cancel before network request");
        File dir=new File(context.getCacheDir(),"updates");dir.mkdirs();File target=new File(dir,info.fileName());Files.copy(future.toPath(),target.toPath(),java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        Uri uri=UpdateActivity.installIntent(context,target).getData();ok(UpdateFileProvider.resolve(context,uri).equals(target),"provider maps exact APK");
        try(InputStream in=context.getContentResolver().openInputStream(uri)){ok(in!=null&&in.read()==0x50,"provider grants read of ZIP APK");}
        rejects(()->UpdateFileProvider.resolve(context,Uri.parse("content://"+context.getPackageName()+".updates/../shared_prefs/test.xml")),"provider prevents path traversal");
        rejects(()->context.getContentResolver().openFileDescriptor(uri,"w"),"provider prevents writes");
        Intent intent=UpdateActivity.installIntent(context,target);ok((intent.getFlags()&Intent.FLAG_GRANT_READ_URI_PERMISSION)!=0&&intent.getClipData()!=null,"installer URI permission scoped");
        try(UpdateClient client=new UpdateClient()){ok(client.download(context,info,p->{}).equals(target),"verified cached APK reused without request");}
        return count;
    }
}
