package com.jianyi.translator;
import android.app.*;
import android.content.*;
import android.content.pm.ActivityInfo;
import android.graphics.*;
import android.os.*;
import android.text.*;
import android.text.style.ClickableSpan;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.io.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/** Real view geometry and interactions; mock results never claim provider translation quality. */
final class CompactChecks {
    private final Instrumentation runner;private MainActivity activity;private int passed;private final float scale;
    private CompactChecks(Instrumentation r,MainActivity a){runner=r;activity=a;scale=a.getResources().getConfiguration().fontScale;}
    static int run(Instrumentation r,MainActivity a)throws Exception{return new CompactChecks(r,a).test();}
    private void ok(boolean value,String text){if(!value)throw new AssertionError(text);passed++;}
    private View view(String tag){return activity.findViewById(android.R.id.content).findViewWithTag(tag);}
    private void ui(Runnable action){runner.runOnMainSync(action);}
    private void settle(){runner.waitForIdleSync();SystemClock.sleep(160);runner.waitForIdleSync();}
    private void click(String tag){ui(()->{View v=view(tag);if(v==null)throw new AssertionError("Missing "+tag);v.performClick();});settle();}
    private void query(String text,boolean chinese){click(chinese?"mode-zh":"mode-en");ui(()->((EditText)view("query-input")).setText(text));click("submit");settle();}
    private void cache(String q,String translated,boolean chinese)throws Exception{
        new LocalStore(activity).record(q,chinese,OnlineTranslator.parse(TranslationChecks.response(new String[]{q},new String[]{translated},chinese),q,chinese));
    }
    private void capture(String name)throws Exception{
        settle();Bitmap b=runner.getUiAutomation().takeScreenshot();File dir=activity.getExternalFilesDir("qa");dir.mkdirs();
        try(FileOutputStream out=new FileOutputStream(new File(dir,"compact-"+scale+"-"+name+".png"))){b.compress(Bitmap.CompressFormat.PNG,100,out);}finally{b.recycle();}
    }
    private Rect bounds(View v){int[] p=new int[2];v.getLocationOnScreen(p);return new Rect(p[0],p[1],p[0]+v.getWidth(),p[1]+v.getHeight());}
    private void fit(String tag){ui(()->{
        ScrollView scroll=(ScrollView)view("result-scroll");Rect area=bounds(scroll),content=bounds(view(tag));
        ok(scroll.getScrollY()==0,"result begins with input visible");ok(area.contains(content),tag+" fits viewport: "+content+" in "+area);
        ok(bounds(view("result-actions")).top>=area.bottom,"fixed controls do not overlap viewport");
    });}
    private void controls(){ui(()->{
        ViewGroup group=(ViewGroup)view("action-buttons");int min=Math.round(48*activity.getResources().getDisplayMetrics().density);
        for(int i=0;i<group.getChildCount();i++){View b=group.getChildAt(i);ok(b.getWidth()>=min&&b.getHeight()>=min,"48dp action target");}
    });}
    private void rotate(int orientation){
        Instrumentation.ActivityMonitor monitor=runner.addMonitor(MainActivity.class.getName(),null,false);ui(()->activity.setRequestedOrientation(orientation));
        Activity next=monitor.waitForActivityWithTimeout(8000);runner.removeMonitor(monitor);ok(next!=null,"rotation recreates activity");activity=(MainActivity)next;settle();
    }
    private int test()throws Exception{
        Context c=runner.getTargetContext();c.getSharedPreferences("jianyi-local-v1",0).edit().clear().commit();TranslationPolicy.consent(c,-1);
        query("judge",false);ui(()->{
            ok(view("home-hero").getVisibility()==View.GONE&&view("query-examples").getVisibility()==View.GONE,"compact hides hero and examples");
            ok(((EditText)view("query-input")).getMaxLines()==2,"two-line editable input");ok(view("submit").getParent()==view("clear-input").getParent(),"inline query and clear");
        });if(scale<=1)fit("word-card:judge");controls();capture("judge");
        cache("bank","银行；河岸",false);query("bank",false);
        ui(()->{ok(view("word-online-summary")!=null&&view("sentence-card")==null,"online word merged into dictionary");ok(view("speak:英:bank")!=null&&view("speak:美:bank")!=null,"word IPA controls retained");});
        if(scale<=1)fit("word-card:bank");capture("bank");
        String beef="I want to eat beef";cache(beef,"我想吃牛肉",false);query(beef,false);
        ui(()->{ok(((TextView)view("sentence-chinese")).getText().toString().equals("我想吃牛肉"),"complete translation shown");Spanned english=(Spanned)((TextView)view("sentence-english")).getText();ok(english.getSpans(0,english.length(),ClickableSpan.class).length==5,"source words clickable");});
        if(scale<=1)fit("sentence-card");controls();capture("sentence");
        if(scale>=1.3f)ui(()->ok(view("copy-result").getTop()>view("speak-sentence-uk").getTop(),"large font action bar wraps to two rows"));
        click("copy-result");ui(()->ok(((android.content.ClipboardManager)c.getSystemService(Context.CLIPBOARD_SERVICE)).getPrimaryClip().getItemAt(0).getText().toString().equals("我想吃牛肉"),"copy uses complete translation"));
        click("favorite");ok(new LocalStore(c).isFavorite(beef,false),"favorite works from fixed action bar");
        ui(()->((EditText)view("query-input")).setText("Changed draft"));settle();ui(()->{ok(view("sentence-card")==null&&view("result-actions").getVisibility()==View.GONE,"edit clears old result and actions");ok(view("home-hero").getVisibility()==View.GONE,"edit stays compact");});
        rotate(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);ui(()->ok(((EditText)view("query-input")).getText().toString().equals("Changed draft")&&view("home-hero").getVisibility()==View.GONE,"edited draft and compact state restored"));capture("landscape-draft");rotate(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        click("tab-1");click("entry:"+beef);ui(()->ok(view("sentence-card")!=null&&view("home-hero").getVisibility()==View.GONE,"favorite opens compact result without network"));
        String zh="这首音乐很好听。";cache(zh,"This music sounds beautiful.",true);query(zh,true);if(scale<=1)fit("sentence-card");capture("chinese-sentence");
        String source="A complete paragraph.\n\n"+"Another sentence with several words. ".repeat(15);
        String translated="这是完整的第一段。\n\n"+"第二段的内容需要完整显示，不能因为一屏限制而截断。".repeat(20)+"末尾校验文字。";
        cache(source,translated,false);query(source,false);ui(()->{ok(((TextView)view("sentence-chinese")).getText().toString().equals(translated),"long paragraphs never truncated");ok(((EditText)view("query-input")).getMaxLines()==2,"long input remains bounded");((ScrollView)view("result-scroll")).fullScroll(View.FOCUS_DOWN);});settle();
        ui(()->{ScrollView sv=(ScrollView)view("result-scroll");TextView out=(TextView)view("sentence-chinese");ok(sv.getScrollY()>0,"long result scrolls");ok(bounds(out).bottom<=bounds(sv).bottom,"translation end reachable above fixed actions");ok(bounds(view("result-actions")).top>=bounds(sv).bottom,"long content not covered by actions");});capture("long-bottom");
        query("行",true);ui(()->ok(view("word-card:walk")!=null&&view("word-card:row")!=null&&view("word-card:line")!=null,"multiple reverse words retained"));capture("multiple-words");
        // Keyboard editing stays usable; rotation does not initiate a new request.
        query(beef,false);ui(()->{EditText edit=(EditText)view("query-input");edit.requestFocus();((InputMethodManager)activity.getSystemService(Context.INPUT_METHOD_SERVICE)).showSoftInput(edit,InputMethodManager.SHOW_IMPLICIT);});SystemClock.sleep(700);settle();
        ui(()->{ok(activity.getWindow().getDecorView().getRootWindowInsets().isVisible(WindowInsets.Type.ime()),"keyboard visible");ok(view("result-actions").getVisibility()==View.GONE,"keyboard has editing space");});capture("keyboard");runner.sendKeyDownUpSync(KeyEvent.KEYCODE_BACK);settle();
        click("clear-input");ui(()->{ok(view("home-hero").getVisibility()==View.VISIBLE&&view("query-examples").getVisibility()==View.VISIBLE,"clear restores original home");ok(((EditText)view("query-input")).getText().length()==0&&view("result-actions").getVisibility()==View.GONE,"clear removes query and actions");});
        if(scale<=1)networkChecks(c);
        return passed;
    }
    private void networkChecks(Context c)throws Exception{
        ok(TranslationPolicy.connected(c),"network gate available for mock transport");TranslationAccount account=new TranslationAccount(c);account.save("123456789","layout-test-key-not-real",1000000);TranslationPolicy.consent(c,1);
        CountDownLatch entered=new CountDownLatch(1),release=new CountDownLatch(1);AtomicInteger calls=new AtomicInteger();
        DictionaryRepository.Result r=TranslationChecks.result("bank","银行");
        ui(()->activity.translatorFactory=()->new OnlineTranslator(){@Override DictionaryRepository.Result translate(String q,boolean zh){calls.incrementAndGet();entered.countDown();try{release.await(3,TimeUnit.SECONDS);}catch(InterruptedException ignored){}return r;}});
        query("light",false);ok(entered.await(2,TimeUnit.SECONDS),"mock request started");ui(()->ok(view("network-loading")!=null&&view("word-card:light")!=null,"local dictionary alongside compact loading"));
        click("submit");ok(calls.get()==1,"same inflight query coalesced");ui(()->((EditText)view("query-input")).setText("new query"));release.countDown();settle();ui(()->ok(view("word-card:bank")==null&&view("network-loading")==null,"stale result cannot replace edited query"));
        AtomicInteger failed=new AtomicInteger();ui(()->activity.translatorFactory=()->new OnlineTranslator(){@Override DictionaryRepository.Result translate(String q,boolean zh)throws IOException{failed.incrementAndGet();throw new NetworkErrors.Failure("测试连接未完成");}});
        query("judge",false);settle();ui(()->ok(view("word-card:judge")!=null&&view("network-error")!=null,"failure leaves offline dictionary readable"));
        UiActions.refresh(runner,activity);settle();ok(failed.get()==2,"More menu retries explicitly");
        rotate(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);rotate(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);ok(failed.get()==2,"rotation never retries network");
        account.delete();TranslationPolicy.consent(c,-1);ui(()->activity.translatorFactory=()->new OnlineTranslator(c));
    }
}
