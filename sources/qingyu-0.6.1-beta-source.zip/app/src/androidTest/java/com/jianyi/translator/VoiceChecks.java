package com.jianyi.translator;
import android.app.Instrumentation;
import android.content.Context;
import android.os.SystemClock;
import com.k2fsa.sherpa.onnx.*;
import java.io.*;
import java.nio.file.Files;
import java.util.*;

final class VoiceChecks {
    private static void assertTrue(boolean c,String label){if(!c)throw new AssertionError(label);}
    static int run(Instrumentation runner)throws Exception{
        Context c=runner.getTargetContext();int count=0;
        SpeechEngine.get(c).suspend();SpeechEngine.get(c).barrier().get(30,java.util.concurrent.TimeUnit.SECONDS);
        assertTrue(!TranslationPolicy.connected(c),"voice generation must be tested with network off");count++;
        File qa=c.getExternalFilesDir("qa"),fixtures=c.getExternalFilesDir("qa-fixtures");qa.mkdirs();
        File root=VoiceStore.root(c);root.mkdirs();
        boolean rejected=false;try{VoiceStore.safeChild(root,"../escape");}catch(IOException ex){rejected=true;}assertTrue(rejected,"archive traversal rejected");count++;
        assertTrue(SpeechPlayer.segments("word ".repeat(100)).stream().allMatch(s->s.length()<=200),"bounded speech chunks");count++;
        for(VoiceStore.Pack p:VoiceStore.PACKS){
            File archive=new File(fixtures,p==VoiceStore.UK?"uk.tar.bz2":"us.tar.bz2");
            assertTrue(archive.length()==p.bytes&&UpdateClient.hash(archive).equals(p.sha),"fixture voice hash");count++;
            File staging=new File(root,p.id+".qa-staging");
            VoiceStore.erase(root,staging);
            try(VoiceStore installer=new VoiceStore()){installer.installArchive(c,p,archive,staging);}
            VoiceStore.erase(root,VoiceStore.directory(c,p));
            assertTrue(staging.renameTo(VoiceStore.directory(c,p)),"activate verified voice");count++;
            assertTrue(VoiceStore.ready(c,p),"voice installed");count++;
            long started=SystemClock.elapsedRealtime();
            OfflineTts tts=SpeechPlayer.create(c,p);
            try{
                assertTrue(tts.sampleRate()==22050&&tts.numSpeakers()>p.speaker,"native voice loaded");count++;
                for(String text:new String[]{"judge","The bank is near the school."}){
                    GeneratedAudio audio=tts.generate(text,p.speaker,SpeechEngine.SPEED);float[] samples=audio.getSamples();
                    double energy=0;for(float v:samples){assertTrue(Float.isFinite(v),"finite sample");energy+=v*v;}
                    assertTrue(samples.length>2000&&energy/samples.length>0.000001,"non-silent speech generated offline");count++;
                    assertTrue(audio.save(new File(qa,p.id+"-"+(text.equals("judge")?"word":"sentence")+".wav").getPath()),"save audition WAV");count++;
                }
            }finally{tts.release();}
            Files.write(new File(qa,p.id+"-timing.txt").toPath(),Collections.singletonList("Load and generate word + sentence: "+(SystemClock.elapsedRealtime()-started)+" ms"));
        }
        return count;
    }
}
