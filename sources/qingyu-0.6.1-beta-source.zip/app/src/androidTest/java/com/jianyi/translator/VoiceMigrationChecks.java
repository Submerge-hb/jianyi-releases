package com.jianyi.translator;
import android.app.Instrumentation;
import android.content.Context;
import java.io.*;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

final class VoiceMigrationChecks {
    private static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
    static int run(Instrumentation runner)throws Exception{
        Context c=runner.getTargetContext();SpeechEngine e=SpeechEngine.get(c);int count=0;
        File root=VoiceStore.root(c),current=VoiceStore.directory(c,VoiceStore.UK),backup=new File(root,"cori-test-backup");
        check(!backup.exists()&&VoiceStore.ready(c,VoiceStore.UK),"new voice ready for migration test");count++;
        File archive=new File(c.getExternalFilesDir("qa-fixtures"),"uk-legacy.tar.bz2");
        check(archive.length()==VoiceStore.LEGACY_UK.bytes&&UpdateClient.hash(archive).equals(VoiceStore.LEGACY_UK.sha),"legacy fixture matches v0.4");count++;
        e.exclusive(()->{
            File legacy=VoiceStore.directory(c,VoiceStore.LEGACY_UK);
            if(!VoiceStore.ready(c,VoiceStore.LEGACY_UK)){
                File stage=new File(root,"legacy-test-staging");VoiceStore.erase(root,stage);
                try(VoiceStore installer=new VoiceStore()){installer.installArchive(c,VoiceStore.LEGACY_UK,archive,stage);}
                VoiceStore.erase(root,legacy);if(!stage.renameTo(legacy))throw new IOException("legacy activation");
            }
            if(!current.renameTo(backup))throw new IOException("park new voice");
        }).get(45,TimeUnit.SECONDS);
        try{
            check(VoiceStore.available(c,Locale.UK)==VoiceStore.LEGACY_UK,"legacy remains selected until new ready");count++;
            SpeechEngine.Metrics old=e.speak("judge",VoiceStore.available(c,Locale.UK),null).done.get(30,TimeUnit.SECONDS);
            check(old.writtenSamples>0,"legacy still plays during migration");count++;
            VoiceStore cancelled=new VoiceStore();cancelled.close();boolean rejected=false;
            try{cancelled.download(c,VoiceStore.UK,(text,percent)->{});}catch(IOException ex){rejected=true;}
            check(rejected&&VoiceStore.available(c,Locale.UK)==VoiceStore.LEGACY_UK,"cancelled update preserves old voice");count++;
        }finally{e.exclusive(()->{if(!backup.renameTo(current))throw new IOException("restore new voice");}).get(30,TimeUnit.SECONDS);}
        check(VoiceStore.available(c,Locale.UK)==VoiceStore.UK,"new voice selected after activation");count++;
        SpeechEngine.Metrics fresh=e.speak("judge",VoiceStore.UK,null).done.get(30,TimeUnit.SECONDS);
        check(!fresh.cacheHit&&fresh.writtenSamples>0,"new model never reuses legacy cached audio");count++;
        e.exclusive(()->VoiceStore.erase(root,VoiceStore.directory(c,VoiceStore.LEGACY_UK))).get(30,TimeUnit.SECONDS);
        check(!VoiceStore.directory(c,VoiceStore.LEGACY_UK).exists()&&VoiceStore.ready(c,VoiceStore.UK),"old files removed only after new ready");count++;
        return count;
    }
}
