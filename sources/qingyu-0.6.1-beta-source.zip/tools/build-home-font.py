"""Reproducible tiny home-title font; install fonttools==4.60.1 first."""
from pathlib import Path
import hashlib
import sys
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / 'tools/font-deps'))
from fontTools import subset
from fontTools.ttLib import TTFont

SOURCE = ROOT / 'tools/font-source/LXGWWenKai-Regular.ttf'
SHA256 = '2d73eea94ad808999d90c0000c239a84a33b09d4bc6ab6c5b8bbf1eda8a7fc8b'
if hashlib.sha256(SOURCE.read_bytes()).hexdigest() != SHA256:
    raise SystemExit('Font source hash mismatch')
font = TTFont(SOURCE)
options = subset.Options()
options.recalc_timestamp = False
subsetter = subset.Subsetter(options=options)
subsetter.populate(text='轻语字里行间，山海相逢。 ')
subsetter.subset(font)
names = {1:'Qingyu Home Kai',2:'Regular',3:'QingyuHomeKai-1.530-subset1',4:'Qingyu Home Kai Regular',6:'QingyuHomeKai-Regular',16:'Qingyu Home Kai',17:'Regular'}
for record in font['name'].names:
    if record.nameID in names:
        record.string = names[record.nameID].encode(record.getEncoding())
target = ROOT / 'app/src/main/res/font/qingyu_kai.ttf'
target.parent.mkdir(parents=True, exist_ok=True)
font.save(target)
assert target.stat().st_size < 100000, 'Font subset size exceeds budget'
print(f'{target}: {target.stat().st_size} bytes')
