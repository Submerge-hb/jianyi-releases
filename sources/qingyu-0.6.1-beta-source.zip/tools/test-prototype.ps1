param([string]$Serial='emulator-5554', [string[]]$Phases=@('main','persistence','large','ergonomics','data'))
$ErrorActionPreference='Stop'
. "$PSScriptRoot\activate-android.ps1"
$project=Split-Path -Parent $PSScriptRoot
$dist=Join-Path $project 'dist'
$qa=Join-Path $dist 'qa'
New-Item -ItemType Directory -Force -Path $qa | Out-Null
$isEmulator=(& adb -s $Serial shell getprop ro.kernel.qemu | Out-String).Trim()
if($isEmulator -ne '1'){throw 'This test resets prototype sample data. It is restricted to an Android emulator.'}
$version = ([regex]::Match((Get-Content "$project\app\build.gradle" -Raw), "versionName '([^']+)'" )).Groups[1].Value
& adb -s $Serial install -r "$dist\qingyu-$version.apk"
if($LASTEXITCODE -ne 0){throw 'Prototype installation failed.'}
& adb -s $Serial install -r "$dist\qingyu-tests.apk"
if($LASTEXITCODE -ne 0){throw 'Test installation failed.'}
& adb -s $Serial logcat -c
$fontScale=(& adb -s $Serial shell settings get system font_scale | Out-String).Trim()
try {
    & adb -s $Serial shell settings put system font_scale 1.0
    foreach($phase in $Phases){
        $scale=switch($phase){'large'{1.3};'compactLarge'{1.3};'compactHuge'{2.0};default{1.0}}
        & adb -s $Serial shell settings put system font_scale $scale
        Start-Sleep -Milliseconds 1800
        & adb -s $Serial shell am force-stop com.jianyi.translator.prototype
        $output=& adb -s $Serial shell am instrument -w -e phase $phase 'com.jianyi.translator.prototype.test/com.jianyi.translator.SmokeInstrumentation' 2>&1
        $output | Tee-Object -FilePath "$qa\$phase.txt"
        if(($output | Out-String) -notmatch 'PASS:' -or ($output | Out-String) -match 'FAIL:'){throw "Device tests failed in phase $phase"}
    }
} finally {
    if($fontScale -eq 'null' -or !$fontScale){& adb -s $Serial shell settings delete system font_scale}
    else {& adb -s $Serial shell settings put system font_scale $fontScale}
    New-Item -ItemType Directory -Force -Path "$dist\screenshots" | Out-Null
    & adb -s $Serial pull '/sdcard/Android/data/com.jianyi.translator.prototype/files/qa/.' "$dist\screenshots"
}
& adb -s $Serial shell am force-stop com.jianyi.translator.prototype
& adb -s $Serial shell am start -W -n 'com.jianyi.translator.prototype/com.jianyi.translator.MainActivity' | Tee-Object -FilePath "$qa\startup.txt"
& adb -s $Serial shell dumpsys meminfo com.jianyi.translator.prototype | Set-Content -LiteralPath "$qa\memory.txt" -Encoding UTF8
$runtimeErrors = (& adb -s $Serial logcat -d -s AndroidRuntime:E | Out-String)
Set-Content -LiteralPath "$qa\runtime-errors.txt" -Value $runtimeErrors -Encoding UTF8
if($runtimeErrors -match 'FATAL EXCEPTION'){throw 'Android runtime crash found.'}
Write-Output 'PASS: all device integration phases completed.'
