$ErrorActionPreference='Stop'
$project=Split-Path -Parent $PSScriptRoot
$folder=Join-Path $project 'app/libs'
New-Item -ItemType Directory -Force -Path $folder | Out-Null
$file=Join-Path $folder 'sherpa-onnx-1.12.14.aar'
$expected='5a629a899888cb2760e245d9d5340858b15591aee7fa13644cf57199ff2829b9'
if(!(Test-Path -LiteralPath $file) -or (Get-FileHash -LiteralPath $file).Hash.ToLowerInvariant() -ne $expected){
    Invoke-WebRequest 'https://github.com/k2-fsa/sherpa-onnx/releases/download/v1.12.14/sherpa-onnx-1.12.14.aar' -OutFile "$file.part"
    if((Get-FileHash -LiteralPath "$file.part").Hash.ToLowerInvariant() -ne $expected){throw 'Runtime checksum mismatch'}
    Move-Item -LiteralPath "$file.part" -Destination $file -Force
}
Write-Output 'Verified sherpa-onnx 1.12.14 runtime.'
