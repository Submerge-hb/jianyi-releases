param([Parameter(Mandatory=$true)][string]$Serial,[switch]$Install)
$ErrorActionPreference='Stop'
. "$PSScriptRoot/activate-android.ps1"
$project=Split-Path -Parent $PSScriptRoot
$version=([regex]::Match((Get-Content "$project/app/build.gradle" -Raw),"versionName '([^']+)'")).Groups[1].Value
$output=Join-Path $project ('dist/phone-qa/'+(Get-Date -Format 'yyyyMMdd-HHmmss'))
$state=(& adb -s $Serial get-state 2>&1 | Out-String).Trim()
if($state -ne 'device'){throw 'Unlock the phone and approve USB debugging for this computer first.'}
if((& adb -s $Serial shell getprop ro.kernel.qemu | Out-String).Trim() -eq '1'){throw 'Use test-prototype.ps1 for an emulator.'}
if($Install){
    & adb -s $Serial install -r "$project/dist/qingyu-$version.apk"
    if($LASTEXITCODE -ne 0){throw 'App installation failed; do not uninstall the existing app.'}
}
$installed=(& adb -s $Serial shell dumpsys package com.jianyi.translator.prototype | Select-String 'versionName=' | Out-String).Trim()
if($installed -ne "versionName=$version"){throw "Install QingYu $version first."}
& adb -s $Serial install -r "$project/dist/qingyu-tests.apk"
if($LASTEXITCODE -ne 0){throw 'Test helper installation failed.'}
New-Item -ItemType Directory -Force -Path $output | Out-Null
$model=(& adb -s $Serial shell getprop ro.product.model | Out-String).Trim()
$android=(& adb -s $Serial shell getprop ro.build.version.release | Out-String).Trim()
"Model: $model`nAndroid: $android`n$version`nOnly fixed test words are spoken. No user history/favorites are read or reset." | Set-Content "$output/device.txt"
Write-Output 'Keep the phone unlocked. Download both voices first, then enable airplane mode and disable Wi-Fi. The test plays fixed words for several minutes.'
$result=& adb -s $Serial shell am instrument -w -e phase phone5 'com.jianyi.translator.prototype.test/com.jianyi.translator.SmokeInstrumentation' 2>&1
$result | Tee-Object -FilePath "$output/result.txt"
& adb -s $Serial pull /sdcard/Android/data/com.jianyi.translator.prototype/files/qa/speech5-benchmark.csv "$output/speech5-benchmark.csv"
if(($result | Out-String) -notmatch 'PASS:' -or ($result | Out-String) -match 'FAIL:'){throw "Phone test did not pass. See $output"}
$rows=Import-Csv "$output/speech5-benchmark.csv"
$stats=$rows | Group-Object pack,mode | ForEach-Object {
    $values=@($_.Group | ForEach-Object {[double]$_.first_write_ms} | Sort-Object)
    $row=$_.Group[0]
    $target=switch($row.mode){'cold'{2000};'warm'{800};'repeat'{250};default{$null}}
    $p95=$values[[Math]::Max(0,[Math]::Ceiling($values.Count*0.95)-1)]
    [pscustomobject]@{voice=$row.pack;mode=$row.mode;count=$values.Count;p95FirstWriteMs=$p95;targetMs=$target;targetMet=if($null -ne $target){$p95 -le $target}else{$null}}
}
$stats | Export-Csv "$output/summary.csv" -NoTypeInformation -Encoding UTF8
$stats | Format-Table
Write-Output "Saved $output. First-write timing is an application-side audio-output estimate, not microphone-measured audible latency. Listening approval is still required."
