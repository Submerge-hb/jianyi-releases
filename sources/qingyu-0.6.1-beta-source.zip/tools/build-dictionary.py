"""Build the bundled indexed dictionary from pinned, locally downloaded sources."""
import csv, hashlib, json, re, sqlite3
from pathlib import Path

root = Path(__file__).resolve().parents[1]
data = root / 'tools/data'
assets = root / 'app/src/main/assets'
us = dict(line.rstrip('\n').split('\t', 1) for line in (data/'en_US.txt').read_text('utf-8').splitlines() if '\t' in line)
cmu={}
for line in (data/'cmudict.dict').read_text('utf-8').splitlines():
    parts=line.split()
    if not parts: continue
    head=re.sub(r'\(\d+\)$','',parts[0])
    cmu.setdefault(head,[]).append(tuple(p for p in parts[1:] if p.startswith('ER') and p[-1:].isdigit()))
corrected=0
for word,ipa in list(us.items()):
    variants=set(cmu.get(word,[]))
    # Normalize rhotic ER stress only when every original CMU pronunciation
    # agrees and IPA vowel counts match (some upstream entries use ɝ for ER0).
    if len(variants)!=1 or not re.search('[ɜɝ]',ipa) or re.search('[ɜɝ][ɹr]',ipa): continue
    ers=next(iter(variants)); readings=ipa.split(', ')
    if not ers or any(len(re.findall('[ɜɝ]',reading))!=len(ers) for reading in readings): continue
    fixed=[]
    for reading in readings:
        marks=iter('ɚ' if er=='ER0' else 'ɝ' for er in ers)
        fixed.append(re.sub('[ɜɝ]',lambda m:next(marks),reading))
    us[word]=', '.join(fixed);corrected+=1
assert 'ɚ' in us['computer'] and 'ɝ' in us['bird']
rows = []
with (data/'ecdict.csv').open(encoding='utf-8', newline='') as f:
    for r in csv.DictReader(f):
        word = r['word'].lower()
        if r['word'] != word or not re.fullmatch(r"[a-z]+(?:[-'][a-z]+)*", word):
            continue
        if not r['phonetic'] or word not in us or not re.search('[\u4e00-\u9fff]',r['translation']):
            continue
        ranks = [int(r[k]) for k in ('bnc','frq') if r[k].isdigit() and int(r[k])>0]
        if not ranks: continue
        r['rank'] = min(ranks)
        rows.append(r)
rows.sort(key=lambda r:(r['rank'], r['word']))
rows = rows[:12000]
target = assets/'dictionary-v2.db'
if target.exists(): target.unlink()
db = sqlite3.connect(target)
db.executescript('CREATE TABLE words(word TEXT PRIMARY KEY, uk TEXT, us TEXT, senses TEXT, rank INTEGER); CREATE TABLE aliases(zh TEXT, word TEXT, PRIMARY KEY(zh,word)); CREATE TABLE forms(form TEXT, word TEXT, PRIMARY KEY(form,word));')
for r in rows:
    senses=[]; aliases=set()
    for line in r['translation'].split('\\n'):
        line=line.strip()
        if not line: continue
        match=re.match(r'^((?:(?:[a-z]+\.)\s*(?:&\s*)?)+)\s*(.*)',line)
        pos,meaning = (match.group(1).strip(),match.group(2)) if match else ('',line)
        senses.append([pos,meaning])
        # Index complete short Chinese glosses, never arbitrary substrings.
        for fragment in re.split('[,，;；、]',meaning):
            fragment=re.sub(r'\[[^\]]*\]|\([^)]*\)|（[^）]*）','',fragment).strip()
            if re.fullmatch('[\u4e00-\u9fff]{2,8}',fragment): aliases.add(fragment)
    ipa=r['phonetic'].strip().strip('/')
    ipa=ipa.replace("'",'ˈ').replace(':','ː')
    db.execute('INSERT INTO words VALUES(?,?,?,?,?)',(r['word'],'/'+ipa+'/',us[r['word']],json.dumps(senses,ensure_ascii=False),r['rank']))
    db.executemany('INSERT OR IGNORE INTO aliases VALUES(?,?)',[(a,r['word']) for a in aliases])
    for formgroup in r['exchange'].split('/'):
        if ':' not in formgroup: continue
        kind,form=formgroup.split(':',1)
        if kind not in ('p','d','i','3','s','r','t'): continue
        if re.fullmatch(r"[a-z]+(?:[-'][a-z]+)*",form): db.execute('INSERT OR IGNORE INTO forms VALUES(?,?)',(form,r['word']))
db.commit()
assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
stats={table:db.execute('SELECT count(*) FROM '+table).fetchone()[0] for table in ('words','aliases','forms')}
db.execute('VACUUM'); db.close()
licenses=assets/'licenses'; licenses.mkdir(exist_ok=True)
for name in ('ecdict-LICENSE.txt','ipa-LICENSE.txt','cmudict-ipa-LICENSE.txt','cmudict-LICENSE.txt'):
    (licenses/name).write_bytes((data/name).read_bytes())
stats['sources']={}
for project,filename,meta in [('ECDICT','ecdict.csv','ecdict-meta.json'),('ipa-dict','en_US.txt','ipa-meta.json'),('CMUdict','cmudict.dict','cmu-meta.json')]:
    stats['sources'][project]={'commit':json.loads((data/meta).read_text('utf-8-sig'))['sha'],'file':filename,'sha256':hashlib.sha256((data/filename).read_bytes()).hexdigest()}
stats['databaseSha256']=hashlib.sha256(target.read_bytes()).hexdigest()
stats['rhoticCorrection']='ER0 → ɚ; ER1/ER2 → ɝ only where original CMU variants agree and vowel counts match'
(assets/'dictionary-info.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps(stats,ensure_ascii=True,indent=2))
