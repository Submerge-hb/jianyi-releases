$ErrorActionPreference='Stop'
$data=Join-Path $PSScriptRoot 'data'
New-Item -ItemType Directory -Force -Path $data | Out-Null
$manifest=Get-Content (Join-Path $PSScriptRoot '../app/src/main/assets/dictionary-info.json') -Raw | ConvertFrom-Json
$ec=$manifest.sources.ECDICT.commit
$ipa=$manifest.sources.'ipa-dict'.commit
$cmu=$manifest.sources.CMUdict.commit
$downloads=@{
    'ecdict.csv'="https://raw.githubusercontent.com/skywind3000/ECDICT/$ec/ecdict.csv"
    'ecdict-LICENSE.txt'="https://raw.githubusercontent.com/skywind3000/ECDICT/$ec/LICENSE"
    'en_US.txt'="https://raw.githubusercontent.com/open-dict-data/ipa-dict/$ipa/data/en_US.txt"
    'ipa-LICENSE.txt'="https://raw.githubusercontent.com/open-dict-data/ipa-dict/$ipa/LICENSE"
    'cmudict.dict'="https://raw.githubusercontent.com/cmusphinx/cmudict/$cmu/cmudict.dict"
}
foreach($name in $downloads.Keys){Invoke-WebRequest -Uri $downloads[$name] -OutFile (Join-Path $data $name) -UseBasicParsing}
foreach($source in @($manifest.sources.ECDICT,$manifest.sources.'ipa-dict',$manifest.sources.CMUdict)){
    if((Get-FileHash (Join-Path $data $source.file) -Algorithm SHA256).Hash -ne $source.sha256){throw "Checksum mismatch: $($source.file)"}
}
foreach($name in @('cmudict-ipa-LICENSE.txt','cmudict-LICENSE.txt')){Copy-Item (Join-Path $PSScriptRoot "../app/src/main/assets/licenses/$name") (Join-Path $data $name) -Force}
@{sha=$ec} | ConvertTo-Json | Set-Content (Join-Path $data 'ecdict-meta.json') -Encoding UTF8
@{sha=$ipa} | ConvertTo-Json | Set-Content (Join-Path $data 'ipa-meta.json') -Encoding UTF8
@{sha=$cmu} | ConvertTo-Json | Set-Content (Join-Path $data 'cmu-meta.json') -Encoding UTF8
Write-Output 'Verified dictionary sources are ready. Run build-dictionary.py using Python.'
