$ErrorActionPreference='Stop'
. "$PSScriptRoot\activate-android.ps1"
$project=Split-Path -Parent $PSScriptRoot
$staging='D:\AndroidDev\projects\qingyu'
$qa=Join-Path $project 'dist\qa-fixtures'
New-Item -ItemType Directory -Force -Path $qa | Out-Null
$original=Get-Content "$project\app\build.gradle" -Raw
try {
    $fixture=$original.Replace('versionCode 8','versionCode 9').Replace("versionName '0.6.1-beta'","versionName '0.7.0-qa'")
    Set-Content "$staging\app\build.gradle" -Value $fixture -Encoding UTF8
    & gradle -p $staging --console=plain --no-daemon --offline :app:assembleDebug
    if($LASTEXITCODE -ne 0){throw 'Fixture build failed'}
    Copy-Item "$staging\app\build\outputs\apk\debug\app-debug.apk" "$qa\future.apk" -Force
    $key=Join-Path $qa 'test-only-key.jks'
    if(!(Test-Path -LiteralPath $key)){
        & keytool -genkeypair -keystore $key -storepass qa-test-only -keypass qa-test-only -alias qa -dname 'CN=Test fixture only' -keyalg RSA -keysize 2048 -validity 30
        if($LASTEXITCODE -ne 0){throw 'QA key creation failed'}
    }
    & apksigner sign --ks $key --ks-key-alias qa --ks-pass pass:qa-test-only --key-pass pass:qa-test-only --out "$qa\wrong-signer.apk" "$qa\future.apk"
    if($LASTEXITCODE -ne 0){throw 'QA resign failed'}
    Copy-Item "$project\dist\qingyu-tests.apk" "$qa\other-package.apk" -Force
} finally {Set-Content "$staging\app\build.gradle" -Value $original -Encoding UTF8}
Write-Output 'QA fixtures only; never publish files under dist/qa-fixtures.'
