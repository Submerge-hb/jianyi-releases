param([switch]$WithTests, [switch]$Lint, [switch]$Offline)
$ErrorActionPreference = 'Stop'
. "$PSScriptRoot\activate-android.ps1"
$project = Split-Path -Parent $PSScriptRoot
$version = ([regex]::Match((Get-Content "$project\app\build.gradle" -Raw), "versionName '([^']+)'" )).Groups[1].Value
if(!$version){throw 'Missing versionName'}
$staging = 'D:\AndroidDev\projects\qingyu'
New-Item -ItemType Directory -Force -Path "$staging\app" | Out-Null
foreach($file in @('settings.gradle','build.gradle','gradle.properties')) {
    Copy-Item -LiteralPath (Join-Path $project $file) -Destination $staging -Force
}
Copy-Item -LiteralPath "$project\app\build.gradle" -Destination "$staging\app" -Force
Copy-Item -LiteralPath "$project\app\src" -Destination "$staging\app" -Recurse -Force
Copy-Item -LiteralPath "$project\app\libs" -Destination "$staging\app" -Recurse -Force
Set-Content -LiteralPath "$staging\local.properties" -Value 'sdk.dir=D:/AndroidDev/sdk' -Encoding ASCII
$tasks = @(':app:assembleDebug')
if($WithTests){ $tasks += ':app:assembleDebugAndroidTest' }
if($Lint){ $tasks += ':app:lintDebug' }
$buildArgs = @('-p',$staging,'--console=plain','--no-daemon')
if($Offline){ $buildArgs += '--offline' }
& gradle @buildArgs @tasks
if($LASTEXITCODE -ne 0){ throw 'Android build failed.' }
$sourceApk = "$staging\app\build\outputs\apk\debug\app-debug.apk"
& apksigner verify --verbose $sourceApk
if($LASTEXITCODE -ne 0){ throw 'APK signature verification failed.' }
$dist = Join-Path $project 'dist'
New-Item -ItemType Directory -Force -Path $dist | Out-Null
$apk = Join-Path $dist "qingyu-$version.apk"
Copy-Item -LiteralPath $sourceApk -Destination $apk -Force
$hash = (Get-FileHash -LiteralPath $apk -Algorithm SHA256).Hash
Set-Content -LiteralPath "$apk.sha256" -Value "$hash  qingyu-$version.apk" -Encoding ASCII
if($WithTests){ Copy-Item -LiteralPath "$staging\app\build\outputs\apk\androidTest\debug\app-debug-androidTest.apk" -Destination "$dist\qingyu-tests.apk" -Force }
[ordered]@{displayName='轻语';projectName='QingYu';version=$version;applicationId='com.jianyi.translator.prototype';minAndroid=8;targetApi=35;sizeBytes=(Get-Item $apk).Length;sha256=$hash;builtAt=[DateTimeOffset]::Now.ToString('o');signing='development';examplesOnly=$false;offlineWords=12000;onlineProvider='Baidu (personal credentials required)'} | ConvertTo-Json | Set-Content -LiteralPath "$dist\build-info.json" -Encoding UTF8
Write-Output "APK ready: $apk"
