$env:JAVA_HOME = 'D:\AndroidDev\jdk\jdk-21.0.12.1+1'
$env:ANDROID_HOME = 'D:\AndroidDev\sdk'
$env:ANDROID_SDK_ROOT = $env:ANDROID_HOME
$env:ANDROID_USER_HOME = 'D:\AndroidDev\cache\android'
$env:ANDROID_AVD_HOME = 'D:\AndroidDev\cache\avd'
$env:ANDROID_EMULATOR_HOME = 'D:\AndroidDev\cache\android'
$env:GRADLE_USER_HOME = 'D:\AndroidDev\cache\gradle'
$env:TEMP = 'D:\AndroidDev\temp'
$env:TMP = $env:TEMP
$env:GRADLE_OPTS = '-Djava.io.tmpdir=D:/AndroidDev/temp -Duser.home=D:/AndroidDev/cache'
$env:JAVA_TOOL_OPTIONS = '-Djava.io.tmpdir=D:/AndroidDev/temp -Duser.home=D:/AndroidDev/cache'
$toolPaths = @("$env:JAVA_HOME\bin", 'D:\AndroidDev\gradle\gradle-8.11.1\bin', "$env:ANDROID_HOME\cmdline-tools\latest\bin", "$env:ANDROID_HOME\platform-tools", "$env:ANDROID_HOME\build-tools\35.0.0")
$remainingPaths = $env:Path -split ';' | Where-Object { $_ -and $_ -notin $toolPaths }
$env:Path = ($toolPaths + $remainingPaths) -join ';'
