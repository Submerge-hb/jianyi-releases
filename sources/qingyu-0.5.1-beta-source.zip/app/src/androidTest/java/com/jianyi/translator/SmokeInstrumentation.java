package com.jianyi.translator;

import android.app.*;
import android.content.*;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.os.*;
import android.text.Spanned;
import android.text.style.ClickableSpan;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.*;
import java.io.*;
import java.util.*;
import java.util.regex.*;

/** Device integration checks using platform instrumentation, with no test runtime in the app. */
public final class SmokeInstrumentation extends Instrumentation {
    private MainActivity activity;
    private String phase;
    private int passed;
    @Override public void onCreate(Bundle arguments){super.onCreate(arguments);phase=arguments.getString("phase","main");start();}
    @Override public void onStart(){
        Bundle result=new Bundle();
        try {
            if(phase.equals("main"))getTargetContext().getSharedPreferences("jianyi-local-v1",Context.MODE_PRIVATE).edit().clear().commit();
            if(!phase.equals("phone5"))TranslationPolicy.consent(getTargetContext(),phase.equals("online4")?0:phase.equals("offline4")?1:-1);
            launch();
            if(phase.equals("speech5")){passed+=SpeechChecks.functional(this);
            }else if(phase.equals("benchmark5")||phase.equals("phone5")){
                runOnMainSync(()->activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON));
                passed+=SpeechChecks.benchmark(this,phase.equals("phone5")?20:6);
            }else if(phase.equals("lifecycle5")){
                SpeechEngine engine=SpeechEngine.get(getTargetContext());
                engine.suspend();engine.barrier().get();
                getTargetContext().getSharedPreferences("jianyi-settings",0).edit().putString("last-voice","uk").commit();
                query("judge",false);engine.barrier().get();int loads=engine.modelLoads;
                check(loads>0,"translation preloads voice");
                rotate(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);engine.barrier().get();
                check(engine.modelLoads==loads,"rotation retains shared model");
                rotate(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);engine.barrier().get();
                check(engine.modelLoads==loads,"portrait retains shared model");
                click("about");dialogClick("英美语音包");sendKeyDownUpSync(KeyEvent.KEYCODE_BACK);settle();engine.barrier().get();
                check(engine.modelLoads==loads,"voice page round trip retains model");
                SpeechEngine.Job job=engine.speak("judge",VoiceStore.UK,null);job.done.get();engine.barrier().get();
                check(engine.cachedBytes()>0,"audio cached before background");
                Intent home=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getTargetContext().startActivity(home);SystemClock.sleep(1200);engine.barrier().get();
                check(engine.cachedBytes()==0,"actual background clears audio cache");
                getTargetContext().startActivity(new Intent(getTargetContext(),MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                settle();engine.prewarm();engine.barrier().get();
                check(engine.modelLoads==loads+1,"return reloads released model once");
            }else if(phase.equals("stress5")){passed+=SpeechChecks.stress(this);
            }else if(phase.equals("migration5")){passed+=VoiceMigrationChecks.run(this);
            }else if(phase.equals("playback4")){
                check(!TranslationPolicy.connected(getTargetContext()),"playback tested offline");
                query("I went to the bank.",false);check(find("speak-sentence-us")!=null,"built-in offline sentence has playback action");runOnMainSync(()->find("speak-sentence-us").performClick());
                android.media.AudioManager audio=(android.media.AudioManager)getTargetContext().getSystemService(Context.AUDIO_SERVICE);
                boolean playing=false;for(int i=0;i<150&&!playing;i++){playing=audio.isMusicActive();SystemClock.sleep(100);}
                check(playing,"offline sentence reached Android audio output");capture("34-offline-speaking");
                query("judge",false);runOnMainSync(()->find("speak:英:judge").performClick());playing=false;for(int i=0;i<150&&!playing;i++){playing=audio.isMusicActive();SystemClock.sleep(100);}
                check(playing,"offline UK word reached Android audio output");
                click("about");dialogClick("英美语音包");SystemClock.sleep(500);capture("35-voice-manager");
            }else if(phase.equals("download4")){
                check(TranslationPolicy.connected(getTargetContext()),"download network available");
                VoiceStore.Pack pack=VoiceStore.US;VoiceStore.erase(VoiceStore.root(getTargetContext()),VoiceStore.directory(getTargetContext(),pack));
                VoiceStore cancelled=new VoiceStore();cancelled.close();boolean rejected=false;
                try{cancelled.download(getTargetContext(),pack,(t,p)->{});}catch(IOException ex){rejected=true;}
                check(rejected&&!VoiceStore.ready(getTargetContext(),pack),"cancelled download not activated");
                final int[] progress={-1};
                try(VoiceStore download=new VoiceStore()){download.download(getTargetContext(),pack,(t,p)->{if(p>=0)progress[0]=p;});}
                check(progress[0]==100&&VoiceStore.ready(getTargetContext(),pack),"real HTTPS download verified and activated");
                check(!new File(VoiceStore.root(getTargetContext()),pack.id+".part").exists(),"temporary download cleaned");
            }else if(phase.equals("failure4")){
                TranslationPolicy.consent(getTargetContext(),1);
                runOnMainSync(()->activity.translatorFactory=()->new OnlineTranslator(){@Override DictionaryRepository.Result translate(String q,boolean zh)throws IOException{throw new IOException("Test service unavailable");}});
                query("bank",false);check(hasText("河岸")&&hasText("联网未完成"),"service failure automatically falls back");check(!hasText("Test service unavailable")||hasText("河岸"),"service error remains separate from dictionary result");
                runOnMainSync(()->activity.translatorFactory=()->new OnlineTranslator(){@Override DictionaryRepository.Result translate(String q,boolean zh)throws IOException{SystemClock.sleep(1800);throw new IOException("Stale failure");}});
                query("light",false);click("clear-input");SystemClock.sleep(2300);check(!hasText("Stale failure")&&!hasText("联网未完成"),"cancelled response cannot overwrite cleared UI");capture("33-service-fallback");
            }else if(phase.equals("voices")){ passed+=VoiceChecks.run(this); capture("31-voices-tested");
            }else if(phase.equals("offline4")){
                check(!TranslationPolicy.connected(getTargetContext()),"device really offline");query("bank",false);check(hasText("河岸")&&hasText("离线"),"automatic dictionary fallback");query("A new offline sentence with no saved result.",false);check(hasText("这条内容需要联网翻译"),"uncached sentence explained");query("The bank is near the school.",false);check(hasText("MyMemory 已保存"),"saved translation available offline");capture("32-offline-auto");
            }else if(phase.equals("online4")){
                check(TranslationPolicy.connected(getTargetContext()),"network validated");query("bank",false);dialogClick("同意并翻译");for(int i=0;i<35&&!hasText("MyMemory 联网");i++)SystemClock.sleep(1000);check(hasText("MyMemory 联网"),"word submitted online first");check(hasText("河岸")&&hasText("/bæŋk/"),"dictionary supplements online word");check(TranslationPolicy.consent(getTargetContext())==1,"consent remembered");capture("30-online-word");query("The bank is near the school.",false);for(int i=0;i<35&&!hasText("MyMemory 联网");i++)SystemClock.sleep(1000);check(hasText("MyMemory 联网"),"second request no consent popup");check(new LocalStore(getTargetContext()).cached("The bank is near the school.",false)!=null,"online saved for offline");capture("30-online-sentence");
            }else if(phase.equals("updates")){
                passed+=UpdateChecks.run(this);
                // Settings -> update navigation is checked separately with coordinate taps.
            }else if(phase.equals("live")){
                query("The bank is near the school.",false);click("online-translate");dialogClick("发送并翻译");
                for(int i=0;i<45&&!hasText("MyMemory 联网")&&!hasText("请稍后重试")&&!hasText("无法连接");i++)SystemClock.sleep(1000);
                check(hasText("MyMemory 联网"),"live online response rendered");capture("15-online");
                check(new LocalStore(getTargetContext()).cached("The bank is near the school.",false)!=null,"live result saved");
                rotate(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);check(hasText("MyMemory 已保存"),"online result retained after rotation");
                rotate(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                query("他在银行工作，周末喜欢步行去公园。",true);click("online-translate");dialogClick("发送并翻译");
                for(int i=0;i<45&&!hasText("MyMemory 联网")&&!hasText("无法连接");i++)SystemClock.sleep(1000);
                check(hasText("MyMemory 联网"),"Chinese to English live response rendered");capture("16-online-zh");
            }else if(phase.equals("data")){
                DictionaryRepository repo=new DictionaryRepository(getTargetContext());
                for(String word:new String[]{"computer","environment","dictionary","development","responsibility"}){
                    DictionaryRepository.Word w=repo.word(word);check(w!=null&&!w.uk.isEmpty()&&!w.us.isEmpty()&&!w.senses.isEmpty(),"expanded dictionary: "+word);
                }
                check(repo.lookup("计算机",true)!=null,"Chinese reverse index");check(repo.word("computers")!=null,"inflected form lookup");
                check(repo.word("computer").us.contains("ɚ"),"CMU rhotic unstressed vowel retained");
                check(repo.lookup("x' OR 1=1 --",false)==null,"SQL input treated as literal");check(!repo.suggestions("compu").isEmpty(),"prefix suggestions");repo.close();
                boolean rejected=false;try{OnlineTranslator.validate("汉".repeat(167));}catch(IOException ex){rejected=true;}check(rejected,"UTF8 byte bound");
                OnlineTranslator.validate("a".repeat(500));check(true,"exact byte boundary");
                for(String invalid:new String[]{"{}","{\"responseStatus\":429}","{\"responseStatus\":200,\"quotaFinished\":true}","{\"responseStatus\":200,\"responseData\":{\"translatedText\":\"\"}}"}){
                    rejected=false;try{OnlineTranslator.parse(invalid,"fixture",false);}catch(IOException ex){rejected=true;}check(rejected,"service error rejected");
                }
                DictionaryRepository.Result r=OnlineTranslator.parse("{\"responseStatus\":200,\"responseData\":{\"translatedText\":\"测试 &amp; <literal>\"}}","fixture sentence",false);
                check(r.chinese.equals("测试 & <literal>"),"entities decoded without losing literal tags");
                LocalStore local=new LocalStore(getTargetContext());local.record("fixture sentence",false,r);if(!local.isFavorite("fixture sentence",false))local.toggle("fixture sentence",false);
                check(!new LocalStore.Entry("Are you sure?",false,0).key().equals(new LocalStore.Entry("Are you sure.",false,0).key()),"sentence punctuation preserved in cache keys");
                local.clearHistory();check(new LocalStore(getTargetContext()).cached("fixture sentence",false)!=null,"favorite keeps result after history removal");
                local.toggle("fixture sentence",false);check(local.cached("fixture sentence",false)==null,"removed data no longer cached");
                query("computer",false);check(hasText("计算机"),"expanded entry rendered");capture("13-expanded-word");
                query("compu",false);check(hasText("computer"),"suggestion buttons rendered");
                query("This is an uncached network sentence.",false);click("online-translate");dialogClick("暂用离线");check(!hasText("正在翻译"),"consent cancellation does not send");capture("14-network-choice");
                query("汉".repeat(167),true);click("online-translate");check(!hasText("正在翻译"),"overlong input blocked before request");
                query("bank",false);
            }else if(phase.equals("persistence")){
                check(new LocalStore(getTargetContext()).isFavorite("bank",false),"favorite survived process restart");
                check(new LocalStore(getTargetContext()).read("history").size()>0,"history survived process restart");
                click("tab-1");check(hasText("bank"),"persisted favorite rendered");capture("07-persistence");
            }else if(phase.equals("large")){
                query("bank",false);capture("08-large-font");check(hasText("bank"),"large font dictionary rendered");
                click("tab-1");capture("09-large-font-favorites");
            }else if(phase.equals("ergonomics")){
                query("bank",false);
                click("speak:英:bank");SystemClock.sleep(700);capture("10-voice-pack-choice");
                if(!VoiceStore.ready(getTargetContext(),VoiceStore.UK)){AccessibilityNodeInfo screen=getUiAutomation().getRootInActiveWindow();check(screen!=null&&!screen.findAccessibilityNodeInfosByText("下载英式英语语音包").isEmpty(),"missing voice gives in-app download");dialogClick("稍后");}
                rotate(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);check(hasText("bank"),"query retained after landscape rotation");capture("11-landscape");
                rotate(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);check(hasText("bank"),"query retained after portrait rotation");
                click("clear-input");click("submit");runOnMainSync(()->check(((EditText)find("query-input")).getError()!=null,"empty input validation"));
                runOnMainSync(()->{
                    EditText edit=(EditText)find("query-input");edit.setText("x".repeat(1200));check(edit.length()==1000,"input size bounded");edit.setText("bank");
                    edit.requestFocus();((InputMethodManager)activity.getSystemService(Context.INPUT_METHOD_SERVICE)).showSoftInput(edit,InputMethodManager.SHOW_IMPLICIT);
                });settle();SystemClock.sleep(900);capture("12-keyboard");
                runOnMainSync(()->{WindowInsets insets=activity.getWindow().getDecorView().getRootWindowInsets();check(insets!=null&&insets.isVisible(WindowInsets.Type.ime()),"keyboard displayed");});
                sendKeyDownUpSync(KeyEvent.KEYCODE_BACK);settle();click("submit");check(hasText("bank"),"query works after keyboard dismissed");
                click("tab-1");click("remove:en:bank");check(!new LocalStore(getTargetContext()).isFavorite("bank",false),"favorite removal");
                click("tab-0");query("bank",false);click("favorite");
            }else{
                capture("01-home");
                query(" BANK ",false);check(hasText("bank"),"case and whitespace normalized");check(hasText("/bæŋk/"),"IPA rendered");check(hasText("河岸"),"multiple senses rendered");capture("02-word");
                click("copy-result");runOnMainSync(()->{
                    String copied=((android.content.ClipboardManager)getTargetContext().getSystemService(Context.CLIPBOARD_SERVICE)).getPrimaryClip().getItemAt(0).getText().toString();
                    check(copied.contains("bæŋk")&&copied.contains("河岸"),"clipboard includes IPA and meanings");
                });
                click("favorite");check(new LocalStore(getTargetContext()).isFavorite("bank",false),"favorite saved");
                query("bank",false);check(new LocalStore(getTargetContext()).read("history").size()==1,"history deduplicated");
                query("银行",true);check(hasText("bank"),"Chinese word lookup");
                query("行",true);check(hasText("walk")&&hasText("row")&&hasText("line"),"ambiguous Chinese character lists senses");capture("03-chinese");
                query("这首音乐很好听。",true);check(hasText("This music sounds beautiful."),"Chinese context example");
                query("I went to the bank.",false);check(hasText("我去了银行。"),"sentence translated");capture("04-sentence");
                runOnMainSync(()->{
                    TextView sentence=(TextView)find("sentence-english");Spanned s=(Spanned)sentence.getText();ClickableSpan[] spans=s.getSpans(0,s.length(),ClickableSpan.class);check(spans.length==5,"all sentence words clickable");spans[spans.length-1].onClick(sentence);
                });settle();capture("05-word-popup");sendKeyDownUpSync(KeyEvent.KEYCODE_BACK);settle();
                click("favorite");click("tab-1");check(hasText("bank")&&hasText("I went to the bank."),"favorites list rendered");capture("06-favorites");
                click("tab-2");check(hasText("银行"),"history rendered");capture("06b-history");
                click("clear-history");dialogClick("取消");check(new LocalStore(getTargetContext()).read("history").size()>0,"history clear cancellation");
                click("clear-history");dialogClick("清空");check(new LocalStore(getTargetContext()).read("history").isEmpty(),"history clear confirmed");check(new LocalStore(getTargetContext()).read("favorites").size()==2,"clearing history preserves favorites");
                click("tab-0");query("unknown example 123",false);check(hasText("这条内容需要联网翻译"),"unsupported input is honest");check(new LocalStore(getTargetContext()).read("history").isEmpty(),"unknown input not stored as success");capture("06c-unsupported");
                query("bank",false);
                DictionaryRepository repo=new DictionaryRepository(getTargetContext());
                String[] examples={"I went to the bank.","He walks to school.","This music sounds beautiful.","I am happy.","Please say that again.","Thank you."};
                for(String example:examples){Matcher m=Pattern.compile("[A-Za-z]+").matcher(example);while(m.find()){DictionaryRepository.Word w=repo.word(m.group());check(w!=null&&!w.uk.isEmpty()&&!w.us.isEmpty(),"IPA coverage: "+m.group());}}
                repo.close();
            }
            result.putString("stream","PASS: "+passed+" checks ("+phase+")\n");result.putInt("passed",passed);finish(Activity.RESULT_OK,result);
        }catch(Throwable error){result.putString("stream","FAIL: "+error+"\n"+android.util.Log.getStackTraceString(error));finish(Activity.RESULT_CANCELED,result);}
    }
    private void launch(){Intent i=new Intent(Intent.ACTION_MAIN);i.setClassName(getTargetContext().getPackageName(),MainActivity.class.getName());i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);activity=(MainActivity)startActivitySync(i);settle();}
    private void settle(){waitForIdleSync();SystemClock.sleep(650);waitForIdleSync();}
    private void rotate(int orientation){
        ActivityMonitor monitor=addMonitor(MainActivity.class.getName(),null,false);
        runOnMainSync(()->activity.setRequestedOrientation(orientation));
        Activity next=monitor.waitForActivityWithTimeout(8000);removeMonitor(monitor);
        if(next==null)throw new AssertionError("Activity not recreated on rotation");activity=(MainActivity)next;settle();
    }
    private View find(String tag){return activity.findViewById(android.R.id.content).findViewWithTag(tag);}
    private void click(String tag){final boolean[] missing={false};runOnMainSync(()->{View v=find(tag);if(v==null)missing[0]=true;else v.performClick();});if(missing[0])throw new AssertionError("Missing view: "+tag);settle();}
    private void query(String q,boolean zh){click(zh?"mode-zh":"mode-en");runOnMainSync(()->((EditText)find("query-input")).setText(q));click("submit");}
    private boolean hasText(String value){final boolean[] found={false};runOnMainSync(()->found[0]=contains(activity.findViewById(android.R.id.content),value));return found[0];}
    private boolean contains(View v,String value){if(v instanceof TextView && ((TextView)v).getText().toString().contains(value))return true;if(v instanceof ViewGroup)for(int i=0;i<((ViewGroup)v).getChildCount();i++)if(contains(((ViewGroup)v).getChildAt(i),value))return true;return false;}
    private void dialogClick(String text){
        boolean clicked=false;
        for(int attempt=0;attempt<20&&!clicked;attempt++){
            AccessibilityNodeInfo root=getUiAutomation().getRootInActiveWindow();
            if(root!=null)for(AccessibilityNodeInfo n:root.findAccessibilityNodeInfosByText(text)){if(text.contentEquals(n.getText())){AccessibilityNodeInfo target=n;while(target!=null&&!target.isClickable())target=target.getParent();if(target!=null)clicked=target.performAction(AccessibilityNodeInfo.ACTION_CLICK);if(!clicked){android.graphics.Rect bounds=new android.graphics.Rect();n.getBoundsInScreen(bounds);if(!bounds.isEmpty()){long now=SystemClock.uptimeMillis();MotionEvent down=MotionEvent.obtain(now,now,MotionEvent.ACTION_DOWN,bounds.centerX(),bounds.centerY(),0),up=MotionEvent.obtain(now,now+50,MotionEvent.ACTION_UP,bounds.centerX(),bounds.centerY(),0);try{sendPointerSync(down);sendPointerSync(up);clicked=true;}finally{down.recycle();up.recycle();}}}if(clicked)break;}}
            if(!clicked)SystemClock.sleep(250);
        }
        if(!clicked)throw new AssertionError("Dialog button unavailable: "+text);settle();
    }
    private void check(boolean condition,String label){if(!condition)throw new AssertionError(label);passed++;}
    private void capture(String name)throws IOException{
        SystemClock.sleep(400);Bitmap bitmap=getUiAutomation().takeScreenshot();if(bitmap==null)throw new IOException("Screenshot unavailable");
        File dir=getTargetContext().getExternalFilesDir("qa");if(dir==null)throw new IOException("QA directory unavailable");dir.mkdirs();
        try(FileOutputStream out=new FileOutputStream(new File(dir,name+".png"))){bitmap.compress(Bitmap.CompressFormat.PNG,100,out);}finally{bitmap.recycle();}
    }
}
