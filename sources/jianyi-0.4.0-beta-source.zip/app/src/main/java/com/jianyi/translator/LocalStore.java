package com.jianyi.translator;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.*;
import java.util.*;

/** Bounded, device-local history and favorites; no account or network dependency. */
final class LocalStore {
    static final class Entry {
        String query; boolean fromChinese; long time; DictionaryRepository.Result result;
        Entry(String q,boolean c,long t) { query=q;fromChinese=c;time=t; }
        // Preserve punctuation in sentence keys: a question and a statement may translate differently.
        String key(){return (fromChinese?"zh:":"en:")+query.trim().toLowerCase(Locale.ROOT).replace('’','\'').replaceAll("\\s+"," ");}
    }
    private final SharedPreferences preferences;
    LocalStore(Context context) { preferences=context.getSharedPreferences("jianyi-local-v1",Context.MODE_PRIVATE); }
    List<Entry> read(String kind) {
        List<Entry> entries=new ArrayList<>();
        try {
            JSONArray array=new JSONArray(preferences.getString(kind,"[]"));
            for(int i=0;i<array.length();i++){
                JSONObject o=array.getJSONObject(i); Entry e=new Entry(o.getString("q"),o.getBoolean("zh"),o.getLong("time"));
                if(o.has("en")&&o.has("cn")){e.result=new DictionaryRepository.Result();e.result.english=o.getString("en");e.result.chinese=o.getString("cn");e.result.source="MyMemory 已保存";}
                entries.add(e);
            }
        } catch(JSONException ignored) { /* Keep the app usable if legacy local data is malformed. */ }
        return entries;
    }
    private void write(String kind,List<Entry> entries) {
        JSONArray array=new JSONArray();
        try { for(Entry e:entries){ JSONObject o=new JSONObject(); o.put("q",e.query);o.put("zh",e.fromChinese);o.put("time",e.time);if(e.result!=null){o.put("en",e.result.english);o.put("cn",e.result.chinese);}array.put(o); } }
        catch(JSONException ex) { throw new IllegalStateException(ex); }
        preferences.edit().putString(kind,array.toString()).apply();
    }
    void record(String query,boolean chinese) {
        record(query,chinese,null);
    }
    void record(String query,boolean chinese,DictionaryRepository.Result result) {
        List<Entry> list=read("history"); Entry e=new Entry(query,chinese,System.currentTimeMillis());
        e.result=result!=null&&result.source.startsWith("MyMemory")?result:null;
        list.removeIf(item->item.key().equals(e.key())); list.add(0,e);
        if(list.size()>100) list=new ArrayList<>(list.subList(0,100)); write("history",list);
    }
    boolean isFavorite(String query,boolean chinese) {
        String key=new Entry(query,chinese,0).key();
        for(Entry e:read("favorites")) if(e.key().equals(key)) return true;
        return false;
    }
    boolean toggle(String query,boolean chinese) {
        List<Entry> list=read("favorites"); Entry e=new Entry(query,chinese,System.currentTimeMillis());
        boolean removed=list.removeIf(item->item.key().equals(e.key()));
        if(!removed){ if(list.size()>=200) throw new IllegalStateException("收藏已达 200 条，请先移除一些内容"); e.result=cached(query,chinese);list.add(0,e); }
        write("favorites",list); return !removed;
    }
    void clearHistory() { preferences.edit().remove("history").apply(); }
    DictionaryRepository.Result cached(String query,boolean chinese){
        String key=new Entry(query,chinese,0).key();
        for(String kind:new String[]{"history","favorites"})for(Entry e:read(kind))if(e.key().equals(key)&&e.result!=null)return e.result;
        return null;
    }
}
