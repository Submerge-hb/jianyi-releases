package com.jianyi.translator;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Indexed offline dictionary with curated overrides for common ambiguous words. */
public final class DictionaryRepository {
    public static final class Word {
        public String word, uk, us;
        public final List<String[]> senses = new ArrayList<>();
        public String summary() { return senses.get(0)[1]; }
    }
    public static final class Result {
        public final List<Word> words = new ArrayList<>();
        public String chinese, english, source="离线词典";
        public boolean isSentence() { return english != null; }
        public String translation(boolean fromChinese) {
            if (isSentence()) return fromChinese ? english : chinese;
            List<String> parts = new ArrayList<>();
            for (Word w : words) parts.add(fromChinese ? w.word : w.summary());
            return String.join("；", parts);
        }
    }
    private final Map<String,Word> english = new LinkedHashMap<>();
    private SQLiteDatabase database;
    private final Map<String,List<Word>> chinese = new LinkedHashMap<>();
    private final Map<String,Result> sentencesEn = new LinkedHashMap<>(), sentencesZh = new LinkedHashMap<>();
    public DictionaryRepository(Context context) throws IOException, JSONException {
        String json;
        try (InputStream in = context.getAssets().open("examples.json"); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[4096]; int count;
            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            json = out.toString(StandardCharsets.UTF_8.name());
        }
        JSONObject data = new JSONObject(json);
        JSONArray entries = data.getJSONArray("words");
        for (int i=0;i<entries.length();i++) {
            JSONObject entry=entries.getJSONObject(i); Word w = new Word();
            w.word=entry.getString("word"); w.uk=entry.getString("uk"); w.us=entry.getString("us");
            JSONArray senses=entry.getJSONArray("senses");
            for (int j=0;j<senses.length();j++) { JSONArray s=senses.getJSONArray(j); w.senses.add(new String[]{s.getString(0),s.getString(1)}); }
            english.put(normalize(w.word),w);
            JSONArray forms=entry.optJSONArray("forms");
            if (forms != null) for(int j=0;j<forms.length();j++) english.put(normalize(forms.getString(j)),w);
            JSONArray aliases=entry.getJSONArray("zh");
            for(int j=0;j<aliases.length();j++) chinese.computeIfAbsent(normalize(aliases.getString(j)), k -> new ArrayList<>()).add(w);
        }
        JSONArray sentences=data.getJSONArray("sentences");
        for(int i=0;i<sentences.length();i++) {
            JSONObject s=sentences.getJSONObject(i); Result r=new Result(); r.source="内置短句"; r.english=s.getString("en"); r.chinese=s.getString("zh");
            sentencesEn.put(normalize(r.english),r); sentencesZh.put(normalize(r.chinese),r);
        }
        File file=new File(context.getFilesDir(),"dictionary-v2.db");
        if(!file.exists()) {
            File temporary=new File(context.getFilesDir(),"dictionary-v2.tmp");
            try(InputStream in=context.getAssets().open("dictionary-v2.db"); FileOutputStream out=new FileOutputStream(temporary)) {
                byte[] buffer=new byte[32768]; int n; while((n=in.read(buffer))!=-1)out.write(buffer,0,n);
                out.getFD().sync();
            }
            if(!temporary.renameTo(file))throw new IOException("Dictionary installation failed");
        }
        database=SQLiteDatabase.openDatabase(file.getPath(),null,SQLiteDatabase.OPEN_READONLY);
    }
    public static String normalize(String text) {
        return text.trim().toLowerCase(Locale.ROOT).replace('’','\'').replaceAll("\\s+"," ").replaceAll("[。.!！?？]+$","");
    }
    public Word word(String query) {
        String key=normalize(query); Word curated=english.get(key); if(curated!=null)return curated;
        Word exact=databaseWord(key); if(exact!=null)return exact;
        try(Cursor c=database.rawQuery("SELECT f.word FROM forms f JOIN words w ON w.word=f.word WHERE f.form=? ORDER BY w.rank LIMIT 1",new String[]{key})) {
            return c.moveToFirst()?databaseWord(c.getString(0)):null;
        }
    }
    private Word databaseWord(String key) {
        try(Cursor c=database.rawQuery("SELECT word,uk,us,senses FROM words WHERE word=?",new String[]{key})) {
            if(!c.moveToFirst())return null;
            Word w=new Word();w.word=c.getString(0);w.uk=c.getString(1);w.us=c.getString(2);
            JSONArray senses=new JSONArray(c.getString(3));
            for(int i=0;i<senses.length();i++){JSONArray s=senses.getJSONArray(i);w.senses.add(new String[]{s.getString(0),s.getString(1)});}
            return w;
        }catch(JSONException ex){return null;}
    }
    public List<String> suggestions(String query) {
        List<String> items=new ArrayList<>(); String key=normalize(query);
        if(!key.matches("[a-z]{2,30}"))return items;
        try(Cursor c=database.rawQuery("SELECT word FROM words WHERE word>=? AND word<? ORDER BY rank LIMIT 5",new String[]{key,key+"\uffff"})){
            while(c.moveToNext())items.add(c.getString(0));
        }return items;
    }
    public void close(){if(database!=null)database.close();}
    public Result lookup(String query, boolean fromChinese) {
        String key=normalize(query);
        Result sentence=(fromChinese ? sentencesZh : sentencesEn).get(key);
        if(sentence != null) return sentence;
        Result r=new Result();
        if(fromChinese) {
            List<Word> entries=chinese.get(key); if(entries != null) r.words.addAll(entries);
            if(entries==null)try(Cursor c=database.rawQuery("SELECT a.word FROM aliases a JOIN words w ON w.word=a.word WHERE a.zh=? ORDER BY w.rank LIMIT 8",new String[]{key})){
                while(c.moveToNext()){Word w=word(c.getString(0));if(w!=null)r.words.add(w);}
            }
        }
        else { Word word=word(key); if(word != null) r.words.add(word); }
        return r.words.isEmpty() ? null : r;
    }
}
