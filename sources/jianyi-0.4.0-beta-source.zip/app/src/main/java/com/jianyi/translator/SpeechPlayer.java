package com.jianyi.translator;

import android.app.*;
import android.content.*;
import android.media.*;
import android.os.*;
import android.widget.Toast;
import com.k2fsa.sherpa.onnx.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/** One native voice at a time, all model work off the UI thread. No system TTS dependency. */
final class SpeechPlayer {
    private final Activity activity;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final AtomicInteger generation=new AtomicInteger();
    private volatile boolean closed;
    private OfflineTts engine;
    private VoiceStore.Pack loaded;
    private volatile AudioTrack track;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable idleRelease=()->{if(!closed)worker.submit(this::releaseEngine);};
    SpeechPlayer(Activity activity){this.activity=activity;}
    static OfflineTts create(Context context,VoiceStore.Pack pack){
        File dir=VoiceStore.directory(context,pack);
        OfflineTtsVitsModelConfig vits=new OfflineTtsVitsModelConfig();
        vits.setModel(new File(dir,pack.model).getPath());vits.setTokens(new File(dir,"tokens.txt").getPath());vits.setDataDir(new File(dir,"espeak-ng-data").getPath());
        OfflineTtsModelConfig model=new OfflineTtsModelConfig();model.setVits(vits);model.setNumThreads(2);model.setDebug(false);
        OfflineTtsConfig config=new OfflineTtsConfig();config.setModel(model);config.setMaxNumSentences(1);
        return new OfflineTts(null,config);
    }
    void speak(String text,Locale locale){
        if(closed||text==null||text.trim().isEmpty())return;
        VoiceStore.Pack pack=VoiceStore.forLocale(locale);
        if(!VoiceStore.ready(activity,pack)){
            new AlertDialog.Builder(activity).setTitle("下载"+pack.name+"语音包")
                .setMessage("下载一次后，就能离线朗读英文单词和句子，无需安装手机系统语音。可在语音包页面试听、管理和删除。")
                .setNegativeButton("稍后",null).setPositiveButton("管理语音包",(d,w)->activity.startActivity(new Intent(activity,VoiceActivity.class))).show();return;
        }
        if(text.length()>5000){Toast.makeText(activity,"内容过长，请分段朗读",Toast.LENGTH_SHORT).show();return;}
        stop();final int token=generation.get();handler.removeCallbacks(idleRelease);
        Toast.makeText(activity,"正在准备"+pack.name+"发音…",Toast.LENGTH_SHORT).show();
        worker.submit(()->{
            try{
                if(token!=generation.get()||closed)return;
                if(loaded!=pack||engine==null){releaseEngine();engine=create(activity,pack);loaded=pack;}
                int rate=engine.sampleRate();
                if(rate<=0)throw new IOException("语音模型未能加载");
                // A bounded sentence at a time, so cancellation does not wait for a long paragraph.
                for(String piece:segments(text)){
                    if(token!=generation.get()||closed)break;
                    // JNI resolves invoke(float[]) specifically. A Java lambda only supplies
                    // the erased invoke(Object) method, so retain an explicit typed bridge.
                    GeneratedAudio audio=engine.generateWithCallback(piece,pack.speaker,0.95f,new kotlin.jvm.functions.Function1<float[],Integer>(){
                        @Override public Integer invoke(float[] samples){return token==generation.get()&&!closed?1:0;}
                    });
                    if(token!=generation.get()||closed)break;
                    play(audio.getSamples(),audio.getSampleRate(),token);
                }
            }catch(Exception|LinkageError ex){releaseEngine();activity.runOnUiThread(()->{if(token==generation.get()&&!activity.isFinishing()&&!closed)new AlertDialog.Builder(activity).setTitle("暂时无法朗读").setMessage("请检查媒体音量；若仍无法播放，可在语音包管理中删除并重新下载。其他翻译功能可继续使用。").setPositiveButton("知道了",null).show();});}
            finally{activity.runOnUiThread(()->{if(token==generation.get()&&!closed){handler.removeCallbacks(idleRelease);handler.postDelayed(idleRelease,20000);}});}
        });
    }
    static List<String> segments(String text){
        List<String> result=new ArrayList<>();
        for(String sentence:text.trim().split("(?<=[.!?;])\\s+")){
            while(sentence.length()>200){int end=sentence.lastIndexOf(' ',200);if(end<1)end=200;result.add(sentence.substring(0,end));sentence=sentence.substring(end).trim();}
            if(!sentence.isEmpty())result.add(sentence);
        }return result;
    }
    private void play(float[] samples,int rate,int token)throws IOException{
        if(samples.length==0)throw new IOException("没有生成音频");
        int minimum=AudioTrack.getMinBufferSize(rate,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_FLOAT);
        AudioTrack audio=new AudioTrack.Builder().setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(new AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_FLOAT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setTransferMode(AudioTrack.MODE_STREAM).setBufferSizeInBytes(Math.max(minimum,16384)).build();
        track=audio;
        AudioManager manager=(AudioManager)activity.getSystemService(Context.AUDIO_SERVICE);
        AudioFocusRequest focus=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK).setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()).setOnAudioFocusChangeListener(change->{if(change<0)stop();}).build();
        try{
            if(manager.requestAudioFocus(focus)!=AudioManager.AUDIOFOCUS_REQUEST_GRANTED)throw new IOException("音频暂被其他应用占用");
            audio.play();int offset=0;
            while(offset<samples.length&&token==generation.get()&&!closed){int n=audio.write(samples,offset,Math.min(4096,samples.length-offset),AudioTrack.WRITE_NON_BLOCKING);if(n<0)throw new IOException("音频播放失败");if(n==0)SystemClock.sleep(10);else offset+=n;}
            long deadline=SystemClock.elapsedRealtime()+samples.length*1000L/rate+2000;
            while(token==generation.get()&&!closed&&audio.getPlaybackHeadPosition()<offset&&SystemClock.elapsedRealtime()<deadline)SystemClock.sleep(25);
        }finally{track=null;try{audio.pause();audio.flush();}catch(IllegalStateException ignored){}audio.release();manager.abandonAudioFocusRequest(focus);}
    }
    void stop(){generation.incrementAndGet();handler.removeCallbacks(idleRelease);AudioTrack audio=track;if(audio!=null)try{audio.pause();audio.flush();}catch(IllegalStateException ignored){}if(!closed)worker.submit(this::releaseEngine);}
    private void releaseEngine(){if(engine!=null){engine.release();engine=null;}loaded=null;}
    void close(){stop();closed=true;worker.submit(this::releaseEngine);worker.shutdown();}
}
