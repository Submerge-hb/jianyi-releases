package com.jianyi.translator;

import android.content.*;
import android.database.*;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.*;

/** Read-only, non-exported provider granting access to one validated update APK URI. */
public final class UpdateFileProvider extends ContentProvider {
    @Override public boolean onCreate(){return true;}
    static File resolve(Context context,Uri uri)throws FileNotFoundException {
        String name=uri.getLastPathSegment();
        if(!"content".equals(uri.getScheme())||!(context.getPackageName()+".updates").equals(uri.getAuthority())||uri.getPathSegments().size()!=1||name==null||!name.matches("jianyi-[0-9]+-[a-f0-9]{64}\\.apk"))throw new FileNotFoundException("Invalid update URI");
        File file=new File(new File(context.getCacheDir(),"updates"),name);if(!file.isFile())throw new FileNotFoundException("Update not available");return file;
    }
    @Override public String getType(Uri uri){return "application/vnd.android.package-archive";}
    @Override public ParcelFileDescriptor openFile(Uri uri,String mode)throws FileNotFoundException{if(!"r".equals(mode))throw new FileNotFoundException("Read only");return ParcelFileDescriptor.open(resolve(getContext(),uri),ParcelFileDescriptor.MODE_READ_ONLY);}
    @Override public Cursor query(Uri uri,String[] projection,String selection,String[] selectionArgs,String sortOrder){
        try{File file=resolve(getContext(),uri);String[] cols=projection!=null?projection:new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE};MatrixCursor cursor=new MatrixCursor(cols);Object[] values=new Object[cols.length];for(int i=0;i<cols.length;i++){if(OpenableColumns.DISPLAY_NAME.equals(cols[i]))values[i]="简译更新.apk";else if(OpenableColumns.SIZE.equals(cols[i]))values[i]=file.length();}cursor.addRow(values);return cursor;}catch(FileNotFoundException ex){return null;}
    }
    @Override public Uri insert(Uri uri,ContentValues values){throw new UnsupportedOperationException("Read only");}
    @Override public int update(Uri uri,ContentValues values,String where,String[] args){throw new UnsupportedOperationException("Read only");}
    @Override public int delete(Uri uri,String where,String[] args){throw new UnsupportedOperationException("Read only");}
}
