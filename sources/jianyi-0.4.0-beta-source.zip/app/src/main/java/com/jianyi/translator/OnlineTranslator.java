package com.jianyi.translator;

import android.text.Html;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

/** Explicit-request, HTTPS-only service adapter. No background uploads or analytics. */
class OnlineTranslator implements AutoCloseable {
    private volatile HttpURLConnection active;
    private volatile boolean cancelled;
    private void checkCancelled()throws InterruptedIOException{if(cancelled||Thread.currentThread().isInterrupted())throw new InterruptedIOException("已取消");}
    public void close(){cancelled=true;HttpURLConnection c=active;if(c!=null)c.disconnect();}
    static final int MAX_BYTES=500;
    static void validate(String text)throws IOException {
        if(text.trim().isEmpty())throw new IOException("请先输入需要翻译的内容");
        if(text.getBytes(StandardCharsets.UTF_8).length>MAX_BYTES)
            throw new IOException("这段文字过长，请分成短句。每次联网最多 500 字节，约 160 个汉字或 500 个英文字母。");
    }
    DictionaryRepository.Result translate(String text,boolean chinese)throws IOException {
        validate(text);
        checkCancelled();
        String pair=chinese?"zh-CN|en":"en|zh-CN";
        URL url=new URL("https://api.mymemory.translated.net/get?q="+URLEncoder.encode(text,"UTF-8")+"&langpair="+URLEncoder.encode(pair,"UTF-8"));
        HttpURLConnection connection=(HttpURLConnection)url.openConnection();
        active=connection;
        connection.setConnectTimeout(7000);connection.setReadTimeout(9000);connection.setInstanceFollowRedirects(false);
        try {
            checkCancelled();
            int status=connection.getResponseCode();
            if(status==429)throw new IOException("免费服务暂时限流，请稍后重试。离线查词仍可使用。");
            if(status!=200)throw new IOException("翻译服务暂不可用（"+status+"），请稍后重试。");
            try(InputStream in=connection.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){
                byte[] bytes=new byte[4096];int n;
                while((n=in.read(bytes))!=-1){checkCancelled();out.write(bytes,0,n);if(out.size()>262144)throw new IOException("翻译服务返回的数据过大，请重试。");}
                return parse(out.toString("UTF-8"),text,chinese);
            }
        }catch(SocketTimeoutException ex){throw new IOException("连接超时，请检查网络后重试。",ex);}
        catch(UnknownHostException ex){throw new IOException("无法连接翻译服务，请检查网络。",ex);}
        finally{connection.disconnect();}
    }
    static DictionaryRepository.Result parse(String json,String text,boolean chinese)throws IOException {
        try {
            JSONObject data=new JSONObject(json);
            if(data.optBoolean("quotaFinished")||data.optInt("responseStatus")==429)
                throw new IOException("免费翻译额度暂时用完，请稍后重试。离线查词仍可使用。");
            if(data.optInt("responseStatus")!=200)throw new IOException("服务未能完成翻译，请稍后重试。");
            String translated=data.getJSONObject("responseData").getString("translatedText").trim();
            if(translated.isEmpty()||translated.length()>5000)throw new IOException("服务没有返回有效译文，请重试。");
            // Decode only entities, never interpret provider text as HTML markup.
            java.util.regex.Matcher m=java.util.regex.Pattern.compile("&(?:#[0-9]+|#x[0-9a-fA-F]+|[a-zA-Z]+);").matcher(translated);
            StringBuffer decoded=new StringBuffer();
            while(m.find())m.appendReplacement(decoded,java.util.regex.Matcher.quoteReplacement(Html.fromHtml(m.group(),Html.FROM_HTML_MODE_LEGACY).toString()));m.appendTail(decoded);
            DictionaryRepository.Result result=new DictionaryRepository.Result();result.source="MyMemory 联网";
            result.chinese=chinese?text:decoded.toString();result.english=chinese?decoded.toString():text;
            return result;
        }catch(JSONException ex){throw new IOException("翻译服务返回格式异常，请稍后重试。",ex);}
    }
}
