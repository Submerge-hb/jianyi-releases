package com.jianyi.translator;

import android.content.Context;
import org.apache.commons.compress.archivers.tar.*;
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.*;

/** Versioned voice archives: streamed, hash checked, bounded extraction, atomic activation. */
final class VoiceStore implements AutoCloseable {
    static final class Pack {
        final String id,name,folder,model,sha; final long bytes; final int speaker;
        Pack(String id,String name,String folder,String model,long bytes,String sha,int speaker){
            this.id=id;this.name=name;this.folder=folder;this.model=model;this.bytes=bytes;this.sha=sha;this.speaker=speaker;
        }
        String url(){return "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/"+folder+".tar.bz2";}
    }
    static final Pack UK=new Pack("uk-v1","英式英语","vits-piper-en_GB-vctk-medium","en_GB-vctk-medium.onnx",80488085,
        "abafd35bdab0a72a3c6b947228ae3cccdf3624db83313c77d1abb5cbc75e1f64",107);
    static final Pack US=new Pack("us-v1","美式英语","vits-piper-en_US-ljspeech-medium","en_US-ljspeech-medium.onnx",67169893,
        "3dfb4b759d8be032a4903a9538d128b0fda2a06ab1de6cbc2d93a97e2dd83dba",0);
    static final Pack[] PACKS={UK,US};
    static Pack forLocale(Locale locale){return "GB".equals(locale.getCountry())?UK:US;}
    interface Progress{void changed(String text,int percent);}
    private volatile boolean cancelled;
    private volatile HttpURLConnection active;
    boolean isCancelled(){return cancelled;}
    static File root(Context c){return new File(c.getFilesDir(),"voices");}
    static File directory(Context c,Pack p){return new File(root(c),p.id);}
    static boolean ready(Context c,Pack p){
        File dir=directory(c,p),marker=new File(dir,"ready");
        try{return marker.isFile()&&new String(Files.readAllBytes(marker.toPath()),StandardCharsets.UTF_8).equals(p.sha)
            &&new File(dir,p.model).length()>1000000&&new File(dir,"tokens.txt").isFile()
            &&new File(dir,"espeak-ng-data/phontab").isFile();}catch(IOException e){return false;}
    }
    private void check()throws InterruptedIOException{if(cancelled||Thread.currentThread().isInterrupted())throw new InterruptedIOException("下载已取消");}
    private HttpURLConnection open(String address)throws IOException{
        URL url=new URL(address);
        for(int i=0;i<6;i++){
            check();
            if(!"https".equals(url.getProtocol())||url.getUserInfo()!=null||url.getPort()!=-1||
                !Arrays.asList("github.com","release-assets.githubusercontent.com","objects.githubusercontent.com").contains(url.getHost()))
                throw new IOException("语音包下载地址异常");
            HttpURLConnection c=(HttpURLConnection)url.openConnection();active=c;c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(15000);c.setReadTimeout(20000);c.setRequestProperty("Accept-Encoding","identity");check();
            int status=c.getResponseCode();
            if(status==301||status==302||status==303||status==307||status==308){
                String location=c.getHeaderField("Location");c.disconnect();if(location==null)throw new IOException("下载地址缺失");url=new URL(url,location);continue;
            }
            if(status!=200){c.disconnect();throw new IOException("暂时无法下载语音包（"+status+"），请稍后重试");}return c;
        }throw new IOException("下载跳转过多");
    }
    void download(Context c,Pack p,Progress progress)throws Exception{
        // Reopening the page during cancellation must not share temporary files
        // with the previous activity's still-finishing download.
        synchronized(p){check();downloadLocked(c,p,progress);}
    }
    private void downloadLocked(Context c,Pack p,Progress progress)throws Exception{
        File base=root(c);if(!base.isDirectory()&&!base.mkdirs())throw new IOException("无法创建语音目录");
        if(ready(c,p))return;
        android.os.storage.StorageManager storage=(android.os.storage.StorageManager)c.getSystemService(Context.STORAGE_SERVICE);
        if(storage.getAllocatableBytes(storage.getUuidForPath(base))<300L*1024*1024)throw new IOException("请先预留至少 300 MB 存储空间");
        File archive=new File(base,p.id+".part"),staging=new File(base,p.id+".staging");
        erase(base,archive);erase(base,staging);
        HttpURLConnection connection=null;
        try{
            connection=open(p.url());long length=connection.getContentLengthLong();
            if(length!=-1&&length!=p.bytes)throw new IOException("语音包版本发生变化，请更新应用后重试");
            MessageDigest digest=MessageDigest.getInstance("SHA-256");long total=0;int last=-1;
            try(InputStream in=connection.getInputStream();FileOutputStream out=new FileOutputStream(archive)){
                storage.allocateBytes(out.getFD(),p.bytes);byte[] buffer=new byte[65536];int n;
                while((n=in.read(buffer))!=-1){check();total+=n;if(total>p.bytes)throw new IOException("语音包大小异常");out.write(buffer,0,n);digest.update(buffer,0,n);int percent=(int)(total*100/p.bytes);if(percent!=last){progress.changed("正在下载 "+percent+"%",percent);last=percent;}}
                out.getFD().sync();
            }
            if(total!=p.bytes||!UpdateClient.hex(digest.digest()).equals(p.sha))throw new IOException("语音包校验失败，请重新下载");
            progress.changed("下载完成，正在安装语音包…",-1);installArchive(c,p,archive,staging);check();
            File target=directory(c,p);erase(base,target);
            if(!staging.renameTo(target))throw new IOException("语音包保存失败");
        }finally{if(connection!=null)connection.disconnect();erase(base,archive);erase(base,staging);}
    }
    void installArchive(Context c,Pack p,File archive,File staging)throws Exception{
        if(!staging.mkdirs()&&!staging.isDirectory())throw new IOException("无法创建语音安装目录");
        long expanded=0;int count=0;
        try(TarArchiveInputStream tar=new TarArchiveInputStream(new BZip2CompressorInputStream(new BufferedInputStream(new FileInputStream(archive))))){
            TarArchiveEntry entry;byte[] buffer=new byte[65536];
            while((entry=tar.getNextTarEntry())!=null){
                check();if(++count>4000)throw new IOException("语音包文件过多");
                String path=entry.getName();if(!path.startsWith(p.folder+"/"))throw new IOException("语音包路径异常");
                String relative=path.substring(p.folder.length()+1);if(relative.isEmpty())continue;
                File out=safeChild(staging,relative);
                if(entry.isSymbolicLink()||entry.isLink()||(!entry.isDirectory()&&!entry.isFile()))throw new IOException("不支持的语音包文件");
                if(entry.isDirectory()){if(!out.mkdirs()&&!out.isDirectory())throw new IOException("无法建立目录");continue;}
                if(entry.getSize()<0||entry.getSize()>150L*1024*1024)throw new IOException("语音文件过大");
                File parent=out.getParentFile();if(!parent.isDirectory()&&!parent.mkdirs())throw new IOException("无法建立目录");
                try(OutputStream stream=new FileOutputStream(out)){int n;while((n=tar.read(buffer))!=-1){check();expanded+=n;if(expanded>220L*1024*1024)throw new IOException("语音包解压大小异常");stream.write(buffer,0,n);}}
            }
        }
        if(!new File(staging,p.model).isFile()||!new File(staging,"tokens.txt").isFile()||!new File(staging,"espeak-ng-data/phontab").isFile())throw new IOException("语音包文件不完整");
        Files.write(new File(staging,"ready").toPath(),p.sha.getBytes(StandardCharsets.UTF_8));
    }
    static File safeChild(File root,String relative)throws IOException{
        if(relative.contains("\\")||relative.startsWith("/")||relative.contains(":"))throw new IOException("非法文件路径");
        File child=new File(root,relative).getCanonicalFile();
        if(!child.getPath().startsWith(root.getCanonicalPath()+File.separator))throw new IOException("非法文件路径");
        return child;
    }
    static void erase(File root,File target)throws IOException{
        if(!target.getCanonicalPath().startsWith(root.getCanonicalPath()+File.separator))throw new IOException("非法清理路径");
        if(!target.exists())return;
        if(Files.isSymbolicLink(target.toPath()))throw new IOException("不支持符号链接");
        File[] children=target.listFiles();if(children!=null)for(File child:children)erase(root,child);
        if(!target.delete())throw new IOException("无法清理语音文件");
    }
    public void close(){cancelled=true;HttpURLConnection c=active;if(c!=null)c.disconnect();}
}
