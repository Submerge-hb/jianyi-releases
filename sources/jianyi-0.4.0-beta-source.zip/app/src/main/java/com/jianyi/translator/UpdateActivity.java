package com.jianyi.translator;

import android.app.*;
import android.content.*;
import android.graphics.Insets;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.Locale;
import java.util.concurrent.*;

/** User-initiated updater. Android remains responsible for the installation consent. */
public final class UpdateActivity extends Activity {
    private final ExecutorService executor=Executors.newSingleThreadExecutor();
    private UpdateClient client;
    private Future<?> task;
    private int generation;
    private TextView status,details;
    private ProgressBar progress;
    private Button check,action,cancel;
    private UpdateClient.Info info;
    private File downloaded;
    private boolean busy;
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        if(Build.VERSION.SDK_INT>=30)getWindow().setDecorFitsSystemWindows(false);
        else getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setBackgroundColor(MainActivity.PAPER);if(Build.VERSION.SDK_INT>=29)outer.setForceDarkAllowed(false);setContentView(outer);
        outer.setOnApplyWindowInsetsListener((v,insets)->{if(Build.VERSION.SDK_INT>=30){Insets b=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());v.setPadding(b.left,b.top,b.right,b.bottom);}else v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;});
        ScrollView scroll=new ScrollView(this);outer.addView(scroll,new LinearLayout.LayoutParams(-1,-1));LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(24),dp(20),dp(24),dp(28));scroll.addView(body);
        Button back=button("‹  返回简译");back.setOnClickListener(v->finish());body.addView(back);
        add(body,label("让简译，一点点更好。",26),22);
        String version;try{version=UpdateClient.installed(this).versionName;}catch(Exception ex){version="未知";}
        add(body,label("当前版本  "+version,14),12);
        status=label("准备检查更新",19);status.setTag("update-status");add(body,status,30);
        details=label("",14);details.setTextIsSelectable(true);details.setTag("update-details");add(body,details,16);
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(100);progress.setVisibility(View.GONE);add(body,progress,20);
        check=button("检查更新");check.setTag("check-update");check.setOnClickListener(v->checkUpdate());add(body,check,24);
        action=button("下载新版");action.setTag("download-update");action.setVisibility(View.GONE);action.setOnClickListener(v->{if(downloaded==null)download();else install();});add(body,action,12);
        cancel=button("取消");cancel.setTag("cancel-update");cancel.setVisibility(View.GONE);cancel.setOnClickListener(v->{cancelTask();idle();status.setText("已取消，可稍后重试");});add(body,cancel,12);
        add(body,label("更新来源：GitHub · Submerge-hb/jianyi-releases\n检查更新不会发送你的查询、收藏或历史。下载使用网络流量；安装前由安卓确认。覆盖更新会保留应用数据。",12),26);
        outer.requestApplyInsets();checkUpdate();
    }
    private int dp(int value){return Math.round(value*getResources().getDisplayMetrics().density);}
    private TextView label(String value,int size){TextView t=new TextView(this);t.setText(value);t.setTextColor(MainActivity.INK);t.setTextSize(size);t.setLineSpacing(dp(4),1);return t;}
    private Button button(String value){Button b=new Button(this);b.setText(value);b.setTextColor(MainActivity.GREEN);b.setTextSize(15);b.setAllCaps(false);b.setMinHeight(dp(50));b.setPadding(dp(14),dp(12),dp(14),dp(12));GradientDrawable shape=new GradientDrawable();shape.setColor(MainActivity.PALE);shape.setCornerRadius(dp(18));b.setBackground(shape);return b;}
    private void add(LinearLayout parent,View child,int margin){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(margin);parent.addView(child,p);}
    private void cancelTask(){generation++;if(task!=null){task.cancel(true);task=null;}if(client!=null){client.close();client=null;}}
    private int begin(String text){cancelTask();busy=true;check.setEnabled(false);action.setEnabled(false);cancel.setVisibility(View.VISIBLE);progress.setVisibility(View.VISIBLE);progress.setIndeterminate(true);status.setText(text);return generation;}
    private void idle(){busy=false;check.setEnabled(true);action.setEnabled(true);cancel.setVisibility(View.GONE);progress.setVisibility(View.GONE);task=null;}
    private void post(int token,Runnable done){runOnUiThread(()->{if(!isFinishing()&&!isDestroyed()&&generation==token)done.run();});}
    private void failure(int token,Exception error){post(token,()->{idle();status.setText("未能完成更新");details.setText(error instanceof java.net.SocketTimeoutException?"连接 GitHub 超时，请检查网络后重试。":error instanceof java.net.UnknownHostException?"无法连接 GitHub，请检查网络后重试。":error instanceof IOException?error.getMessage():"更新暂时失败，请稍后重试。");});}
    private void checkUpdate(){
        if(busy)return;info=null;downloaded=null;action.setVisibility(View.GONE);details.setText("正在读取发布信息…");int token=begin("正在检查更新…");
        UpdateClient request=new UpdateClient();client=request;
        task=executor.submit(()->{try{UpdateClient.Info found=request.check();long installed=UpdateClient.version(UpdateClient.installed(this));post(token,()->{idle();info=found;if(found.versionCode<=installed){status.setText("当前已是最新版本");details.setText(getString(R.string.update_current,found.versionName));}else if(found.minSdk>Build.VERSION.SDK_INT){status.setText(getString(R.string.update_android));details.setText("当前版本仍可继续使用。");}else{status.setText(getString(R.string.update_new,found.versionName));details.setText(String.format(Locale.CHINA,"安装包约 %.2f MB\n\n%s",found.size/1000000.0,found.notes));action.setText("下载新版");action.setVisibility(View.VISIBLE);}});}catch(Exception ex){failure(token,ex);}finally{request.close();}});
    }
    private void download(){
        if(busy||info==null)return;final UpdateClient.Info selected=info;int token=begin("正在下载新版…");progress.setIndeterminate(false);progress.setProgress(0);
        UpdateClient request=new UpdateClient();client=request;
        task=executor.submit(()->{try{File file=request.download(this,selected,p->post(token,()->{progress.setProgress(p);status.setText(p==100?"正在校验安装包…":getString(R.string.update_percent,p));}));post(token,()->{idle();downloaded=file;status.setText("安装包校验通过");details.setText(getString(R.string.update_verified,selected.versionName));action.setText("安装更新");});}catch(Exception ex){failure(token,ex);}finally{request.close();}});
    }
    private void install(){
        if(busy||info==null||downloaded==null)return;
        if(!getPackageManager().canRequestPackageInstalls()){
            new AlertDialog.Builder(this).setTitle("允许简译安装更新")
                .setMessage("安卓需要你允许来自“简译”的应用安装。打开设置后开启对应选项，再返回这里点击“安装更新”。")
                .setNegativeButton("稍后",null).setPositiveButton("打开设置",(d,w)->{try{startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:"+getPackageName())));}catch(ActivityNotFoundException ex){status.setText("请在系统设置中允许简译安装未知应用");}}).show();return;
        }
        final UpdateClient.Info selected=info;final File file=downloaded;int token=begin("正在复核安装包…");
        task=executor.submit(()->{try{UpdateClient.verify(this,file,selected);post(token,()->{idle();try{startActivity(installIntent(this,file));status.setText("请在安卓安装界面确认");}catch(ActivityNotFoundException|SecurityException ex){status.setText("无法打开系统安装程序");details.setText("请确认系统允许简译安装应用，再重试。");}});}catch(Exception ex){downloaded=null;post(token,()->action.setText("重新下载"));failure(token,ex);}});
    }
    static Intent installIntent(Context context,File file){Uri uri=new Uri.Builder().scheme("content").authority(context.getPackageName()+".updates").appendPath(file.getName()).build();Intent intent=new Intent(Intent.ACTION_VIEW).setDataAndType(uri,"application/vnd.android.package-archive").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);intent.setClipData(ClipData.newRawUri("简译更新",uri));return intent;}
    @Override protected void onDestroy(){cancelTask();executor.shutdownNow();super.onDestroy();}
}
