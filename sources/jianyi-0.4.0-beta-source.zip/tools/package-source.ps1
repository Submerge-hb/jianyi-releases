$ErrorActionPreference='Stop'
$project=Split-Path -Parent $PSScriptRoot
$version=([regex]::Match((Get-Content "$project/app/build.gradle" -Raw),"versionName '([^']+)'")).Groups[1].Value
$destination=Join-Path $project "dist/source-$version"
if(Test-Path -LiteralPath $destination){throw "Source staging already exists: $destination"}
New-Item -ItemType Directory -Path "$destination/app","$destination/tools" -Force | Out-Null
foreach($name in @('build.gradle','settings.gradle','gradle.properties','LICENSE','README.md','发布更新说明.md')){
    Copy-Item -LiteralPath "$project/$name" -Destination $destination
}
Copy-Item -LiteralPath "$project/app/build.gradle" -Destination "$destination/app"
Copy-Item -LiteralPath "$project/app/src" -Destination "$destination/app" -Recurse
foreach($name in @('activate-android.ps1','build-prototype.ps1','download-voice-runtime.ps1','download-dictionary.ps1','build-dictionary.py','test-prototype.ps1','prepare-update.ps1','package-source.ps1')){
    Copy-Item -LiteralPath "$project/tools/$name" -Destination "$destination/tools"
}
Copy-Item -LiteralPath "$project/SOURCE-BUILD.md" -Destination $destination
$forbidden=Get-ChildItem -LiteralPath $destination -Recurse -File | Where-Object {
    $_.Extension -in @('.jks','.keystore','.apk','.aar','.part') -or $_.Name -in @('local.properties','key.properties','.env')
}
if($forbidden){throw 'Source archive contains a forbidden local artifact'}
$zip=Join-Path $project "dist/jianyi-$version-source.zip"
Compress-Archive -Path "$destination/*" -DestinationPath $zip -Force
Get-FileHash -LiteralPath $zip -Algorithm SHA256
