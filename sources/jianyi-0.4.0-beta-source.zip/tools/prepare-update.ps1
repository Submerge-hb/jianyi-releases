param(
    [Parameter(Mandatory=$true)][ValidatePattern('^[a-f0-9]{40}$')][string]$ApkCommit,
    [Parameter(Mandatory=$true)][string]$Notes
)
$ErrorActionPreference='Stop'
$project=Split-Path -Parent $PSScriptRoot
$config=Get-Content "$project/app/build.gradle" -Raw
$version=[regex]::Match($config,"versionName '([^']+)'").Groups[1].Value
$code=[int][regex]::Match($config,'versionCode\s+(\d+)').Groups[1].Value
$apk=Get-Item -LiteralPath "$project/dist/jianyi-$version.apk"
$build=Get-Content "$project/dist/build-info.json" -Raw | ConvertFrom-Json
$hash=(Get-FileHash -LiteralPath $apk.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
if($build.version -ne $version -or $build.sha256.ToLowerInvariant() -ne $hash){throw 'Build metadata does not match APK. Rebuild first.'}
if($Notes.Length -gt 4000){throw 'Release notes exceed 4000 characters.'}
$manifest=[ordered]@{
    schemaVersion=1
    versionCode=$code
    versionName=$version
    minSdk=26
    packageName='com.jianyi.translator.prototype'
    sizeBytes=$apk.Length
    sha256=$hash
    notes=$Notes
    apkUrl="https://raw.githubusercontent.com/Submerge-hb/jianyi-releases/$ApkCommit/packages/jianyi-$version.apk"
}
$path=Join-Path $project 'dist/update.json'
[IO.File]::WriteAllText($path,($manifest | ConvertTo-Json),[Text.UTF8Encoding]::new($false))
Write-Output "Prepared $path. Verify the public APK URL and hash before publishing this manifest."
